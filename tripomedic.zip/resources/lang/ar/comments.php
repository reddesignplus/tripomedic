<?php

return [

    'title' => 'مــراجــعــــات',
    'total_count' => 'مــراجــعــــه',


];
