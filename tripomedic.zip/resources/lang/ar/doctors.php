<?php

return [

    'result_title' => '{result} أفضل الأطباء على أساس البحث |{default} أطباء المختارون',
    'gender' => '{men} الدكتور |{women} الدكتورة',
    'men' => 'الذکر',
    'women' => 'انثی',
    'adult' => 'بالغ',
    'child' => 'طفل',
    'contact' => 'حجــز طبـيــب',
    'map' => 'أين يقع مكتب الطبيب؟',

];
