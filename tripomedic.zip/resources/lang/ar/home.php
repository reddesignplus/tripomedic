<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Validation Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the default error messages used by
    | the validator class. Some of these rules have multiple versions such
    | as the size rules. Feel free to tweak each of these messages here.
    |
    */
    'page_direction' => 'rtl',
    'add_clinic' => 'أضف عيادتك',
    'contact_us' => 'اتصل بنا: ',
    'services' => 'خدماتنا',
    'clinics' => 'عيادات',
    'clinics_sub' => 'استمتع بالعلاج',
    'doctors' => 'الأطباء',
    'doctors_sub' => 'مع الافضل',
    'facilitator' => 'المیسرین',
    'facilitator_sub' => 'تصفح بین اکثر من 30 من افضل المیسرین الایرانیین',
    'seesight' => 'انظر البصر',
    'seesight_sub' => 'السفر علی تاریخ',
    'treatments' => 'الصـحـيـة',
    'treatments_sub' => 'کن بصحة الجديدة',
    'special_packages' => 'حــزم الخــاصة',
    'price_from' => 'السعر من ',
    'find_clinic' => 'قارن بین العیادات و قراءه مراجعات المرضی و حجز عبر الانترنت',
    'find_button' => 'العثور علی عيادة علیک الحب',
    'city_placeholder' => ' ...علی سبیل المثال، طهران، شیراز و',
    'treatment_placeholder' => 'علی سبیل المثال طبیب اسنان، شد الوجه',
    'how_we_do' => 'كيف “تریبومدیک” عمل!؟',
    'cities' => 'الوجهات المشهورة',
    'need_advice' => 'أحتاج إلى النصيحة!؟',
    'contact_now' => '!اتصال بنا الان',
    'social_network' => 'شبكات اجتماعية',
    'blog' => 'الإخـــبـــــــــار',
    'more_about' => 'تعلم المزيد عن',
    'see_all_blog' => 'انظر جمیع المشارکات',
    'subscribe_text' => 'اشتراک فی الحصول  علی آخر اصدار',
    'subscribe_button' => 'استشر مجانا مع',
    'copyright' => '@copyright :year',
    'by_reddesign' => 'مشغل بواسطة RedDesign.Studio',
    'related_items' => 'اقـــتــراحــــات لـــك',
    'readmore' => 'اقــرأ الـمزيــد',
    'hospitals'=>'المستشفيات',
    'city'=>'شهر',
    'city_code'=>'کد شهر',
    'credit'=>'اعتبار',
    'name'=>'نام',
    'action'=>'اقدامات',
    'description'=>'توضیحات',
    'featured'=>'ویژه',
    'tel'=>'تلفن',
    'avatar'=>'تصویر',
    'clinic'=>'کلینیک',
    'procedures'=>'إجراءات',
    'created'=>'أنشئت في',
    'published'=>'أنشئت في',
    'updated'=>'تم التحديث في',
    'cancel'=>'لغو',
    'update'=>'به روزرسانی',
    'icon'=>'إجراءات',
    'alias'=>'الاسم المستعار',
    'excerpt'=>'االمقتبس',
    'gender'=>'جنس',
    'age'=>'عمر',
    'add_new'=>'اضف جدید',



    'buttons' => [
        'find_now' => 'اجـــد الان',
        'showMore' => 'أظـهـر المـزيـد',
        'showLess' => 'تـظـهر أقـل',
    ],

'facilitators' =>  [
    'result_title' => '{result}ثمانية ميسرين لطب :treat |{default} عیادات المختارون',

],

    'language'=>[
        'ar'=>'عربی',
        'fa'=>'فارسی',
        'en'=>'انگلیسی',
        'es'=>'اسبانیولی'
]
];
