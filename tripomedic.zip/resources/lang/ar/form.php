<?php

return [

    'treatment' => 'الـتـخـصـصات',
    'language' => 'اللغة المتحدثة',
    'city' => 'مــديــنــة',
    'price' => 'الســعـــــر',
    'doctor' => '',
    'facilities' => 'مــرافــق',
    'rate' => 'رتبة المستخدم',
    'facilitator' => 'تشمل الميسرين',
    'comment_form_title' => 'ما رأيك في هذا المقال!؟',
    'name' => 'الاسم واللقب',
    'comment' => 'اكتب رأيك هنا',
    'email' => 'عنوان البريد الإلكتروني',
    'captcha' => 'أدخل الرمز المقابل',
    'submit_comment' => 'إرســــــــال',
    'submit_inquiry' => 'إرسال هذا',
    'visa_title' => 'الاستفسار عن التأشيرة الطبية',
    'submit_visa' => 'إرسال هذا',

'error'=> [
    'email' => 'آدرس ایمیل صحیح نیست'
]

];
