<?php

return [

    'result_title' => '{0} Featured doctors|{1} Doctors for You',
    'gender' => '{men} Dr. |{women} Dr.',



];
