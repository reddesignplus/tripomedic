<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Validation Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines contain the default error messages used by
    | the validator class. Some of these rules have multiple versions such
    | as the size rules. Feel free to tweak each of these messages here.
    |
    */
    'page_direction' => 'rtl',
    'add_clinic' => 'Add Your Clinic',
    'contact_us' => 'Contact us: ',
    'services' => 'Our Services',
    'clinics' => 'Clinics',
    'clinics_sub' => 'Our Services',
    'doctors' => 'Doctors',
    'doctors_sub' => 'Our Doctors',
    'facilitator' => 'Facilitators',
    'facilitator_sub' => 'Find the Best between around 30 facilitators',
    'seesight' => 'See sight',
    'seesight_sub' => 'Our See sight',
    'treatments' => 'Treatments',
    'treatments_sub' => 'Our Treatments',
    'special_packages' => 'Special Packages',
    'price_from' => 'From',
    'find_clinic' => 'Find best Between clinic and treatments',
    'find_button' => 'Find Now!',
    'city_placeholder' => 'Find Now!',
    'treatment_placeholder' => 'Find Now!',
    'how_we_do' => 'How "TripoMedic" Work?!',
    'need_advice' => 'Need Advice?!',
    'contact_now' => 'Contact us now!',
    'social_network' => 'Social Networks',
    'blog' => 'Articles',
    'see_all_blog' => 'See All Articles',
    'subscribe_text' => 'Subscribe for All Articles',
    'subscribe_button' => 'Subscribe Now!',
    'copyright' => '@copyright :year',
    'by_reddesign' => 'By RedDesign.Studio',


    'buttons' => [
        'find_now' => 'Find Now!',
    ],


];
