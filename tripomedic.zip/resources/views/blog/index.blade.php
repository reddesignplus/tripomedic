@extends('layouts.app')

@section('content')
    <section id="cities" class="mt-3">
        <div class="container">
            <div class="row mb-3">
                <div class="col position-relative">
                    <img class="border radius" src="/images/blog-bg.jpg" alt="{{__('blog.page_title')}}">
                    <p class="position-absolute " style="transform: translate(-50%,-50%);top:50%;left:50%;font-size:12px;color: #fff">{{__('blog.paeg_title')}}</p>
                </div>

            </div>
            <div class="row">
                @foreach (\App\Blog::all() as $item)
                    <div class="blog-item col-12 col-md-6 mb-4">
                        <div class="pb-4">
                            <div class="item-img position-relative">
                                <a href="/blog/{{ $item->id }}">
                                    <img src="{{ $item->featured_image }}" class="border radius w-100"
                                         alt="{{ $item->title }}">
                                    <div class="title position-absolute red p-3">{{$item->title}}</div>
                                </a>
                            </div>
                            <div class="content px-3 pt-1 mb-3">
                                <div class="content">{{ $item->excerpt }}</div>
                            </div>
                            <div class="row justify-content-center">
                                <a href="/blog/{{ $item->id }}" class="tripo-btn btn-white">{{__('home.more_about')}} {{ Str::limit($item->title,10)}}</a>

                            </div>
                        </div>

                    </div>

                @endforeach

            </div>

    @include('partial.social')
@endsection
