@extends('layouts.app')
@section('content')

    <section class="blog-item">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="item">
                            <img src="{{$item->featured_image}}" alt="{{$item->title}}" class="border radius">
                            <h1 class="title mt-2">{{$item->title}}</h1>
                        <div class="description">{!! $item->content !!}</div>
                    </div>
                </div>
            </div>
        </div>

                        @include('partial.comments', ['showTitle'=>true])
        <div class="container comment-form">
            <div class="row">
                <div class="section-head d-flex justify-content-center hr">
                    <h2 class="px-1">{{__('form.comment_form_title')}}</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="comment-form">
                        @include('partial.commentForm')
                    </div>
                </div>
            </div>

        </div>
    </section>
        <section id="related-item">
            <div class="container">
                <div class="row">
                    <div class="section-head d-flex justify-content-center hr">
                        <h2 class="px-1">{{__('home.related_items')}}</h2>
                    </div>
                </div>
            </div>
        </section>




@endsection
