@extends('layouts.app')

@section('content')


<section id="steps">
    <div class="container p-4">
        <div class="row">
            <div class="path d-flex justify-content-center w-100 align-items-center">
                <div class="step rounded-circle p-3">
                    <span class="flaticon-doctor"></span>
                </div>
                <div class="step rounded-circle p-3">
                    <span class="flaticon-clinic"></span>
                </div>
                <div class="step rounded-circle p-3">
                    <span class="flaticon-seesight"></span>
                </div>
                <div class="step rounded-circle p-3">
                    <span class="flaticon-treatment"></span>
                </div>
            </div>
        </div>
        <div class="row justify-content-center mt-4">
            <a class="tripo-btn btn-white" href="#">{{ __('home.how_we_do') }}</a>
        </div>
    </div>
</section>

@include('partial.social')
@endsection
