<section id="destination" class="{{$class ?? ''}}">
    <div class="container">
        @if ($showTitle)

            <div class="row">
                <div class="section-head d-flex justify-content-center hr">
                    <h2 class="px-1">{{__('clinics.destination')}}</h2>
                </div>
            </div>
        @endif
        <div class="row">
            <div class="city-item col-12 col-md-6 mb-4">
                <div class="pb-4">
                    <div class="item-img position-relative">
                        <a href="/cities/{{ $city->id }}" class="tripo-btn p-0">
                            <img src="{{ $city->featured_image }}" class="border radius w-100"
                                 alt="{{ $city->name }}">
                            <p class="title position-absolute btn-btcenter">{{$city->name}}</p>
                        </a>
                    </div>
                            <div class="description p-3 mb-3">{!! $city->description !!} </div>
                </div>

            </div>

        </div>

    </div>
</section>
