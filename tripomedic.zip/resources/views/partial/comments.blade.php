<section id="comments" class="{{$class ?? ''}}">
    <div class="container">
        @if ($showTitle)
            <div class="row">
                <div class="section-head d-flex justify-content-center hr">
                    <h2 class="px-1">{{__('comments.title')}}</h2>
                </div>
            </div>
        @endif
        <div class="row mb-2 m-0 total-count">{{count($comments)}} {{__('comments.total_count')}}</div>
        <div class="row justify-content-center">
            @foreach ($comments as $item)
                <div class="col-md-6">
                    <div class="comment-item d-flex mb-3 pb-3">
                        <div class="detail w-25">
                            <div class="rate">{{$item->rate}}
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star"></span>
                            </div>
                            <div class="date pr-1">{{$item->created_at->format('j F, Y')}}</div>
                        </div>
                        <div class="content w-75">
                            {{$item->comment}}
                        </div>
                    </div>

                </div>

            @endforeach
        </div>
        @if (count($comments) > 2 )
            <div class="row">
                <div class="btn-readmore d-flex flex-column align-items-center position-relative w-100">
                    <a href="#" class="tripo-btn btn-white">{{__('home.buttons.showMore')}}</a>
                    <div class="arrow"></div>

                </div>
            </div>
        @endif
    </div>
</section>
