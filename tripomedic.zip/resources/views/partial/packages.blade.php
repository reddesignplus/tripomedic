<section id="packages">
    <div class="container">
        <div class="row">
            <div class="section-head d-flex justify-content-center hr">
                <h2 class="px-1">{{__('home.special_packages')}}</h2>
            </div>
        </div>
        <div class="row">
            <div class="owl-carousel owl-theme" id="special-carousel">

                @foreach ($packages as $package)
                    <div class="item"  style="width:330px">
                        <div class="package-img">
                            <a href="packages/{{ $package->id }}">
                                <img src="{{ $package->featured_image }}" class="border radius"
                                     alt="{{ $package->excerpt }}">
                            </a>
                        </div>
                        <div class="content align-items-center position-absolute d-flex text-center px-2">
                            <a href="packages/{{ $package->id }}">
                                <p class="package-price">{{ __('home.price_from') }} {{ $package->price }}</p>
                                <p>{{ $package->name }}</p>
                            </a>
                        </div>
                    </div>
                @endforeach

            </div>
        </div>
    </div>

</section>
