<section id="subscribe" class="mt-0">
    <div class="container d-flex flex-column position-relative justify-content-center">
        <div class="row justify-content-center">
                <form action="/subscribe/add" method="post">
                    @method('PUT')
                    @csrf
                    <p class="form-label text-center mb-4 w-100">{{__('home.subscribe_text')}}</p>
                    <div class="d-flex align-items-center">
                        <input id="email" type="email" name="email" class="form-control radius @error('email') is-invalid @enderror">
                        @error('email')
                        <div class="alert alert-danger">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="position-absolute btn-btcenter">
                       <button type="submit" class="tripo-btn btn-white">{{__('home.subscribe_button')}}</button>
                    </div>
                </form>

        </div>
    </div>
</section>
