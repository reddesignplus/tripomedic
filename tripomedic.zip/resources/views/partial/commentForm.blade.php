<form action="/comment/add" method="post" class=" d-flex flex-column align-items-center text-center">
   @method('POST')
    @csrf
    <input type="hidden" value="1" name="object_type">
    <input type="hidden" value="1" name="object_id">
    <div class="mb-2">
        <label for="comment" class="form-label">{{__('form.comment')}}</label>
        <textarea name="comment" rows="5" id="comment" class="form-control radius"></textarea>
    </div>
    <div class="mb-2">
        <label for="name" class="form-label">{{__('form.name')}}</label>
        <input type="text" name="name" id="name" class="form-control radius" />
    </div>
    <div class="mb-2">
        <label for="email" class="form-label">{{__('form.email')}}</label>
        <input id="email" type="email" name="email" class="form-control radius @error('email') is-invalid @enderror" >

        @error('email')
        <div class="alert alert-danger">{{ __('form.error.email') }}</div>
        @enderror
    </div>
    <div class="mb-2">
        <button type="submit" class="tripo-btn btn-white">{{__('form.submit_comment')}}</button>
    </div>
</form>
