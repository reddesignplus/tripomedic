<section id="social" class=" col-lg-6 mt-4">
    <div class="container">
        <div class="row">
            <div class="section-head d-flex justify-content-center hr">
                <h2 class="px-1">{{__('home.social_network')}}</h2>
            </div>
        </div>
        <div class="row justify-content-center">
            <ul class="d-flex justify-content-around list-unstyled w-75 m-0">
                <li>
                    <a href="https://www.instagram.com/tripomedic/"><span class="social-icon instagram"></span></a>
                </li>
                <li>
                    <a href="https://www.facebook.com/tripomedic/"><span class="social-icon facebook"></span></a>
                </li>
                <li>
                    <a href="https://www.twitter.com/tripomedic/"><span class="social-icon twitter"></span></a>
                </li>
            </ul>
        </div>
    </div>
</section>
