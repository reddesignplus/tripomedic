<section id="blog" class="{{$class ?? ''}}">
    <div class="container">
        @if ($showTitle)

        <div class="row">
            <div class="section-head d-flex justify-content-center hr">
                <h2 class="px-1">{{__('home.blog')}}</h2>
            </div>
        </div>
        @endif
        <div class="row">
                @foreach ($blog as $item)
                    <div class="blog-item col-12 col-md-6 mb-4">
                        <div class="pb-4">
                            <div class="item-img position-relative">
                                <a href="/blog/{{ $item->id }}">
                                    <img src="{{ $item->featured_image }}" class="border radius w-100"
                                         alt="{{ $item->title }}">
                                    <div class="title position-absolute red p-3">{{$item->title}}</div>
                                </a>
                            </div>
                            <div class="content px-3 pt-1 mb-3">
                                    <div class="content">{{ $item->excerpt }}</div>
                            </div>
                            <div class="row justify-content-center">
                                <a href="/blog/{{ $item->id }}" class="tripo-btn btn-white">{{__('home.more_about')}} {{ Str::limit($item->title,10)}}</a>

                            </div>
                        </div>

                    </div>

                @endforeach

        </div>

            @if ($showMore)
        <div class="row">
            <div class="section-head d-flex justify-content-center hr">
                <p style="background-color: white" class="m-0 p-1">
                    <a href="/blog" class="position-relative tripo-btn btn-blue btn-border">{{__('home.see_all_blog')}}</a>
                </p>

            </div>
        </div>
            @endif
    </div>
</section>
