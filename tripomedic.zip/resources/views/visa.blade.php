@extends('layouts.app')

@section('content')

    <section id="visa">
        <div class="d-flex justify-content-center form-title mb-3">{{$page->title}}</div>
        <div class="container">
            <div class="row">
                <div class="col-12 description">
                    {!! $page->content !!}
                </div>

            </div>
        </div>
        <div class="container">
            <div class="row justify-content-center">
                <div class="divider my-3"></div>
                <div class="title text-center mb-3">{{__('form.visa_title')}}</div>
            </div>
        </div>

        <div class="container d-flex visa justify-content-center position-relative">

            <div class="row align-items-center">
                <form action="/visa" method="post" class="text-center">
                    @csrf
                    <div class="form-row justify-content-around">

                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gender" id="gender"
                                           value="men" {{  app('request')->input('gender') == 'men' ? 'checked' :'' }}>
                                    <label class="form-label" for="gender">{{__('doctors.men')}}</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gender" id="gender"
                                           value="women"  {{  app('request')->input('gender') == 'women' ? 'checked' :'' }}>
                                    <label class="form-label" for="gender">{{__('doctors.women')}}</label>
                                </div>

                    </div>
                    <div class="form-group">
                        <label for="name" class="form-label">{{__('form.name')}}</label>
                        <input type="text" name="name" id="name" class="form-control radius"/>
                    </div>
                    <div class="form-group">
                        <label for="email" class="form-label">{{__('form.email')}}</label>
                        <input id="email" name="email" type="email"
                               class="form-control radius @error('email', 'login') is-invalid @enderror">

                        @error('email', 'login')
                        <div class="alert alert-danger">{{ __('form.error.email') }}</div>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="email" class="form-label">{{__('form.age')}}</label>
                        <input id="age" type="number" name="age" class="form-control radius">
                    </div>
                    <div class="form-group">
                        <label for="email" class="form-label">{{__('form.nationality')}}</label>
                        <input id="email" name="nationality" type="email"
                               class="form-control radius">
                    </div>
                    <div class="form-group">
                        <label for="attendant" class="form-label">{{__('form.attendant')}}</label>
                        <input id="attendant" name="attendant" type="number"
                               class="form-control radius">
                    </div>
                    <div class="form-group">
                        <label for="m_records" class="form-label">{{__('form.m_records')}}</label>
                        <input id="m_records" name="m_records" type="file"
                               class="form-control radius">
                    </div>
                    <div class="form-group">
                        <label for="attendant" class="form-label">{{__('form.passport')}}</label>
                        <input id="attendant" type="file"
                               class="form-control radius">
                    </div>

                    <div class="form-group">
                        <label for="attendant" class="form-label">{{__('form.description')}}</label>
                        <textarea id="attendant"name="description"  type="file"
                                  class="radius" rows="5"></textarea>
                    </div>
                    <div class="position-absolute btn-btcenter">
                        <button type="submit" class="tripo-btn btn-white text-nowrap">
                            {{__('form.submit_visa')}}
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </section>
    <section>

    </section>



    @include('partial.advice')
    @include('partial.social')
@stop
