@extends('admin.layouts.app', ['activePage' => 'facilitators', 'titlePage' => __('home.facilitator')])

@section('content')
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title ">{{$facilitator->name}}</h4>
                            <p class="card-category">{{$facilitator->excerpt}}</p>
                        </div>
                        <div class="card-body">
                            <form action="{{route('admin.facilitators.update',['facilitator'=>$facilitator])}}"
                                  method="post" enctype="multipart/form-data">
                                @method('PUT')
                                @csrf

                                <div class="form-row my-5">
                                    <div class="form-group col">
                                        <label for="name">{{__('home.name')}}</label>
                                        <input type="text" class="form-control" id="name" name="name"
                                               value="{{old('name') ?? $facilitator->name }}" placeholder="">
                                        @error('name')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group col">
                                        <label for="alias">{{__('home.alias')}}</label>
                                        <input type="text" class="form-control" id="alias" name="alias"
                                               value="{{old('alias') ?? $facilitator->alias }}">
                                        @error('alias')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="form-row my-5">
                                    <div class="form-group col">
                                        <label for="excerpt">{{__('home.excerpt')}}</label>
                                        <input type="text" class="form-control" id="excerpt" name="excerpt"
                                               value="{{old('excerpt') ?? $facilitator->excerpt }}">
                                    </div>
                                    @error('excerpt')
                                    <div class="alert alert-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="form-row">
                                    <div class="form-group col">
                                        <label for="address">{{__('home.address')}}</label>
                                        <input type="text" class="form-control" id="address" name="address"
                                               value="{{old('address' ?? $facilitator->address )}}">
                                    </div>
                                    @error('address')
                                    <div class="alert alert-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="form-row">
                                    <div class="form-group pt-3">
                                        <label for="description">{{__('home.description')}}</label>
                                        <textarea class="form-control description" id="description" name="description"
                                                  rows="3">{{old('description') ?? $facilitator->description }}</textarea>
                                    </div>
                                    @error('description')
                                    <div class="alert alert-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-row">

                                    <div class="form-group col">
                                        <label for="tel">{{__('home.tel')}}</label>
                                        <input type="text" class="form-control" id="tel" name="tel"
                                               value="{{old('tel') ?? $facilitator->tel }}">
                                        @error('tel')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
                                    </div>

                                    <div class="form-group col">
                                        <label for="website">{{__('home.website')}}</label>
                                        <input type="text" class="form-control" id="website" name="website"
                                               value="{{old('website') ?? $facilitator->website }}">
                                        @error('website')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
                                    </div>

                                    <div class="form-group col">
                                        <label for="email">{{__('home.email')}}</label>
                                        <input type="email" class="form-control" id="email" name="email"
                                               value="{{old('email') ?? $facilitator->email }}">
                                        @error('email')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col">
                                        <label for="certificate">{{__('home.certificate')}}</label>
                                        <input type="text" class="form-control" id="certificate" name="certificate"
                                               value="{{old('certificate') ?? $facilitator->certificate }}">
                                        @error('certificate')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group col">
                                        <label for="services">{{__('home.services')}}</label>
                                        <input type="text" class="form-control" id="services" name="services"
                                               value="{{old('services') ?? $facilitator->services }}">
                                        @error('services')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="form-row"> <div class="form-group col-3">
                                        <label for="city_code">{{__('home.credit')}}</label>
                                        <select class="form-control" id="credit" name="credit">
                                            @foreach ( \App\Credit::all() as $option)
                                                <option value="{{$option->type}}" {{ $option->type == $facilitator->credit ? "selected" : "" }}>{{$option->name}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    @error('credit')
                                    <div class="alert alert-danger">{{ $message }}</div>
                                    @enderror</div>


                                <div class="form-row">
                                    <div class="form-group col">
                                        <div class="fileinput fileinput-new text-center col-3" data-provides="fileinput">
                                            <div class="fileinput-new thumbnail img-raised">
                                                <img src="{{old('logo') ?? $facilitator->logo }}">
                                            </div>
                                            <div class="fileinput-preview fileinput-exists thumbnail img-raised"></div>
                                            <div class="col-3">
                                        <span class="btn btn-raised btn-round btn-default btn-file">
            <span class="fileinput-new">Select image</span>
            <span class="fileinput-exists">Change</span>
            <input type="file" name="logo"/>
                                              @error('logo')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
        </span>
                                                <a href="#pablo" class="btn btn-danger btn-round fileinput-exists"
                                                   data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="form-group col">
                                        <div class="fileinput fileinput-new text-center col-3" data-provides="fileinput">
                                            <div class="fileinput-new thumbnail img-raised">
                                                <img src="{{old('featured_image') ?? $facilitator->featured_image }}">
                                            </div>
                                            <div class="fileinput-preview fileinput-exists thumbnail img-raised"></div>
                                            <div class="col-3">
                                        <span class="btn btn-raised btn-round btn-default btn-file">
            <span class="fileinput-new">Select image</span>
            <span class="fileinput-exists">Change</span>
            <input type="file" name="featured_image"/>
                                              @error('featured_image')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
        </span>
                                                <a href="#pablo" class="btn btn-danger btn-round fileinput-exists"
                                                   data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                            </div>
                                        </div>

                                    </div>
                                </div>






                                <div class="form-row">
                                    <div class="togglebutton">
                                        <label>
                                            <span>{{__('home.featured')}}</span>
                                            <input type="checkbox"
                                                  {{ old('featured') || $facilitator->featured == 'on' ? 'checked' : '' }} name="featured">
                                            <span class="toggle"></span>
                                        </label>
                                    </div>

                                    <div class="form-group col-3">
                                        <label for="created_at">{{__('home.created')}}</label>
                                        <input class="form-control" type="text"
                                               value="{{$facilitator->created_at }}"
                                               readonly>
                                    </div>
                                    <div class="form-group col-3">
                                        <label for="updated_at">{{__('home.updated')}}</label>
                                        <input class="form-control" type="text"
                                               value="{{\Carbon\Carbon::now()}}"
                                               readonly>
                                    </div>
                                </div>
                                <div class="form-row float-right">
                                    <button type="submit" class="btn btn-primary">{{__('home.update')}}</button>
                                    <a href="{{route('admin.facilitators')}}" class="btn btn-danger">{{__('home.cancel')}}</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
