@extends('layouts.app')

@section('content')
    <div class="container mt-3">
        <div class="row">
            <div class="col-12">
                <div class="description text-justify px-3">{!! $lead !!}
                </div>
            </div>
        </div>
    </div>
    <section id="filter" class="mt-3">
        <div class="container d-flex flex-column position-relative justify-content-center">
            <div class="row justify-content-center">
                <form action="/facilitators" method="POST" class="text-center">
                    @method('POST')
                    @csrf
                    <div class="form-group">
                        <label for="treatment" class="form-label mb-1">{{__('form.treatment')}}</label>
                        <select class="form-control form-control-sm radius" name="treatment" id="treatment">
                            @foreach (\App\Procedure::where('type','treatment')->get() as $treat)
                                <option value="{{$treat->id}}" {{  app('request')->input('treatment') == $treat->id ? 'checked' :'' }} >
                                    @php if(app('request')->input('treatment') == $treat->id)
                                        $treatForTitle = $treat->name ;
                                        @endphp
                                    {{ $treat->name }}
                                </option>
                            @endforeach

                        </select>
                    </div>
                    <div class="form-group">
                        <label for="city" class="form-label mb-1">{{__('form.city')}}</label>
                        <select class="form-control form-control-sm radius" name="city" id="city">
                            @foreach (\App\City::all() as $city)
                                <option value="{{$city->id}}" {{  app('request')->input('city') == $city->id ? 'checked' :'' }} >
                                    {{ $city->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">

                        <label class="form-label form-check-label w-100 d-flex align-items-center justify-content-center form-check p-0"
                               for="facilitator">{{__('form.facilitator')}}
                            <input class="form-check-input" type="checkbox" name="facilitator"
                                   id="facilitator"
                                   value="1" {{  app('request')->input('facilitator')or '' }} >
                            <span class="form-check-sign">
                                <span class="check"></span>
                              </span>
                        </label>

                    </div>
                    <div class="position-absolute btn-btcenter">
                        <button type="submit" class="tripo-btn btn-white text-nowrap">
                            {{__('home.buttons.find_now')}}
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </section>

    <section id="facilitators-result">
        <div class="container">
            <div class="row">
                <div class="section-head d-flex justify-content-center hr">
                    <h2 class="px-1">@php echo trans_choice('home.facilitators.result_title', $type ) @endphp</h2>
                </div>
            </div>

            @isset($facilitators)
                    <ul class="facilitators-list list-unstyled">
                        @foreach ($facilitators as $facilitator)
                            <li class="result-item row mb-3 align-items-center">
                                <div class="col-4">
                                    <a href="/facilitators/{{$facilitator->id}}">
                                        <img src="{{$facilitator->logo}}" alt="{{$facilitator->name}}">
                                    </a>
                                </div>
                                <div class="col-8 details p-1">
                                    <p class="name"><a
                                            href="/facilitators/{{$facilitator->id}}">{{$facilitator->name}}</a>
                                    </p>
                                    <p class="excerpt"> {{ Str::limit($facilitator->excerpt,20) }}</p>
                                    <p class="rate"></p>
                                </div>
                            </li>
                        @endforeach
                    </ul>
            @endisset
            @unless ($facilitators)

            @endunless
        </div>
    </section>
    @include('partial.advice')
    @include('partial.social')

@endsection

