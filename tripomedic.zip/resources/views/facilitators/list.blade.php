@extends('admin.layouts.app', ['activePage' => 'facilitators', 'titlePage' => __('home.facilitator')])

@section('content')
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title ">{{__('home.facilitator')}}</h4>
                            <p class="card-category">{{__('home.facilitator_sub')}}</p>
                        </div>
                        <div class="card-body">
                            <div class="actions float-right">
                                <a class="btn btn-primary" href="{{route('admin.facilitators.create')}}">{{__('home.add_new')}}</a>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-hover">

                                    <thead class=" text-primary">
                                    <th>
                                        ID
                                    </th>
                                    <th>
                                        {{__("home.featured")}}
                                    </th>
                                    <th>
                                        {{__("home.avatar")}}
                                    </th>
                                    <th>
                                        {{__("home.name")}}
                                    </th>
                                    <th>
                                        {{__("home.city")}}
                                    </th>

                                    <th>
                                        {{__("home.tel")}}
                                    </th>

                                    <th>
                                        {{__("home.action")}}
                                    </th>
                                    </thead>

                                    <tbody>
                                    @foreach(\App\Facilitator::all() as $facilitator)
                                        <tr>
                                            <td>
                                                {{$facilitator->id}}
                                            </td>
                                            <td>
                                                <button  type="button" class="btn btn-fab btn-fab-mini btn-round {{$facilitator->featured == 'on' ? 'btn-warning' : 'btn-default'}}">
                                                    <i class="material-icons">star</i>
                                                </button>
                                            </td>
                                            <td>
                                                <img src="{{$facilitator->logo }}" alt="{{$facilitator->name}}">
                                            </td>
                                            <td>
                                                <a href="{{route('admin.facilitators.edit',$facilitator)}}">{{$facilitator->name}}</a>
                                            </td>
                                            <td>
                                                {{$facilitator->city_code}}
                                            </td>
                                            <td>
                                                {{$facilitator->tel}}
                                            </td>


                                            <td>
<span class="input-group-btn">
            <button type="button" class="btn btn-fab btn-fab-mini btn-round btn-primary">
                <i class="material-icons">edit</i>
            </button>
        </span>
                                                <span class="input-group-btn">
            <button type="button" class="btn btn-fab btn-fab-mini btn-round btn-outline-danger">
                <i class="material-icons">delete</i>
            </button>
        </span>
                                            </td>

                                        </tr>
                                    @endforeach
                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
