@extends('layouts.app')
@section('content')

    <section id="cities" class="mt-3">
        <div class="container">
            <div class="row mb-3">
                <div class="col position-relative">
                    <img class="border radius" src="{{ $cities->featured_image }}" alt="{{$cities->title}}">
                    <p class="position-absolute " style="transform: translate(-50%,-50%);top:50%;left:50%;font-size:12px">{{$cities->title}}</p>
                </div>
            </div>
            <div class="row content">
                <div class="col description">
                    {!! $cities->content !!}
                </div>
            </div>
            <div class="row cities-list align-items-center justify-content-around mb-4">
                @foreach(\App\City::all() as $item)
                    <a href="/cities/?c={{$item->city_code}}" class="location btn-green py-1 px-1 d-inline-block">
                        <span class="flaticon-location"></span>{{$item->name}}</a>
                @endforeach

            </div>

            <div class="row">
                <div class="col-12 position-relative">
                    <a href="/cities/{{$city->city_code}}">
                        <img src="{{$city->featured_image}}" alt="{{$city->name . $city->excerpt}}" class="border radius">
                        <p class="position-absolute btn-btcenter"> {{$city->name}}</p>
                    </a>
                </div>

            </div>

            <div class="row content gallery justify-content-center align-items-center mb-4">

                    {{$city->content}}
                    {{$city->serices}}
                    @php $cityGallery = (json_decode($city->gallery,true));
                    @endphp
                    @foreach($cityGallery as $key=>$value)
                        @if ($key == "images")
                            @foreach($value as $item)
                                <div class="item col-6 mb-2">
                                    <img src="{{$item['url']}}" alt="{{$item['title']}}" class="w-100 border radius">
                                </div>
                            @endforeach
                        @else
                        @foreach($value as $item)
                            <div class="item col-12">
                                <video  alt="{{$item['title']}}" class="w-100 border radius" controls>
                                    <source src="{{$item['url']}}" type="video/mp4">
                                    Your browser does not support the video ta
                                </video>
                            </div>
                        @endforeach

                        @endif

                    @endforeach
                </div>

        </div>

        {{-- Ads block--}}
        <div class="container">
            <div class="row">
                <div class="col-12 position-relative">
                    <img src="/images/ads/image-03.jpg" alt="" class="border radius">
                    <p class="position-absolute btn-btcenter">
                        الإعلان في الأشياء الطبية
                    </p>
                </div>
            </div>
        </div>

        {{--   Best Hospitals in city --}}
        <section id="bestHospitals">

            <div class="container">
                <div class="row">
                    <div class="section-head d-flex justify-content-center hr">
                        <h2 class="px-1">{{__('home.best_hospitals')}}</h2>
                    </div>
                </div>
                <div class="row justify-content-center">
                    @foreach ($city->hospitals as $hospital)
                        <div class="col best-item d-flex align-items-center">
                            <div class="image w-50"><img class="img-fluid border radius" src="{{$hospital->featured_image}}" alt="{{$hospital->name}}"></div>
                            <span class="name p-3">{{$hospital->name}}</span>
                        </div>
                    @endforeach
                </div>
            </div>
        </section>


        {{--   Best Clinic in city --}}
        <div class="container">
            <div class="row best-clinics">
                @foreach (\App\Hospital::where('featured',1) as $hospital)
                    <div class="best-item">
                        <div class="image"><img src="{{$hospital->featured_image}}" alt="{{$hospital->name}}"></div>
                        <div class="name">{{$hospital->name}}</div>
                    </div>
                @endforeach
            </div>
        </div>

    </section>


    @include('partial.advice')
    @include('partial.social')
@endsection
