<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" dir="{{__('home.page_direction')}}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">

</head>
<body>

<div id="app">
    @if(Request::path() === '/')
        <div class="container">
            <div class="row justify-content-center px-md-0 py-1">
                <div class="d-flex">
                    <div class="icon d-flex justify-content-center align-items-center">
                        <span>{{__('home.contact_us')}}</span><span class="text"> +989123333000</span>
                    </div>
                </div>
                <div class="d-none d-lg-block px-3">
                    <span class="text">info@tripomedic.com</span>
                </div>
            </div>
        </div>

    @endif
    <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
        <div class="container">

            <button class="navbar-toggler p-0" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="{{ __('Toggle navigation') }}">
                <span class="navbar-toggler-icon"></span>
            </button>
            <a class="navbar-brand m-0" href="{{ url('/') }}">
                <img src="/images/logo.png" alt="{{ config('app.name', 'Laravel') }}">
            </a>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <!-- Left Side Of Navbar -->
                <ul class="navbar-nav mr-auto">

                </ul>

                <!-- Right Side Of Navbar -->
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a href="#" class="nav-link">{{ __('home.add_clinic') }}</a>
                    </li>
                    <!-- Authentication Links -->
                    @guest

                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('login') }}">{{ __('auth.login') }}</a>
                        </li>
                        @if (Route::has('register'))
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('register') }}">{{ __('auth.register') }}</a>
                            </li>
                        @endif
                    @else
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                {{ Auth::user()->name }} <span class="caret"></span>
                            </a>

                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                @if (1)
                                    <a class="dropdown-item" href="{{ route('admin.dashboard') }}">
                                        {{ __('admin.dashboard') }}
                                    </a>
                                @endif

                                <a class="dropdown-item" href="{{ route('logout') }}"
                                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    {{ __('auth.logout') }}
                                </a>

                                <form id="logout-form" action="{{ route('logout') }}" method="POST"
                                      style="display: none;">
                                    @csrf
                                </form>
                            </div>
                        </li>
                    @endguest
                </ul>
            </div>
        </div>
    </nav>

    <main class="">
        @yield('content')
    </main>
</div>
<!-- Scripts -->

<footer class="py-5 mt-30">
    <div class="container-fluid">
        <div class="row">
            <div class="col-4"></div>
            <div class="col-4"></div>
            <div class="col-4"></div>
        </div>
        <div class="row justify-content-center copyright">
            <p><span>{{ __('home.copyright',['year' => now()->year]) }} </span><a href="http://www.reddesign.studio">{{__('home.by_reddesign')}}</a></p>
        </div>
    </div>

</footer>

<script src="{{ asset('js/app.js') }}" defer></script>
</body>
</html>
