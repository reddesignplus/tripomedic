@extends('admin.layouts.app', ['activePage' => 'hospitals', 'titlePage' => __('home.hospitals')])

@section('content')
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title ">{{__('home.hospitals')}}</h4>
                            <p class="card-category">{{__('home.hospitals')}}</p>
                        </div>
                        <div class="card-body">
                            <div class="actions float-right">
                                <a class="btn btn-primary" href="{{route('admin.hospitals.create')}}">{{__('home.add_new')}}</a>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-hover">

                                    <thead class=" text-primary">
                                    <th>
                                        ID
                                    </th>
                                    <th></th>
                                    <th>
                                        {{__("home.name")}}
                                    </th>
                                    <th>
                                        {{__("home.credit")}}
                                    </th>
                                    <th>
                                        {{__("home.city")}}
                                    </th>
                                    <th>
                                        {{__("home.action")}}
                                    </th>
                                    </thead>

                                    <tbody>
                                    @foreach(\App\Hospital::all() as $hospital)

                                        <tr>
                                            <td>
                                                {{$hospital->id}}
                                            </td>
                                            <td>
                                                <button  type="button" class="btn btn-fab btn-fab-mini btn-round {{$hospital->featured == 'on' ? 'btn-warning' : 'btn-default'}}">
                                                    <i class="material-icons">star</i>
                                                </button>
                                            </td>
                                            <td>
                                                <a href="{{route('admin.hospitals.edit',$hospital)}}">{{$hospital->name}}</a>
                                            </td>
                                            <td>
                                                {{$hospital->credit}}
                                            </td>
                                            <td>
                                                {{$hospital->city->name}}
                                            </td>
                                            <td>

                                                <button type="button" class="btn btn-fab  btn-fab-mini btn-round btn-primary">
                                                    <i class="material-icons">edit</i>
                                                </button>
                                                <button type="button" class="btn btn-fab  btn-fab-mini btn-round btn-outline-danger">
                                                    <i class="material-icons">delete</i>
                                                </button>

                                            </td>

                                        </tr>
                                    @endforeach
                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
