@extends('admin.layouts.app', ['activePage' => 'clinics', 'titlePage' => __('home.clinics')])

@section('content')
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title ">{{__('home.clinics')}}</h4>
                            <p class="card-category">{{__('home.clinics_sub')}}</p>
                        </div>
                        <div class="card-body">
                            <div class="actions float-right">
                                <a class="btn btn-primary"
                                   href="{{route('admin.clinics.create')}}">{{__('home.add_new')}}</a>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-hover">

                                    <thead class=" text-primary">
                                    <th>
                                        ID
                                    </th>
                                    <th></th>
                                    <th>
                                        {{__("home.name")}}
                                    </th>
                                    <th>
                                        {{__("home.credit")}}
                                    </th>
                                    <th>
                                        {{__("home.city")}}
                                    </th>
                                    <th>
                                        {{__("home.action")}}
                                    </th>
                                    </thead>

                                    <tbody>
                                    @foreach(\App\Clinic::all() as $clinic)

                                        <tr>
                                            <td>
                                                {{$clinic->id}}
                                            </td>
                                            <td>
                                                <button type="button"
                                                        class="btn btn-fab btn-fab-mini btn-round {{$clinic->featured == 'on' ? 'btn-warning' : 'btn-default'}}">
                                                    <i class="material-icons">star</i>
                                                </button>
                                            </td>
                                            <td>
                                                <a href="{{route('admin.clinics.edit',$clinic)}}">{{$clinic->name}}</a>
                                            </td>
                                            <td>
                                                {{$clinic->credit}}
                                            </td>
                                            <td> {{$clinic->city->name}}</td>
                                            <td>

                                                <button type="button"
                                                        class="btn btn-fab  btn-fab-mini btn-round btn-primary">
                                                    <i class="material-icons">edit</i>
                                                </button>
                                                <button type="button"
                                                        class="btn btn-fab  btn-fab-mini btn-round btn-outline-danger">
                                                    <i class="material-icons">delete</i>
                                                </button>
                                            </td>

                                        </tr>
                                    @endforeach
                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
