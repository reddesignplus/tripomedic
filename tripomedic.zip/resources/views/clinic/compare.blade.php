
@foreach($clinics as $clinic)
{{$clinic}}
@endforeach
