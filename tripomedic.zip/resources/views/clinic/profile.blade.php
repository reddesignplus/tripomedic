@extends('layouts.app')

@section('content')
    <section class="profile">
        <div class="container">
            <div class="row justify-content-around mb-2">
                <div class="w-25 text-center px-3">
                    <a href="/cities/0{{ $clinic->city->city_code}}" class="location btn-green py-1 px-1 d-inline-block"><span
                            class="flaticon-location"></span>{{$clinic->city->name}}</a>
                </div>
                <div class="w-25 text-center px-3">
                    <span class="rate btn-green py-1 px-1">{{$clinic->rate}} 4.3</span>
                </div>

            </div>
            <div
                class="row flex-column align-items-center justify-content-center m-0 text-center detail position-relative clinic-item">
                <div class="avatar position-absolute"><img src="{{ $clinic->logo }}"
                                                           alt="{{ $clinic->name }}"></div>
                <div class="mt-5">
                    <p class="name">{{ $clinic->name }}</p>
                    <p class="excerpt">{{$clinic->procedures->first()['name']}}</p>
                    <a href="#comments" class="btn-green py-1 px-1 mb-3 total-count"><span
                            class="icon-review"></span> {{count($clinic->comments)}} {{__('comments.total_count')}}</a>
                </div>
                <a href="#" class="tripo-btn btn-white btn-btcenter position-absolute" data-toggle="modal"
                   data-target="#inquiry">{{__('clinics.contact')}}</a>
            </div>
        </div>

        <div class="container mt-5">
            <div class="row">
                <div class="section-head d-flex justify-content-center hr">
                    <h2 class="px-1">{{__('clinics.treats')}}</h2>
                </div>
            </div>
            <div class="row">
                <div class="accordion col-12 w-100" id="treatments">
                    @foreach($treatments as $key=>$value)
                        <div class="card">

                            <button class="btn btn-link py-4 px-2" type="button" data-toggle="collapse"
                                    data-target="#collapse{{$key}}" aria-expanded="true"
                                    aria-controls="collapse{{$key}}">
                                <span class="treat-title float-right">{{ \App\Procedure::find($key)->name }}</span>
                                <span class="float-left">{{count($value)}}</span>
                            </button>

                            <div id="collapse{{$key}}" class="collapse show" aria-labelledby="heading{{$key}}"
                                 data-parent="#treatments">
                                <div class="card-body p-0">
                                    <ul class="list-unstyled w-100 p-0">
                                        @for ($i = 0; $i < count($value); $i++)
                                            <li class="d-flex align-items-center justify-content-between py-4 px-2">
                                                <a href="/procedures/{{$value[$i]->id}}">
                                                    {{$value[$i]->name}}
                                                </a>
                                                @if ($value[$i]->pivot['price'])
                                                    <span class="float-left"> {{ $value[$i]->pivot['price']}}</span>
                                                @else
                                                    <a href="#" class="btn-gray float-left" data-toggle="modal"
                                                       data-target="#inquiry">{{__('clinics.req_price')}}</a>

                                                @endunless
                                            </li>
                                        @endfor
                                    </ul>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>

        <div class="container mt-5">
            <div class="row">
                <div class="section-head d-flex justify-content-center hr">
                    <h2 class="px-1">{{__('clinics.desc')}}</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="description mx-3">
                        {!! $clinic->description !!}
                    </div>
                </div>

            </div>
            <div class="row">
                <div class="btn-readmore d-flex flex-column align-items-center position-relative w-100">
                    <a href="/blog" class="tripo-btn btn-white">{{__('home.readmore')}}</a>
                    <div class="arrow"></div>

                </div>
            </div>
        </div>
    </section>
    @include('partial.comments', ['comments' => $clinic->comments,'showTitle'=>true])
    <section id="addresses">
        <div class="container mt-30">
            <div class="row">
                <div class="section-head d-flex justify-content-center hr">
                    <h2 class="px-1">{{__('clinics.map')}}</h2>
                </div>
            </div>
            <div class="map">
                <div class="mapouter">
                    <div class="gmap_canvas">
                        <iframe width="330" height="420" id="gmap_canvas" class="border radius"
                                src="https://maps.google.com/maps?q=Imam%20of%Khomeini%Hospital&t=&z=13&ie=UTF8&iwloc=&output=embed"
                                frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
                    </div>
                </div>
            </div>
        </div>

        {{-- Social Addresses--}}
        <div class="container mt-4">
            <div class="row flex-column align-content-center text-center">
                <div class="contact-info">
                    @if ($clinic->tel)
                        <div class="section-head d-flex justify-content-center hr">
                            <span></span>
                        </div>
                        <p class="phones">{{$clinic->tel}}</p>
                    @endif
                    @if ($clinic->website)
                        <div class="section-head d-flex justify-content-center hr">
                            <span></span>
                        </div>  <p>{{$clinic->website}}</p>
                    @endif

                    @if ($clinic->emial)
                        <div class="section-head d-flex justify-content-center hr">
                            <span></span>
                        </div> <p>{{$clinic->emial}}</p>
                    @endif
                    @if ($clinic->instagram)
                        <div class="section-head d-flex justify-content-center hr">
                            <span></span>
                        </div> <p>{{$clinic->instagram}}</p>
                    @endif

                </div>
            </div>
        </div>

    </section>



    @include('partial.city',['city'=>$clinic->city,'showTitle'=>true])

    @include('partial.social')



    {{--Modal for Inquiry--}}
    <div class="modal fade" id="inquiry" tabindex="-1" role="dialog" aria-labelledby="inquiry" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">{{__('form.inquiry_title')}}</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Recipient:</label>
                            <input type="text" class="form-control" id="recipient-name">
                        </div>
                        <div class="form-group">
                            <label for="message-text" class="col-form-label">Message:</label>
                            <textarea class="form-control" id="message-text"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Send message</button>
                </div>
            </div>
        </div>
    </div>
@endsection

