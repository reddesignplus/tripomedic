@extends('layouts.app')
@if (1)
@section('content')
    @if(!empty($best))
        <div class="container mt-3">
            <div class="row">
                <div class="col-12">
                    <div class="best">
                        <a href="/clinics/{{$best->id}}" class="tripo-btn btn-white p-0">
                            <img class="border radius w-100" src="{{$best->featured_image}}"
                                 alt="{{__('clinic.best')}} {{$best->name}}">
                            <p class="position-absolute btn-btcenter">{{__('clinics.best')}} {{$best->name}}</p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    @endif
    <div class="container mt-3">
        <div class="row">
            <div class="col-12">
                <div class="description text-justify px-3">{!! $lead !!}
                </div>
            </div>
        </div>
    </div>
    <section id="filter" class="mt-3">
        <div class="container clinic-compare d-flex flex-column position-relative justify-content-center">
            <div class="row justify-content-center">
                <form action="/clinics" method="POST" class="text-center">
                    @method('POST')
                    @csrf
                    <div class="form-group">
                        <label for="treatment" class="form-label mb-1">{{__('form.treatment')}}</label>
                        <select class="form-control form-control-sm radius" name="treatment" id="treatment">
                            @foreach (\App\Procedure::where('type','treatment')->get() as $treat)
                                <option
                                    value="{{$treat->id}}" {{  app('request')->input('treatment') == $treat->id ? 'checked' :'' }} >
                                    {{ $treat->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="city" class="form-label mb-1">{{__('form.city')}}</label>
                        <select class="form-control form-control-sm radius" name="city" id="city">
                            @foreach (\App\City::all() as $city)
                                <option
                                    value="{{$city->id}}" {{  app('request')->input('city') == $city->id ? 'checked' :'' }} >
                                    {{ $city->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="facilities" class="form-label mb-1">{{__('form.facilities')}}</label>
                        <select class="form-control form-control-sm radius" name="facilities" id="facilities">
                            @foreach (\App\Facilitator::all() as $facilities)
                                <option
                                    value="{{$facilities->id}}" {{  app('request')->input('facilities') == $facilities->id ? 'checked' :'' }} >
                                    {{ $facilities->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="language" class="form-label mb-1">{{__('form.language')}}</label>
                        <select class="form-control form-control-sm radius" name="language" id="language" type="text"
                                value="{{  app('request')->input('language') or old('language') }}">
                            @foreach (['ar','en','fa','es'] as $lang)
                                <option
                                    value="{{$lang}}" {{  app('request')->input('lang') == $lang ? 'checked' :'' }} >
                                    {{ __('home.language.'.$lang) }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="price" class="form-label mb-1">{{__('form.price')}}</label>
                        <input class="form-control form-control-sm radius" name="price" id="price"
                               type="text" vale="{{  app('request')->input('price') or old('price') }}" >
                    </div>
                    <div class="form-group">
                        <label for="rate" class="form-label mb-1">{{__('form.rate')}}</label>
                        <input class="form-control form-control-sm radius" name="rate" id="rate"
                               type="text" value=" {{  app('request')->input('rate') or old('rate') }}" >
                    </div>
                    <div class="form-group">


                                    <label class="form-label form-check-label w-100 d-flex align-items-center justify-content-center form-check p-0"
                                           for="facilitator">{{__('form.facilitator')}}
                                        <input class="form-check-input" type="checkbox" name="facilitator"
                                               id="facilitator"
                                               value="1" {{  app('request')->input('facilitator')or '' }} >
                                        <span class="form-check-sign">
                                <span class="check"></span>
                              </span>
                                    </label>



                    </div>
                    <div class="position-absolute btn-btcenter">
                        <button type="submit" class="tripo-btn btn-white text-nowrap">
                            {{__('home.find_button')}}
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </section>
    <section id="clinics-result">
        <div class="container">
            <div class="row">
                <div class="section-head d-flex justify-content-center hr">
                    <h2 class="px-1">@php echo trans_choice('clinics.result_title', $type,['count' =>count($clinics)]) @endphp</h2>
                </div>
            </div>

            @isset($clinics)
                <form action="/clinic-compare" method="post" enctype="multipart/form-data">
                    @method('POST')
                    @csrf
                    <ul class="clinics-list list-unstyled">
                        @foreach ($clinics as $clinic)
                            <li class="result-item row mb-3 align-items-center">
                                <div class="col-4">
                                    <a href="/clinics/{{$clinic->id}}">
                                        <img src="{{$clinic->logo}}" alt="{{$clinic->name}}">
                                    </a>
                                </div>

                                <div class="col-8 details p-1">
                                    <p class="name"><a
                                            href="/clinics/{{$clinic->id}}">{{$clinic->name}}</a>
                                    </p>
                                    <p class="excerpt"> {{ $clinic->procedures->first()['name']}}</p>
                                    <div class="row align-items-center justify-content-between m-0">
                                        <div class="location btn-green py-1 px-3"><span
                                                class="flaticon-location"></span>{{$clinic->city['name']}}</div>
                                        <span class="rate"><i class="icon icon-star"></i></span>

                                            <div class="form-check">
                                                <label class="form-check-label"
                                                   for="clinics[]">
                                                    <input class="form-check-input" type="checkbox" name="clinics[]"
                                                       id="clinic-{{$clinic->id}}"
                                                       value="{{$clinic->id}}">
                                                    <span class="form-check-sign">
                                                        <span class="check"></span>
                                                    </span>
                                                </label>

                                            </div>
                                    </div>
                                </div>
                            </li>
                        @endforeach
                    </ul> @error('clinics')
                    <span class="small ">{{__('clinics.compare_warning')}}</span>
                    @enderror
                    <button type="submit" class="compare"></button>
                </form>
            @endisset
            @unless ($clinics)

            @endunless
        </div>
    </section>
    @include('partial.advice')
    @include('partial.social')

@endsection

@endif
