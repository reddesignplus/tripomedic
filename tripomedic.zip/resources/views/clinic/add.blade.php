@extends('admin.layouts.app', ['activePage' => 'clinic', 'titlePage' => __('home.clinic')])

@section('content')
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title ">{{__('home.add_clinic')}}</h4>
                            <p class="card-category">{{__('home.treatments_sub')}}</p>
                        </div>
                        <div class="card-body">
                            <form action="{{route('admin.clinics.store')}}"
                                  method="post" enctype="multipart/form-data">
                                @method('PUT')
                                @csrf

                                <div class="form-row my-5">
                                    <div class="form-group col">
                                        <label for="name">{{__('home.name')}}</label>
                                        <input type="text" class="form-control" id="name" name="name"
                                               value="{{old('name')}}" placeholder="">
                                        @error('name')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group col">
                                        <label for="alias">{{__('home.alias')}}</label>
                                        <input type="text" class="form-control" id="alias" name="alias"
                                               value="{{old('alias')}}">
                                        @error('alias')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="form-row my-5">
                                    <div class="form-group col">
                                        <label for="excerpt">{{__('home.excerpt')}}</label>
                                        <input type="text" class="form-control" id="excerpt" name="excerpt"
                                               value="{{old('excerpt')}}">
                                    </div>
                                    @error('excerpt')
                                    <div class="alert alert-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-3">
                                        <label for="city_code">{{__('home.cities')}}</label>
                                        <select class="form-control" id="city_code" name="city_code">
                                            @foreach ( \App\City::all() as $option)
                                                <option value="{{$option->city_code}}">{{$option->name}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    @error('city_code')
                                    <div class="alert alert-danger">{{ $message }}</div>
                                    @enderror
                                    <div class="form-group col-3">
                                        <label for="hospital_id">{{__('home.hospitals')}}</label>
                                        <select class="form-control" id="hospital_id" name="hospital_id">
                                            <option value="">----</option>
                                            @foreach ( \App\Hospital::all() as $option)
                                                <option value="{{$option->id}}">{{$option->name}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    @error('hospital_id')
                                    <div class="alert alert-danger">{{ $message }}</div>
                                    @enderror
                                    <div class="form-group col-3">
                                        <label for="languages">{{__('home.languages')}}</label>
                                        <select class="form-control" id="languages" name="languages">
                                            {{--                                            @foreach ( \App\Hospital::all() as $option)--}}
                                            {{--                                                <option value="{{$option->id}}">{{$option->name}}</option>--}}
                                            {{--                                            @endforeach--}}
                                        </select>
                                    </div>
                                    @error('languages')
                                    <div class="alert alert-danger">{{ $message }}</div>
                                    @enderror

                                </div>
                                <div class="form-row my-5">
                                    <div class="form-group col">
                                        <label for="address">{{__('home.address')}}</label>
                                        <input type="text" class="form-control" id="address" name="address"
                                               value="{{old('address')}}">
                                    </div>
                                    @error('address')
                                    <div class="alert alert-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-row my-5">
                                    <div class="form-group col">
                                        <label for="location">{{__('home.location')}}</label>
                                        <input type="text" class="form-control" id="location" name="location"
                                               value="{{old('location')}}">
                                    </div>
                                    @error('location')
                                    <div class="alert alert-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-row">
                                    <div class="form-group pt-3">
                                        <label for="description">{{__('home.description')}}</label>
                                        <textarea class="form-control description" id="description" name="description"
                                                  rows="3">{{old('description')}}</textarea>
                                    </div>
                                    @error('description')
                                    <div class="alert alert-danger">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="form-row">

                                    <div class="form-group col">
                                        <label for="tel">{{__('home.tel')}}</label>
                                        <input type="text" class="form-control" id="tel" name="tel"
                                               value="{{old('tel')}}">
                                        @error('tel')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
                                    </div>

                                    <div class="form-group col">
                                        <label for="website">{{__('home.website')}}</label>
                                        <input type="text" class="form-control" id="website" name="website"
                                               value="{{old('website')}}">
                                        @error('website')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
                                    </div>

                                    <div class="form-group col">
                                        <label for="email">{{__('home.email')}}</label>
                                        <input type="email" class="form-control" id="email" name="email"
                                               value="{{old('email')}}">
                                        @error('email')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col">
                                        <label for="certificate">{{__('home.certificate')}}</label>
                                        <input type="text" class="form-control" id="certificate" name="certificate"
                                               value="{{old('certificate')}}">
                                        @error('certificate')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group col">
                                        <label for="services">{{__('home.services')}}</label>
                                        <input type="text" class="form-control" id="services" name="services"
                                               value="{{old('services')}}">
                                        @error('services')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>


                                <div class="fileinput fileinput-new text-center col-3" data-provides="fileinput">
                                    <div class="fileinput-new thumbnail img-raised">
                                        <img src="{{old('featured_image')}}">
                                    </div>
                                    <div class="fileinput-preview fileinput-exists thumbnail img-raised"></div>
                                    <div class="col-3">
                                        <span class="btn btn-raised btn-round btn-default btn-file">
            <span class="fileinput-new">Select image</span>
            <span class="fileinput-exists">Change</span>
            <input type="file" name="featured_image"/>
                                              @error('featured_image')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
        </span>
                                        <a href="#pablo" class="btn btn-danger btn-round fileinput-exists"
                                           data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                    </div>
                                </div>
                                <div class="form-group form-file-upload form-file-multiple">
                                    <input type="file" multiple="" class="inputFileHidden">
                                    <div class="input-group">
                                        <input type="text" class="form-control inputFileVisible"
                                               placeholder="Multiple Files" multiple name="gallery">
                                        <span class="input-group-btn">
            <button type="button" class="btn btn-fab btn-round btn-info">
                <i class="material-icons">layers</i>
            </button>
        </span>
                                        @error('gallery')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="togglebutton">
                                    <label>
                                        <span>{{__('home.featured')}}</span>
                                        <input type="checkbox"
                                              name="featured">
                                        <span class="toggle"></span>
                                    </label>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-3">
                                        <label for="created_at">{{__('home.created')}}</label>
                                        <input class="form-control" type="text"
                                               value="{{now()}}"
                                               readonly>
                                    </div>
                                    <div class="form-group col-3">
                                        <label for="created_at">{{__('home.updated')}}</label>
                                        <input class="form-control" type="text"
                                               value="{{now()}}"
                                               readonly>
                                    </div>
                                </div>
                                <div class="form-row float-right">
                                    <button type="submit" class="btn btn-primary">{{__('home.add_new')}}</button>
                                    <a href="{{route('admin.clinics')}}" class="btn btn-danger">{{__('home.cancel')}}</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
