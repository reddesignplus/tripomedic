@extends('layouts.app')

@section('content')

    <section id="inquiry">
        <div class="d-flex justify-content-center form-title mb-3">{{$inquiry->title}}</div>
        <div class="container d-flex inquiry justify-content-center position-relative">
            <div class="row align-items-center">
                <form action="/inquiry" method="post" class="text-center">
                    @csrf
                    <div class="form-group">
                        <label for="name" class="form-label">{{__('form.name')}}</label>
                        <input type="text" name="name" id="name" class="form-control radius"/>
                    </div>
                    <div class="form-group">
                        <label for="email" class="form-label">{{__('form.email')}}</label>
                        <input id="email" type="email"
                               class="form-control radius @error('email', 'login') is-invalid @enderror">

                        @error('email', 'login')
                        <div class="alert alert-danger">{{ __('form.error.email') }}</div>
                        @enderror
                    </div>
                    <div class="form-group">
                        <label for="treatment" class="form-label mb-1">{{__('form.treatment')}}</label>
                        <select class="form-control form-control-sm radius" name="treatment" id="treatment">
                            @foreach (\App\Treatment::all() as $treat)
                                <option
                                    value="{{$treat->id}}" {{  app('request')->input('treatment') == $treat->id ? 'checked' :'' }} >
                                    {{ $treat->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="city" class="form-label mb-1">{{__('form.city')}}</label>
                        <select class="form-control form-control-sm radius" name="city" id="city">
                            @foreach (\App\City::all() as $city)
                                <option
                                    value="{{$city->id}}" {{  app('request')->input('city') == $city->id ? 'checked' :'' }} >
                                    {{ $city->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="position-absolute btn-btcenter">
                        <button type="submit" class="tripo-btn btn-white text-nowrap">
                            {{__('form.submit_inquiry')}}
                        </button>
                    </div>

                </form>
            </div>
        </div>   </section>
    <section>
        <div class="container">
            <div class="row">
                <div class="col-12 description">
                    {!! $inquiry->content !!}
                </div>

            </div>
        </div>
    </section>



    @include('partial.advice')
    @include('partial.social')
@stop
