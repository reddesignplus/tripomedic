@extends('layouts.app')

@section('content')

    @include('partial.advice')

    @include('partial.social')
@endsection
