@extends('admin.layouts.app', ['activePage' => $procedure->type, 'titlePage' => __('home.treatments')])

@section('content')
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">

                        <form action="{{route('admin.treatments.update',['procedure'=>$procedure])}}"
                              method="post" enctype="multipart/form-data">
                            @method('PUT')
                            @csrf
                            <div class="card-header card-header-tabs card-header-primary">
                                <div class="nav-tabs-navigation">
                                    <div class="nav-tabs-wrapper">
                                        <span class="nav-tabs-title"> {{$procedure->name}}</span>
                                        <ul class="nav nav-tabs" data-tabs="tabs">
                                            <li class="nav-item">
                                                <a class="nav-link active" href="#content" data-toggle="tab">
                                                    <i class="material-icons">file_copy</i> Content
                                                    <div class="ripple-container"></div>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" href="#images" data-toggle="tab">
                                                    <i class="material-icons">collections</i> Images
                                                    <div class="ripple-container"></div>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" href="#details" data-toggle="tab">
                                                    <i class="material-icons">details</i> Details
                                                    <div class="ripple-container"></div>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="card-body">
                                <div class="tab-content">
                                    <div class="tab-pane active" id="content">

                                        <input type="hidden" value="{{$procedure->type}}">
                                        <div class="form-row">
                                            <div class="form-group col-3">
                                                <label for="created_at">{{__('home.created')}}</label>
                                                <input class="form-control" type="text"
                                                       placeholder="    {{$procedure->created_at->format('Y,M,j - H:i')}}"
                                                       readonly>
                                            </div>
                                            <div class="form-group col-3">
                                                <label for="created_at">{{__('home.updated')}}</label>
                                                <input class="form-control" type="text"
                                                       placeholder="    {{$procedure->updated_at->format('Y,M,j - H:i')}}"
                                                       readonly>
                                            </div>
                                        </div>
                                        <div class="form-row my-5">
                                            <div class="form-group col">
                                                <label for="name">{{__('home.name')}}</label>
                                                <input type="text" class="form-control" id="name" name="name"
                                                       value="{{old('name') ?? $procedure->name}}" placeholder="">
                                                @error('name')
                                                <div class="alert alert-danger">{{ $message }}</div>
                                                @enderror
                                            </div>
                                            <div class="form-group col">
                                                <label for="alias">{{__('home.alias')}}</label>
                                                <input type="text" class="form-control" id="alias" name="alias"
                                                       value="{{old('alias') ?? $procedure->alias}}">
                                                @error('alias')
                                                <div class="alert alert-danger">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>
                                        <div class="form-row my-5">
                                            <div class="form-group col">
                                                <label for="excerpt">{{__('home.excerpt')}}</label>
                                                <input type="text" class="form-control" id="excerpt" name="excerpt"
                                                       value="{{$procedure->excerpt}}">
                                            </div>
                                        </div>

                                        <div class="form-row"> @if ($procedure->type == 'procedure')
                                                <div class="form-group col-3">
                                                    <label for="treatparent">{{__('home.treatments')}}</label>
                                                    <select class="form-control" id="treatparent" name="parent">
                                                        @foreach ( \App\Procedure::where('type','treatment')->get() as $option)
                                                            <option
                                                                value="{{$option->id}}" {{$option->id == $procedure->parent ? "selected" :''}}>{{$option->name}}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                                @error('parent')
                                                <div class="alert alert-danger">{{ $message }}</div>
                                                @enderror
                                            @endif
                                            <div class="input-group">
                                                <label for="icon">{{__('home.icon')}}</label>
                                                <div class="input-group-append"><span class="input-group-text"><i
                                                            class="fa fa-group"></i></span></div>
                                                <input type="text" class="form-control"
                                                       value="{{old('icon') ?? $procedure->icon}}" name="icon">
                                                @error('icon')
                                                <div class="alert alert-danger">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>

                                        <div class="form-row">
                                            <div class="form-group pt-3">
                                                <label for="description">{{__('home.description')}}</label>
                                                <textarea class="form-control description" id="description"
                                                          name="description"
                                                          rows="3">{{old('description') ?? $procedure->description}}</textarea>
                                            </div>
                                            @error('description')
                                            <div class="alert alert-danger">{{ $message }}</div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="tab-pane" id="images">
                                        <div class="fileinput fileinput-new text-center col-3"
                                             data-provides="fileinput">
                                            <div class="fileinput-new thumbnail img-raised">
                                                <img src="{{$procedure->featured_image}}" alt="{{$procedure->name}}">
                                            </div>
                                            <div class="fileinput-preview fileinput-exists thumbnail img-raised"></div>
                                            <div class="col-3">
                                        <span class="btn btn-raised btn-round btn-default btn-file">
            <span class="fileinput-new">Select image</span>
            <span class="fileinput-exists">Change</span>
            <input type="file" name="featured_image"/>
                                              @error('featured_image')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
        </span>
                                                <a href="#pablo" class="btn btn-danger btn-round fileinput-exists"
                                                   data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                            </div>
                                        </div>
                                        <div class="form-group form-file-upload form-file-multiple">
                                            <input type="file" multiple="" class="inputFileHidden">
                                            <div class="input-group">
                                                <input type="text" class="form-control inputFileVisible"
                                                       placeholder="Multiple Files" multiple name="gallery">
                                                <span class="input-group-btn">
            <button type="button" class="btn btn-fab btn-round btn-info">
                <i class="material-icons">layers</i>
            </button>
        </span>
                                                @error('gallery')
                                                <div class="alert alert-danger">{{ $message }}</div>
                                                @enderror
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane" id="details">
                                        @if ($procedure->type == 'procedure')
                                            <div class="togglebutton">
                                                <label>
                                                    <span>{{__('home.featured')}}</span>
                                                    <input type="checkbox"
                                                           {{$procedure->featured || old('featured') == 'on' ? 'checked' : ''}} name="featured">
                                                    <span class="toggle"></span>
                                                </label>
                                            </div>
                                            <div class="form-row">
                                                <div class="form-group col">
                                                    <label for="gender">{{__('home.gender')}}</label>
                                                    <div class="form-check form-check-radio">
                                                        <label class="form-check-label">
                                                            <input class="form-check-input" type="radio" name="gender"
                                                                   id="men"
                                                                   value="men" {{old('gender')  || $procedure->gender =='men'? 'checked' : ''}}>{{__('doctors.men')}}
                                                            <span class="circle"><span class="check"></span></span>
                                                        </label>

                                                    </div>
                                                    <div class="form-check form-check-radio">
                                                        <label class="form-check-label">
                                                            <input class="form-check-input" type="radio" name="gender"
                                                                   id="women"
                                                                   value="women" {{old('gender')  || $procedure->gender =='women' ? 'checked' : ''}}>{{__('doctors.women')}}
                                                            <span class="circle"><span class="check"></span></span>
                                                        </label>
                                                    </div>
                                                </div>

                                                <div class="form-group col">
                                                    <label for="age">{{__('home.age')}}</label>
                                                    <div class="form-check form-check-radio ">
                                                        <label class="form-check-label">
                                                            <input class="form-check-input" type="radio" name="age"
                                                                   id="child"
                                                                   value="child" {{old('age') || $procedure->age =='child'? 'checked' : ''}}>{{__('doctors.child')}}
                                                            <span class="circle"><span class="check"></span></span>
                                                        </label>
                                                    </div>
                                                    <div class="form-check form-check-radio">
                                                        <label class="form-check-label">
                                                            <input class="form-check-input" type="radio" name="age"
                                                                   id="adult"
                                                                   value="adult" {{old('age') || $procedure->age =='adult'? 'checked' : ''}}>{{__('doctors.adult')}}
                                                            <span class="circle"><span class="check"></span></span>
                                                        </label>
                                                    </div>

                                                </div>
                                            </div>
                                        @endif
                                    </div>

                                    <div class="card-footer justify-content-end">
                                        <div class="form-row float-right">
                                            <button type="submit" class="btn btn-primary">{{__('home.update')}}</button>
                                            <a href="{{route('admin.treatments')}}"
                                               class="btn btn-danger">{{__('home.cancel')}}</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
@endsection
