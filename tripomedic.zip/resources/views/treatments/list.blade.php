@extends('admin.layouts.app', ['activePage' => $type.'s', 'titlePage' => __('home.treatments')])

@section('content')
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title ">{{$title}}</h4>
                            <p class="card-category">{{__('home.treatments_sub')}}</p>
                        </div>
                        <div class="card-body">
                            <div class="actions float-right">
                                <a class="btn btn-primary" href="{{route('admin.treatments.create',['type'=>$type])}}">{{__('home.add_new')}}</a>
                            </div>

                            <div class="table-responsive">

                                <table class="table table-hover">

                                    <thead class=" text-primary">
                                    <th>
                                        ID
                                    </th>
                                    <th>

                                    </th>

                                    <th>
                                        {{__("home.name")}}

                                    </th>
                                    @if ($treatments[0]->parent)
                                        <th>{{__("treatment.treat")}}</th>
                                    @endif
                                    <th>
                                       <p>{{__("home.description")}}</p>
                                    </th>

                                    <th>
                                        {{__("home.action")}}
                                    </th>
                                    </thead>

                                    <tbody>
                                    @foreach($treatments as $item)
                                        <tr>
                                            <td>
                                                {{$item->id}}
                                            </td>
                                            <td>
                                                <button  type="button" class="btn btn-fab btn-fab-mini btn-round {{$item->featured == 'on' ? 'btn-warning' : 'btn-default'}}">
                                                    <i class="material-icons">star</i>
                                                </button>
                                            </td>
                                            <td>
                                               <p class="m-0"> <a href="{{ route('admin.treatments.edit', ['procedure'=> $item->id]) }}"> <span class="{{$item->icon }}"></span>
                                                {{$item->name}}</a></p>
                                                <span class="badge badge-pill badge-primary">{{$item->clinic}}</span>
                                            </td>
                                            @if ($item->parent)
                                                <th class="text-center">{{\App\Procedure::find($item->parent)->name}}</th>
                                            @endif
                                            <td>
                                                {{ Str::limit($item->excerpt,70)}}
                                            </td>

                                            <td>

                                                <button type="button" class="btn btn-fab  btn-fab-mini btn-round btn-primary">
                                                    <i class="material-icons">edit</i>
                                                </button>
                                                <button type="button" class="btn btn-fab  btn-fab-mini btn-round btn-outline-danger">
                                                    <i class="material-icons">delete</i>
                                                </button>
                                            </td>

                                        </tr>
                                    @endforeach
                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
