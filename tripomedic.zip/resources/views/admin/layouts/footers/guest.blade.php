<footer class="footer">
    <div class="container">
        <nav class="float-left">
        <ul>
            <li>
            <a href="https://www.tripomedic.com">
                {{ __('tripomedic') }}
            </a>
            </li>
            <li>
            <a href="https://www.tripomedic.com/about">
                {{ __('home.about-us') }}
            </a>
            </li>
            <li>
            <a href="http://www.tripomedic.com/blog">
                {{ __('home.blog') }}
            </a>
            </li>
            <li>
            <a href="https://www.tripomedic.com/license">
                {{ __('Licenses') }}
            </a>
            </li>
        </ul>
        </nav>
        <div class="copyright float-right">
        &copy;
        <script>
            document.write(new Date().getFullYear())
        </script>, made with <i class="material-icons">favorite</i> by
        <a href="https://www.tripomedic.com" target="_blank">TripoMedic </a> and <a href="https://www.reddesign.studio" target="_blank">Red Design Studio</a>
        </div>
    </div>
</footer>
