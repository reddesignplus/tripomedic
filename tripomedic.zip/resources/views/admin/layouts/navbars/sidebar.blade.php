<div class="sidebar" data-color="blue" data-background-color="white"
     data-image="{{ asset('material') }}/img/sidebar-1.jpg">
    <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
    <div class="logo">
        <a href="https://tripomedic.com/" class="simple-text logo-normal">
            {{ __('TripoMedic') }}
        </a>
    </div>
    <div class="sidebar-wrapper">
        <ul class="nav">
            <li class="nav-item{{ $activePage == 'dashboard' ? ' active' : '' }}">
                <a class="nav-link" href="{{ route('admin.dashboard') }}">
                    <i class="material-icons">dashboard</i>
                    <p>{{ __('Dashboard') }}</p>
                </a>
            </li>
            <li class="nav-item{{ $activePage == 'hospitals' ? ' active' : '' }}">
                <a class="nav-link" href="{{ route('admin.hospitals') }}">
                    <i class="material-icons">description</i>
                    <p>{{ __('home.hospitals') }}</p>
                </a>
            </li>
            <li class="nav-item{{ $activePage == 'clinics' ? ' active' : '' }}">
                <a class="nav-link" href="{{ route('admin.clinics') }}">
                    <i class="material-icons">dns</i>
                    <p>{{ __('home.clinics') }}</p>
                </a>
            </li>
            <li class="nav-item{{ $activePage == 'doctors' ? ' active' : '' }}">
                <a class="nav-link" href="{{ route('admin.doctors') }}">
                    <i class="material-icons">event_seat</i>
                    <p>{{ __('home.doctors') }}</p>
                </a>
            </li>
            <li class="nav-item {{ ($activePage == 'treatments' || $activePage == 'procedures') ? ' active' : '' }}">
                <a class="nav-link" data-toggle="collapse" href="#laravelExample" aria-expanded="true">
                    <i class="material-icons">content_paste</i>
                    <p>{{ __('home.treatments') }}
                        <b class="caret"></b>
                    </p>
                </a>
                <div class="collapse show" id="laravelExample">
                    <ul class="nav">
                        <li class="nav-item{{ $activePage == 'treatments' ? ' active' : '' }}">
                            <a class="nav-link" href="{{ route('admin.treatments') }}">
                                <span class="sidebar-mini"> TR </span>
                                <span class="sidebar-normal">{{ __('treatment.treatment') }} </span>
                            </a>
                        </li>
                        <li class="nav-item{{ $activePage == 'procedures' ? ' active' : '' }}">
                            <a class="nav-link" href="{{ route('admin.procedures') }}">
                                <span class="sidebar-mini"> PR </span>
                                <span class="sidebar-normal"> {{ __('home.procedures') }} </span>
                            </a>
                        </li>
                    </ul>
                </div>
            </li>

            <li class="nav-item{{ $activePage == 'cities' ? ' active' : '' }}">
                <a class="nav-link" href="{{ route('admin.cities') }}">
                    <i class="material-icons">eco</i>
                    <p>{{ __('home.cities') }}</p>
                </a>
            </li>
            <li class="nav-item{{ $activePage == 'facilitators' ? ' active' : '' }}">
                <a class="nav-link" href="{{ route('admin.facilitators') }}">
                    <i class="material-icons">extension</i>
                    <p>{{ __('home.facilitator') }}</p>
                </a>
            </li>
            <li class="nav-item{{ $activePage == 'blog' ? ' active' : '' }}">
                <a class="nav-link" href="{{ route('admin.blog') }}">
                    <i class="material-icons">explore</i>
                    <p>{{ __('home.blog') }}</p>
                </a>
            </li>

            <li class="nav-item{{ $activePage == 'credit' ? ' active' : '' }}">
                <a class="nav-link" href="{{ route('admin.credit') }}">
                    <i class="material-icons">dollar</i>
                    <p>{{ __('home.credit') }}</p>
                </a>
            </li>
            @if (0)
                <li class="nav-item {{ ($activePage == 'profile' || $activePage == 'user-management') ? ' active' : '' }}">
                    <a class="nav-link" data-toggle="collapse" href="#laravelExample" aria-expanded="true">
                        <i><img style="width:25px" src="{{ asset('material') }}/img/laravel.svg"></i>
                        <p>{{ __('Laravel Examples') }}
                            <b class="caret"></b>
                        </p>
                    </a>
                    <div class="collapse show" id="laravelExample">
                        <ul class="nav">
                            <li class="nav-item{{ $activePage == 'profile' ? ' active' : '' }}">
                                <a class="nav-link" href="{{ route('admin.profile.edit') }}">
                                    <span class="sidebar-mini"> UP </span>
                                    <span class="sidebar-normal">{{ __('User profile') }} </span>
                                </a>
                            </li>
                            <li class="nav-item{{ $activePage == 'user-management' ? ' active' : '' }}">
                                <a class="nav-link" href="{{ route('admin.user.index') }}">
                                    <span class="sidebar-mini"> UM </span>
                                    <span class="sidebar-normal"> {{ __('User Management') }} </span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
                <li class="nav-item{{ $activePage == 'typography' ? ' active' : '' }}">
                    <a class="nav-link" href="{{ route('admin.typography') }}">
                        <i class="material-icons">library_books</i>
                        <p>{{ __('Typography') }}</p>
                    </a>
                </li>
                <li class="nav-item{{ $activePage == 'icons' ? ' active' : '' }}">
                    <a class="nav-link" href="{{ route('admin.icons') }}">
                        <i class="material-icons">bubble_chart</i>
                        <p>{{ __('Icons') }}</p>
                    </a>
                </li>
                <li class="nav-item{{ $activePage == 'map' ? ' active' : '' }}">
                    <a class="nav-link" href="{{ route('admin.map') }}">
                        <i class="material-icons">location_ons</i>
                        <p>{{ __('Maps') }}</p>
                    </a>
                </li>
                <li class="nav-item{{ $activePage == 'notifications' ? ' active' : '' }}">
                    <a class="nav-link" href="{{ route('admin.notifications') }}">
                        <i class="material-icons">notifications</i>
                        <p>{{ __('Notifications') }}</p>
                    </a>
                </li>
                <li class="nav-item{{ $activePage == 'language' ? ' active' : '' }}">
                    <a class="nav-link" href="{{ route('admin.language') }}">
                        <i class="material-icons">language</i>
                        <p>{{ __('RTL Support') }}</p>
                    </a>
                </li>
            @endif
        </ul>
    </div>
</div>
