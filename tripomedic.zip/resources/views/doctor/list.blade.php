@extends('admin.layouts.app', ['activePage' => 'doctors', 'titlePage' => __('home.doctors')])

@section('content')
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title ">{{__('home.doctors')}}</h4>
                            <p class="card-category">{{__('home.doctors_sub')}}</p>
                        </div>
                        <div class="card-body">
                            <div class="actions float-right">
                                <a class="btn btn-primary" href="{{route('admin.doctors.create')}}">{{__('home.add_new')}}</a>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-hover">

                                    <thead class=" text-primary">
                                    <th>
                                        ID
                                    </th>   <th>
                                        {{__("home.featured")}}
                                    </th>
                                    <th>
                                        {{__("home.avatar")}}
                                    </th>

                                    <th>
                                        {{__("home.name")}}
                                    </th>
                                    <th>
                                        {{__("home.city")}}
                                    </th>

                                    <th>
                                        {{__("home.tel")}}
                                    </th>

                                    <th>
                                        {{__("home.action")}}
                                    </th>
                                    </thead>

                                    <tbody>
                                    @foreach(\App\Doctor::all() as $doctor)
                                        <tr>
                                            <td>
                                                {{$doctor->id}}
                                            </td>
                                            <td>
                                                <button  type="button" class="btn btn-fab btn-fab-mini btn-round {{$doctor->featured == 'on' ? 'btn-warning' : 'btn-default'}}">
                                                    <i class="material-icons">star</i>
                                                </button>
                                            </td>
                                            <td>
                                                <img src="{{$doctor->avatar }}" alt="{{$doctor->name}} {{$doctor->family}}">
                                            </td>
                                            <td>
                                               <p class="m-0"><a href="{{route('admin.doctors.edit',$doctor)}}">{{$doctor->name }} {{ $doctor->family}}</a></p>
                                                <sub> {{$doctor->procedures->first()['name']}}</sub>
                                            </td>
                                            <td>
                                               {{-- {{$doctor->procedures->first()->clinic->name}}--}}
                                            </td>
                                            <td>
                                                {{$doctor->tel}}
                                            </td>


                                            <td>

            <button type="button" class="btn btn-fab  btn-fab-mini btn-round btn-primary">
                <i class="material-icons">edit</i>
            </button>


            <button type="button" class="btn btn-fab  btn-fab-mini btn-round btn-outline-danger">
                <i class="material-icons">delete</i>
            </button>

                                            </td>

                                        </tr>
                                    @endforeach
                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
