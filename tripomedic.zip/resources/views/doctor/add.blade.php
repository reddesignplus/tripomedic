@extends('admin.layouts.app', ['activePage' => 'doctors', 'titlePage' => __('home.doctors')])

@section('content')
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title ">{{__('home.add_new')}}</h4>
                            <p class="card-category">{{__('home.doctors_sub')}}</p>
                        </div>
                        <div class="card-body">
                            <form action="{{route('admin.doctors.store')}}"
                                  method="post" enctype="multipart/form-data">
                                @method('PUT')
                                @csrf
                                <div class="form-row my-5">
                                    <div class="form-group col">
                                        <label for="name">{{__('home.name')}}</label>
                                        <input type="text" class="form-control" id="name" name="name"
                                               value="{{old('name')}}" placeholder="">
                                        @error('name')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group col">
                                        <label for="name">{{__('doctor.family')}}</label>
                                        <input type="text" class="form-control" id="family" name="family"
                                               value="{{old('family')}}" placeholder="">
                                        @error('family')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
                                    </div>
                                    <div class="form-group col">
                                        <label for="alias">{{__('home.alias')}}</label>
                                        <input type="text" class="form-control" id="alias" name="alias"
                                               value="{{old('alias')}}">
                                        @error('alias')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>
                                <div class="form-row my-5">
                                    <div class="form-group col">
                                        <label for="excerpt">{{__('home.excerpt')}}</label>
                                        <input type="text" class="form-control" id="excerpt" name="excerpt"
                                               value="{{old('grade')}}">
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group pt-3">
                                        <label for="description">{{__('home.description')}}</label>
                                        <textarea class="form-control description" id="description" name="description"
                                                  rows="3">{{old('description')}}</textarea>
                                    </div>
                                    @error('description')
                                    <div class="alert alert-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                                <div class="form-row">
                                    <div class="form-group col">
                                        <label for="address">{{__('home.address')}}</label>
                                        <input type="text" class="form-control" id="address" name="address"
                                               value="{{old('grade')}}">
                                    </div>
                                </div>
                                <div class="form-row">

                                    <div class="form-group col">
                                        <label for="tel">{{__('home.tel')}}</label>
                                        <input type="text" class="form-control" id="tel" name="tel"
                                               value="{{old('grade')}}">
                                    </div>

                                    <div class="form-group col">
                                        <label for="website">{{__('home.website')}}</label>
                                        <input type="text" class="form-control" id="website" name="website"
                                               value="{{old('grade')}}">
                                    </div>

                                    <div class="form-group col">
                                        <label for="email">{{__('home.email')}}</label>
                                        <input type="email" class="form-control" id="email" name="email"
                                               value="{{old('grade')}}">

                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col">
                                        <label for="certificate">{{__('home.certificate')}}</label>
                                        <input type="text" class="form-control" id="certificate" name="certificate"
                                               value="{{old('grade')}}">

                                    </div>
                                    <div class="form-group col">
                                        <label for="grade">{{__('home.grade')}}</label>
                                        <input type="text" class="form-control" id="grade" name="grade"
                                               value="{{old('grade')}}">

                                    </div>
                                </div>
                                <div class="fileinput fileinput-new text-center col-3" data-provides="fileinput">
                                    <div class="fileinput-new thumbnail img-raised">
                                    </div>
                                    <div class="fileinput-preview fileinput-exists thumbnail img-raised"></div>
                                    <div class="col-3">
                                        <span class="btn btn-raised btn-round btn-default btn-file">
            <span class="fileinput-new">Select image</span>
            <span class="fileinput-exists">Change</span>
            <input type="file" name="featured_image"/>
                                              @error('featured_image')
                                        <div class="alert alert-danger">{{ $message }}</div>
                                        @enderror
        </span>
                                        <a href="#pablo" class="btn btn-danger btn-round fileinput-exists"
                                           data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                    </div>
                                </div>

                                <div class="togglebutton">
                                    <label>
                                        <span>{{__('home.featured')}}</span>
                                        <input type="checkbox"
                                                {{old('featured') == 'on' ?'checked' :''}} name="featured">
                                        <span class="toggle"></span>
                                    </label>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col">
                                        <label for="gender">{{__('home.gender')}}</label>
                                        <div class="form-check form-check-radio">
                                            <label class="form-check-label">
                                                <input class="form-check-input" type="radio" name="gender" id="men"
                                                       value="men" {{old('gender')  =='men'? 'checked' : ''}}>{{__('doctors.men')}}
                                                <span class="circle"><span class="check"></span></span>
                                            </label>

                                        </div>
                                        <div class="form-check form-check-radio">
                                            <label class="form-check-label">
                                                <input class="form-check-input" type="radio" name="gender"
                                                       id="women"
                                                       value="women" {{old('gender')  =='women' ? 'checked' : ''}}>{{__('doctors.women')}}
                                                <span class="circle"><span class="check"></span></span>
                                            </label>
                                        </div>
                                    </div>

                                    <div class="form-group col">
                                        <label for="age">{{__('home.age')}}</label>
                                        <div class="form-check form-check-radio ">
                                            <label class="form-check-label">
                                                <input class="form-check-input" type="radio" name="age" id="child"
                                                       value="child" {{old('age')  =='child'? 'checked' : ''}}>{{__('doctors.child')}}
                                                <span class="circle"><span class="check"></span></span>
                                            </label>
                                        </div>
                                        <div class="form-check form-check-radio">
                                            <label class="form-check-label">
                                                <input class="form-check-input" type="radio" name="age"
                                                       id="adult"
                                                       value="adult" {{old('age')=='adult'? 'checked' : ''}}>{{__('doctors.adult')}}
                                                <span class="circle"><span class="check"></span></span>
                                            </label>
                                        </div>

                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col-3">
                                        <label for="created_at">{{__('home.created')}}</label>
                                        <input class="form-control" type="text"
                                              value="{{now()}}"
                                               readonly>
                                    </div>
                                    <div class="form-group col-3">
                                        <label for="created_at">{{__('home.updated')}}</label>
                                        <input class="form-control" type="text"
                                               value="{{now()}}"
                                               readonly>
                                    </div>
                                </div>
                                <div class="form-row float-right">
                                    <button type="submit" class="btn btn-primary">{{__('home.update')}}</button>
                                    <a href="{{route('admin.doctors')}}" class="btn btn-danger">{{__('home.cancel')}}</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
