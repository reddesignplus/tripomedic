@extends('layouts.app')

@section('content')

    <section id="filter" class="mt-3">
        <div class="container d-flex flex-column position-relative justify-content-center">
            <div class="row justify-content-center">
                <form action="/doctors" method="get">
                    <div class="form-group">
                        <label for="treatment" class="form-label">{{__('treatment.treatment')}}</label>
                        <select class="form-control form-control-sm radius" name="treatment" id="treatment">
                            @foreach (\App\Procedure::where('type','treatment')->get() as $treat)
                                <option value="{{$treat->id}}" {{  app('request')->input('treatment') == $treat->id ? 'checked' :'' }} >
                                    {{ $treat->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="treatment" class="form-label">{{__('treatment.treatment')}}</label>
                        <select class="form-control form-control-sm radius" name="treatment" id="treatment">
                            @foreach (\App\Procedure::where('type','procedure')->get() as $treat)
                                <option value="{{$treat->id}}" {{  app('request')->input('treatment') == $treat->id ? 'checked' :'' }} >
                                    {{ $treat->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="city" class="form-label">{{__('home.city')}}</label>
                        <select class="form-control form-control-sm radius" name="city" id="city">
                            @foreach (\App\City::all() as $city)
                                <option value="{{$city->city_code}}" {{  app('request')->input('treatment') == $city->id ? 'checked' :'' }} >
                                    {{ $city->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-row justify-content-around">
                            <div class="col-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gender" id="gender"
                                           value="men" {{  app('request')->input('gender') == 'men' ? 'checked' :'' }}>
                                    <label class="form-label" for="gender">{{__('doctors.men')}}</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gender" id="gender"
                                           value="women"  {{  app('request')->input('gender') == 'women' ? 'checked' :'' }}>
                                    <label class="form-label" for="gender">{{__('doctors.women')}}</label>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="age" id="age"
                                           value="child"  {{  app('request')->input('age') == 'child' ? 'checked' :'' }}>
                                    <label class="form-label" for="age">{{__('doctors.child')}}</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="age" id="age"
                                           value="adult"  {{  app('request')->input('age') == 'adult' ? 'checked' :'' }}>
                                    <label class="form-label" for="age">{{__('doctors.adult')}}</label>
                                </div>
                            </div>
                    </div>
                    <div class="position-absolute btn-btcenter">
                        <button type="submit" class="tripo-btn btn-white text-nowrap">
                            {{__('home.find_button')}}
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </section>
    <section id="doctors-result">
        <div class="container">
            <div class="row">
                <div class="section-head d-flex justify-content-center hr">
                    <h2 class="px-1">@php echo trans_choice(('doctors.result_title'), $type) @endphp</h2>
                </div>
            </div>

            @isset($doctors)
                <ul class="doctors-list list-unstyled">
                    @foreach ($doctors as $doctor)
                        <li class="result-item row">
                            <div class="col-4">
                                <a href="/doctors/{{$doctor->id}}">
                                    <img src="{{$doctor->avatar}}" alt="{{$doctor->name}}{{$doctor->family}}">
                                </a>
                            </div>
                            <div class="col-8 details p-1">
                                <p class="name"><a
                                        href="/doctors/{{$doctor->id}}">@php echo trans_choice(('doctors.gender'), $doctor->gender) @endphp {{$doctor->name}} {{$doctor->family}}</a>
                                </p>
                                <p class="excerpt"> {{ $doctor->procedures->first()['name'] }}</p>
                                <span class="location btn-green py-1 px-3"><span class="flaticon-location"></span>شـیـــراز </span>
                                <span class="rate"></span>
                            </div>
                        </li>
                    @endforeach
                </ul>
            @endisset
            @unless ($doctors)

            @endunless
            <div class="ads"><img src="/images/ads/image-01.png" alt=""></div>

        </div>
    </section>
    @include('partial.advice')
    <div class="row divider m-4"></div>
    @include('partial.blog',['class'=>'mt-2'])
    @include('partial.social')
@endsection
