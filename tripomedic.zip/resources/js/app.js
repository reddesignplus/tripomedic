window.Vue = require('vue');
require('./bootstrap');
require('./slider');
require('owl.carousel');
/*
//import ScrollSpy from "vue2-scrollspy";
//Vue.use(ScrollSpy);

//mohsen import StarRating from 'vue-star-rating';

 const files = require.context('./', true, /\.vue$/i)

 files.keys().map(key => Vue.component(key.split('/').pop().split('.')[0], files(key).default))

 Vue.component('rate-component', require('./components/RateComponent.vue').default);
*/
$("#special-carousel").owlCarousel(
    {
        center: true,
        autoWidth: true,
        margin:30,
        responsive:{
            0:{
                items: 1
            },
            600:{
                items: 2
            },
            1000:{
                items: 3
            }
        }
    }
);
$("#cities-carousel").owlCarousel(
    {
        center: true,
        autoWidth: true,
        margin:30,
        responsive:{
            0:{
                items: 1
            },
            600:{
                items: 2
            },
            1000:{
                items: 3
            }
        }
    }
);

/*$('#city_code').select2({
    placeholder: ('home.city_placeholder'),
    allowClear: true
});

$('#treatment').select2({
    placeholder:  ('home.treatment_placeholder'),
    allowClear: true
});
$('#treatment').select2({
    ajax: {
        url: 'https://api.github.com/search/repositories',
        dataType: 'json',
        placeholder: 'Search for a Treatments',
        minimumInputLength: 1,
    }
});*/

const app = new Vue({
    el: '#app',
});
