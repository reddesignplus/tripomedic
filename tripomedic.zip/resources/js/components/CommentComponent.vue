<template>
    <star-rating v-model="rating" v-bind:increment="0.5"
                 v-bind:max-rating="3"
                 inactive-color="#000"
                 active-color="#f00"
                 v-bind:star-size="90"></star-rating>
</template>

<script>
    export default {
        name: "CommentComponent"
    }
</script>

<style scoped>

</style>
