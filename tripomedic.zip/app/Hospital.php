<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hospital extends Model
{
    protected $fillable = [
        'name',
        'alias',
        'excerpt',
        'description',
        'address',
        'location',
        'city_code',
        'credit',
        'tel',
        'email',
        'website',
        'certificate',
        'services',
        'logo',
        'featured_image',
        // 'gallery',
        'featured',
    ];

    public function city()
    {
        return $this->belongsTo('App\City','city_code','');
    }
}
