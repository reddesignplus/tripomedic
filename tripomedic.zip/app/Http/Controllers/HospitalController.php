<?php

namespace App\Http\Controllers;

use App\Hospital;
use Illuminate\Http\Request;

class HospitalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('hospital.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //  dd($request->all());
        $data = request()->validate([
            'name'=> "required",
            'alias'=> "required",
            'excerpt'=> "required",
            'description'=> "required",
            'address'=> "nullable",
            'location'=> "nullable",
            'city_code'=> "nullable",
            'credit'=> "nullable",
            'tel'=> "nullable",
            'email'=> "nullable|email",
            'website'=> "nullable|url",
            'certificate'=> "nullable",
            'services'=> "nullable",
            'logo'=> "nullable",
            'featured_image'=> "image|nullable",
            'gallery'=> "image|nullable",
            'featured'=> "nullable",

        ]);

        $lastId  = Hospital::create([

            'name'=> $data['name'],
            'alias'=> $data['alias'],
            'excerpt'=>$data['excerpt'],
            'description'=>$data['description'],
            'address'=>$data['address'],
            'location'=>$data['location'],
            'city_code'=>$data['city_code'],
            'credit'=>$data['credit'],
            'tel'=> $data['tel'],
            'email'=> $data['email'],
            'website'=> $data['website'],
            'certificate'=> $data['certificate'],
            'services'=> $data['services'],
            'logo'=> $data['logo']?? '',
            'featured_image'=> $data['featured_image'] ?? '',
            'gallery'=> $data['gallery'] ?? '',
            'featured'=> $data['featured']
        ]);
        //   dd($lastId);
        return redirect(route('admin.hospitals.edit',$lastId->id));
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Hospital  $hospital
     * @return \Illuminate\Http\Response
     */
    public function show(Hospital $hospital)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Hospital  $hospital
     * @return \Illuminate\Http\Response
     */
    public function edit(Hospital $hospital)
    {

        return view('hospital.edit',compact('hospital'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Hospital  $hospital
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Hospital $hospital)
    {
         // dd($request->all());
        $data = request()->validate([
            'name'=> "required",
            'alias'=> "required",
            'excerpt'=> "required",
            'description'=> "required",
            'address'=> "nullable",
            'location'=> "nullable",
            'city_code'=> "nullable",
            'credit'=> "nullable",
            'tel'=> "nullable",
            'email'=> "nullable|email",
            'website'=> "nullable|url",
            'certificate'=> "nullable",
            'services'=> "nullable",
            'logo'=> "nullable",
            'featured_image'=> "image|nullable",
            'gallery'=> "image|nullable",
            'featured'=> "nullable",

        ]);

        $hospital->update($data);
        //  dd($data);
        return view('hospital.edit',compact('hospital'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Hospital  $hospital
     * @return \Illuminate\Http\Response
     */
    public function destroy(Hospital $hospital)
    {
        //
    }
}
