<?php

namespace App\Http\Controllers;

use App\City;
use App\Page;
use Illuminate\Http\Request;

class CityController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return void
     */
    public function index(Request $request)
    {
      // dd(City::find('021'));
        return view('cities.index',['cities'=>Page::where('alias','cities')->get()->first(),'city'=>City::find($request->input('c') ?? '21')]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('cities.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //  dd($request->all());
        $data = request()->validate([
            'name'=> "required",
            'alias'=> "required",
            'excerpt'=> "required",
            'description'=> "required",
            'location'=> "nullable",
            'city_code'=> "required|unique",
            'services'=> "nullable",
            'featured_image'=> "image|nullable",
            'gallery'=> "image|nullable",

        ]);

        $lastId  = City::create([

            'name'=> $data['name'],
            'alias'=> $data['alias'],
            'excerpt'=>$data['excerpt'],
            'description'=>$data['description'],
            'location'=>$data['location'],
            'city_code'=>$data['city_code'],
            'services'=> $data['services'],
          //  'featured_image'=> $data['featured_image'],
            'gallery'=> $data['gallery'],
        ]);
        //   dd($lastId);
        return redirect(route('admin.cities.edit',$lastId->id));
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\City  $city
     * @return \Illuminate\Http\Response
     */
    public function show(City $city)
    {
        return view('cities.profile',compact('city'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\City  $city
     * @return \Illuminate\Http\Response
     */
    public function edit(City $city)
    {
        return view('cities.edit',compact('city'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\City  $city
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, City $city)
    {
        $data = request()->validate([
            'name'=> "required",
            'alias'=> "required",
            'excerpt'=> "required",
            'description'=> "required",
            'location'=> "nullable",
            'city_code'=> "nullable",
            'services'=> "nullable",
            'featured_image'=> "image|nullable",
            'gallery'=> "image|nullable",

        ]);

        $city->update($data);
        //  dd($data);
        return view('cities.edit',compact('city'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\City  $city
     * @return \Illuminate\Http\Response
     */
    public function destroy(City $city)
    {
        //
    }
}
