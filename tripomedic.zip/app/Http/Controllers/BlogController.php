<?php

namespace App\Http\Controllers;

use App\Blog;
use App\Comment;
use Illuminate\Http\Request;

class BlogController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('blog.index',['blog'=> Blog::all()]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('blog.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        // dd($request->all());
        $data = request()->validate([
            'title'=> "required",
            'alias'=> "required",
            'excerpt'=> "required",
            'content'=> "required",
            'featured'=> "nullable",
        ]);

        //    dd($data);
        $lastId = Blog::create([
            'title'=> $data['title'],
            'alias'=> $data['alias'],
            'excerpt'=>$data['excerpt'],
            'content'=> $data['content'],
            'featured'=> $data['featured'] ?? '',
            'featured_image'=> $data['featured_image'] ?? '',


        ]);
        //   dd($lastId);
        return redirect(route('admin.blog.edit',$lastId->id));
    }

    /**
     * Display the specified resource.
     *
     * @param Blog $blog
     * @return \Illuminate\Http\Response
     */
    public function show(Blog $blog)
    {

        return view('blog.single',compact('blog'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Blog  $blog
     * @return \Illuminate\Http\Response
     */
    public function edit(Blog $blog)
    {
        return view('blog.edit',compact('blog'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Blog  $blog
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Blog $blog)
    {
     //   dd($request->all());
        $data = request()->validate([
            'title'=> "required",
            'alias'=> "required",
            'excerpt'=> "required",
            'content'=> "required",
            'published_date'=> "date",
            'expired_date'=> "nullable|date",
            'featured'=> "nullable",

        ]);

        $blog->update($data);
       // dd($data);
        return redirect(route('admin.blog.edit',$blog));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Blog  $blog
     * @return \Illuminate\Http\Response
     */
    public function destroy(Blog $blog)
    {
        //
    }
}
