<?php

namespace App\Http\Controllers;

use App\Facilitator;
use App\Page;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class FacilitatorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return Response
     */
    public function index(Request $request)
    {
        if ($request->method() == 'POST') {
            $facilitators = Facilitator::where('featured', 0)
                ->orderBy('name', 'desc')
                ->take(8)
                ->get();
            $type = 'result';
//            $blog = Blog::all();

        } else {
            $facilitators = Facilitator::where('featured', 0)->get();
            $type = 'default';
//            $blog = Blog::all();
        }
        $lead = Page::where('alias', 'facilitators')->first()->content;
        $bestOfMonth = Facilitator::where('featured', 0)->take(1)->first();
        return view('facilitators.index', [
            'facilitators' => $facilitators,
            'showTitle' => false,
            'showMore' => false,
            'type' => $type,
            'best' => $bestOfMonth,
            'lead' => $lead
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        return view('facilitators.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return Response
     */
    public function store(Request $request)
    {
      //  dd($request->all());

        $data = request()->validate([
            'name'=> "required",
            'alias'=> "required|unique",
            'excerpt'=> "required",
            'description'=> "required",
            'address'=> "nullable",
            'tel'=> "nullable",
            'email'=> "nullable|email",
            'website'=> "nullable|url",
            'certificate'=> "nullable",
            'services'=> "nullable",
            'credit'=> "required",
            'logo'=> "image|nullable",
            'featured_image'=> "image|nullable",
            'gallery'=> "image|nullable",
            'featured'=> "nullable",
        ]);

        //    dd($data);
        $lastId = Facilitator::create([
            'name'=> $data['name'],
            'alias'=> $data['alias'],
            'excerpt'=>$data['excerpt'],
            'description'=>$data['description'],
            'address'=>$data['address'],
            'tel'=> $data['tel'],
            'email'=> $data['email'],
            'website'=> $data['website'],
            'certificate'=> $data['certificate'],
            'services'=> $data['services'],
            'credit'=> $data['credit'],
            'logo'=> $data['logo'] ?? '',
            'featured_image'=> $data['featured_image'] ?? '',
            'gallery'=> $data['gallery'] ?? '',
            'featured'=> $data['featured'] ?? ''


        ]);
        //   dd($lastId);
        return redirect(route('admin.facilitators.edit',$lastId->id));
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Facilitator  $facilitator
     * @return Response
     */
    public function show(Facilitator $facilitator)
    {
      //  dd($facilitator->packages);
        return view('facilitators.profile',compact('facilitator'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Facilitator  $facilitator
     * @return Response
     */
    public function edit(Facilitator $facilitator)
    {
        return view('facilitators.edit',compact('facilitator'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Facilitator  $facilitator
     * @return Response
     */
    public function update(Request $request, Facilitator $facilitator)
    {
      //  dd($request->all());

        $data = request()->validate([
            'name'=> "required",
            'alias'=> "required",
            'excerpt'=> "required",
            'description'=> "required",
            'address'=> "nullable",
            'tel'=> "nullable",
            'email'=> "nullable|email",
            'website'=> "nullable|url",
            'certificate'=> "nullable",
            'services'=> "nullable",
            'credit'=> "required",
            'logo'=> "nullable",
            'featured_image'=> "image|nullable",
            'gallery'=> "image|nullable",
            'featured'=> "nullable",

        ]);

        $facilitator->update($data);
        // dd($data);
        return redirect(route('admin.facilitators.edit',$facilitator));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Facilitator  $facilitator
     * @return Response
     */
    public function destroy(Facilitator $facilitator)
    {
        //
    }
}
