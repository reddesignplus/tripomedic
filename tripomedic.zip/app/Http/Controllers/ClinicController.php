<?php

namespace App\Http\Controllers;


use App\Page;
use Illuminate\Http\Request;
use App\Clinic;
use Illuminate\Http\Response;

class ClinicController extends Controller
{

    /**
     * Display a listing of the resource for ADMINISTRATORS
     *
     * @return Response
     */

    public function admin()
    {
        return view('admin.index', ['objects' => Clinic::all()]);
    }


    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return Response
     */

    public function index(Request $request)
    {
        if ($request->method() == 'POST') {
            //  dd($request->all());
            $clinics = Clinic::where('featured', 0)
                ->orderBy('name', 'desc')
                ->take(8)
                ->get();
            $type = 'result';
//            $blog = Blog::all();

        } else {
            $clinics = Clinic::where('featured', 0)->get();
            $type = 'default';
//            $blog = Blog::all();
        }
        $lead = Page::where('alias', 'clinics')->first()->content;
        $bestOfMonth = Clinic::where('featured', 0)->take(1)->first();
        return view('clinic.index', [
            'clinics' => $clinics,
            'showTitle' => false,
            'showMore' => false,
            'type' => $type,
            'best' => $bestOfMonth,
            'lead' => $lead
        ]);
    }


    /**
     * Compare Selected Clinics
     *
     * @param Request $request
     * @return Response
     */
    public function compare(Request $request)
    {
        $request->validate([
            "clinics" => "required"
        ]);
        // dd($request->clinics);
        $clinics = array();
        foreach ($request->clinics as $clinic) {
            $clinics[] = Clinic::find($clinic);
        }

        //  dd($clinics);
        return view('clinic.compare', [
            'clinics' => $clinics,
            'showTitle' => false,
            'showMore' => false
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        return view('clinic.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param Request $request
     * @return void
     */
    public function store(Request $request)
    {
        //  dd($request->all());
        $data = request()->validate([
            'name' => "required",
            'alias' => "required",
            'excerpt' => "required",
            'description' => "required",
            'address' => "nullable",
            'location' => "nullable",
            'city_code' => "nullable",
            'hospital_id' => "nullable",
            'tel' => "nullable",
            'email' => "nullable|email",
            'website' => "nullable|url",
            'certificate' => "nullable",
            'services' => "nullable",
            'language' => "nullable",
            'logo' => "nullable",
            'featured_image' => "image|nullable",
            'gallery' => "image|nullable",
            'featured' => "nullable",

        ]);

        $lastId = Clinic::create([

            'name' => $data['name'],
            'alias' => $data['alias'],
            'excerpt' => $data['excerpt'],
            'description' => $data['description'],
            'address' => $data['address'],
            'location' => $data['location'],
            'city_code' => $data['city_code'],
            'hospital_id' => $data['hospital_id'],
            'tel' => $data['tel'],
            'email' => $data['email'],
            'website' => $data['website'],
            'certificate' => $data['certificate'],
            'services' => $data['services'],
            //  'language' => $data['language'],
            //   'logo' => $data['logo'],
            //   'featured_image' => $data['featured_image'],
            //    'gallery' => $data['gallery'],
            'featured' => $data['featured']
        ]);
        //  dd($data);
        return redirect(route('admin.clinics.edit', $lastId->id));
    }

    /**
     * Display the specified resource.
     *
     * @param Clinic $clinic
     * @return Response
     */
    public function show(Clinic $clinic)
    {


        //     dd($clinic->procedures);

        $treatments = array();
        foreach ($clinic->procedures as $key => $value):
            $treatments[$value['parent']][] = $value;
        endforeach;
        // dd($treatments);
        return view('clinic.profile', compact(['clinic', 'treatments']));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Clinic $clinic
     * @return Response
     */
    public function edit(Clinic $clinic)
    {
        return view('clinic.edit', compact('clinic'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param Clinic $clinic
     * @return Response
     */
    public function update(Request $request, Clinic $clinic)
    {
         dd($request->all());
        $data = request()->validate([
            'name' => "required",
            'alias' => "required",
            'excerpt' => "required",
            'description' => "required",
            'address' => "nullable",
            'location' => "nullable",
            'city_code' => "nullable",
            'hospital_id' => "nullable",
            'tel' => "nullable",
            'email' => "nullable|email",
            'website' => "nullable|url",
            'certificate' => "nullable",
            'services' => "nullable",
            'language' => "nullable",
            'logo' => "image|nullable",
            'featured_image' => "image|nullable",
            'gallery' => "image|nullable",
            'featured' => "nullable",

        ]);
        if ($request->featured_image)
        $featured_image = $request->featured_image->store('uploads/clinics/' . $request->alias, 'public');
        else  $featured_image = $clinic->featured_image;
        if ($request->logo)
        $logo = $request->logo->store('uploads/clinics/' . $request->alias, 'public');
        else $logo = $clinic->logo;
        $date['featured_image'] = '/storage/' . $featured_image;
        $date['logo'] = '/storage/' . $logo;
        $clinic->update([
            'name' => $data['name'],
            'alias' => $data['alias'],
            'excerpt' => $data['excerpt'],
            'description' => $data['description'],
            'address' => $data['address'] ?? '',
            'location' => $data['location']??'',
            'city_code' => $data['city_code'],
            'hospital_id' => $data['hospital_id'],
            'tel' => $data['tel'],
            'email' => $data['email'],
            'website' => $data['website'],
            'certificate' => $data['certificate'] ?? '',
            'services' => $data['services'] ?? '',
            'language' => $data['language'] ?? '',
            'logo' => $logo,
           'featured_image' => $featured_image,
         'gallery' => $gallery ?? '',
            'featured' => $data['featured']
        ]);
       // dd($date['featured_image']);
        return redirect(route('admin.clinics.edit', $clinic));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param Clinic $clinic
     * @return Response
     */

    public function destroy(Clinic $clinic)
    {
        //
    }
}
