<?php

namespace App\Http\Controllers;

use App\Blog;
use App\Comment;
use App\Doctor;
use Illuminate\Http\Request;

class DoctorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param Request $request
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if (!empty($request->input('treatment'))) {
            $doctors = Doctor::where('featured', 0)
                ->orderBy('name', 'desc')
                ->take(8)
                ->get();
            $blog = Blog::all();
            $type = 'result';
        } else {
            $doctors = Doctor::where('featured', 0)
                ->orderBy('name', 'desc')
                ->take(8)
                ->get();
            $type = 'default';
            $blog = Blog::find([1]);
        }

        return view('doctor.index', [
            'doctors' => $doctors,
            'showTitle' => false,
            'showMore' => false,
            'type' => $type,
            'blog' => $blog
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('doctor.add');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       //  dd($request->all());
        $data = request()->validate([
                'name'=> "required",
                'family'=> "required",
                'alias'=> "required",
                'excerpt'=> "required",
                'description'=> "required",
                'address'=> "nullable",
                'tel'=> "nullable",
                'email'=> "nullable|email",
                'website'=> "nullable|url",
                'certificate'=> "nullable",
                'grade'=> "nullable",
                'age'=> "nullable",
                'gender'=> "nullable",
                'avatar'=> "image",
                'featured'=> "nullable",
        ]);

        //    dd($data);
        $lastId = Doctor::create([
            'name'=> $data['name'],
            'family'=> $data['family'],
            'alias'=> $data['alias'],
            'excerpt'=>$data['excerpt'],
            'description'=> $data['description'],
            'address'=> $data['address'],
            'tel'=> $data['tel'],
            'website'=> $data['website'],
            'email'=> $data['email'],
            'certificate'=> $data['certificate'],
            'grade'=> $data['grade'],
            'gender'=> $data['gender'],
            'age'=> $data['age'],
            'avatar'=> '',
            'featured'=> $data['featured'],


        ]);
        //   dd($lastId);
        return redirect(route('admin.doctors.edit',$lastId->id));
    }

    /**
     * Display the specified resource.
     *
     * @param Doctor $doctor
     * @return \Illuminate\Http\Response
     */
    public function show(Doctor $doctor)
    {

        return view('doctor.profile', compact('doctor'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param \App\Doctor $doctor
     * @return \Illuminate\Http\Response
     */
    public function edit(Doctor $doctor)
    {
        return view('doctor.edit',compact('doctor'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param \App\Doctor $doctor
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Doctor $doctor)
    {
        $data = request()->validate([
            'name'=> "required",
            'family'=> "required",
            'alias'=> "required",
            'excerpt'=> "required",
            'description'=> "required",
            'address'=> "nullable",
            'tel'=> "nullable",
            'email'=> "nullable|email",
            'website'=> "nullable|url",
            'certificate'=> "nullable",
            'grade'=> "nullable",
            'age'=> "nullable",
            'gender'=> "nullable",
            'avatar'=> "image",
            'featured'=> "nullable",

        ]);

        $doctor->update($data);
        // dd($data);
        return redirect(route('admin.doctors.edit',$doctor));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param \App\Doctor $doctor
     * @return \Illuminate\Http\Response
     */
    public function destroy(Doctor $doctor)
    {
        //
    }
}
