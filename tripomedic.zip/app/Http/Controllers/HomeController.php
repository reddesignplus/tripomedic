<?php

namespace App\Http\Controllers;

use App\Blog;
use App\City;
use App\Package;
use App\Procedure;
use Illuminate\Contracts\Support\Renderable;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this;//->middleware('auth');
    }

    public function admin()
    {
        return view('admin.dashboard');
}

    /**
     * Show the application dashboard.
     *
     * @return Renderable
     */
    public function index()
    {
        return view('home', [
            'packages' => Package::all(),
            'cities' => $this->cities(),
            'treatments' => $this->treatments(),
            'blog' => $this->blog(),
            'showTitle' => true,
            'showMore' => true
        ]);
    }


    protected function treatments()
    {

        return Procedure::where('type','treatment')->get();
    }

    protected function cities()
    {

        return City::all();
    }

    protected function blog()
    {

        return Blog::all();
    }

}
