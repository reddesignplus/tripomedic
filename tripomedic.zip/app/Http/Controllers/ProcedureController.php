<?php

namespace App\Http\Controllers;

use App\Procedure;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class ProcedureController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @param $type
     * @return Response
     */
    public function create($type)
    {
        return view('treatments.add',compact('type'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return Response
     */
    public function store(Request $request)
    {
       // dd($request->all());
        $data = request()->validate([
            'type' =>'required',
            'name'=> "required",
            'alias'=> "required",
            'excerpt'=> "required",
            'description'=> "required",
            'parent'=>'required',
            'icon' => 'nullable'
        ]);

    //    dd($data);
       $lastId = Procedure::create([
           'type'=>$data['type'],
            'name'=> $data['name'],
            'alias'=> $data['alias'],
            'excerpt'=>$data['excerpt'],
            'description'=> $data['description'],
            'parent'=> $data['parent'],
            'icon'=> '',
            'featured_image'=> '',
            'gallery'=> '{}',
        /*    'featured'=> $data['featured'],
            'age'=> $data['age'],
            'gender'=> $data['gender'],
            'parent'=> $data['parent'],*/


        ]);
      //   dd($lastId);
        return redirect(route('admin.treatments.edit',$lastId->id));
    }

    /**
     * Display the specified resource.
     *
     * @param Procedure $procedure
     * @return void
     */
    public function show(Procedure $procedure)
    {
      //  dd($procedure->clinics()->city);
        $city = $procedure->clinics()->city;

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param Procedure $procedure
     * @return Response
     */
    public function edit(Procedure $procedure)
    {
        return view('treatments.edit', compact('procedure'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param Request $request
     * @param \App\Procedure $procedure
     * @return Response
     */
    public function update(Procedure $procedure)
    {

        $data = request()->validate([
            'name'=> "required",
            'alias'=> "required",
            'excerpt'=> "required",
            'description'=> "required",
            'icon'=> "nullable",
            'featured_image'=> "image",
            'featured'=> "nullable",
            'age'=> "nullable",
            'gender'=> "nullable",
            'parent'=> "nullable",
        ]);

        $procedure->update($data);
      // dd($data);
        return redirect(route('admin.treatments.edit',$procedure));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param \App\Procedure $procedure
     * @return Response
     */
    public function destroy(Procedure $procedure)
    {
        //
    }
}
