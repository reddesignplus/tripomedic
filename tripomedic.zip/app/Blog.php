<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Blog extends Model
{
    protected $fillable = [
        'title',
        'alias',
        'excerpt',
        'content',
        'published_date',
        'expired_date',
        'featured',
    ];

    public function procedures()
    {
return $this->belongsToMany('App\Procedure');
    }
}
