<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Procedure extends Model
{

protected $fillable = [
    'type',
    'name',
    'alias',
    'excerpt',
    'description',
    'parent',
    'icon',
    'age',
    'gender',
    'featured',
    'featured_image',
    'gallery'
];

    public function clinics()
    {
       return $this->belongsToMany('App\Clinic')->withPivot('price');

    }

    public function doctors()
    {
        return $this->belongsToMany('App\Doctor');
    }

    public function blogs()
    {
        return $this->belongsToMany('App\Blog');
    }
}
