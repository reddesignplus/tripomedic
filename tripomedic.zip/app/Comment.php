<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    public function clinic()
    {
        return $this->belongsTo('App\Clinic');
    }
    public function doctor() {
        return $this->belongsTo('App\Doctor');
    }

    public function facilitator() {
        return $this->belongsTo('App\Facilitator');
    }
}
