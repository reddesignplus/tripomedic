<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Doctor extends Model
{
    protected $fillable = [
        'name',
        'family',
        'alias',
        'excerpt',
        'description',
        'address',
        'tel',
        'email',
        'website',
        'certificate',
        'grade',
        'age',
        'gender',
        'avatar',
        'featured',
    ];

    public function procedures()
    {
        return $this->belongsToMany('App\Procedure');

    }
    public function comments()
    {
        return $this->hasMany('App\Comment','object_id')->where('object_type','doctor');
    }
}
