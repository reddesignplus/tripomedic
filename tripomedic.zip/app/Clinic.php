<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Clinic extends Model
{


    protected $fillable = [
        'name',
        'alias',
        'excerpt',
        'description',
        'address',
        'location',
        'city_code',
        'hospital_id',
        'tel',
        'email',
        'website',
        'certificate',
        'services',
        'language',
        'logo',
        'featured_image',
       // 'gallery',
        'featured',
    ];
    private $procedures;

    public function procedures()
    {
        return $this->belongsToMany('App\Procedure')->withPivot('price');
    }

    public function city()
    {
        return $this->belongsTo('App\City', 'city_code');
    }

    public function comments()
    {
        return $this->hasMany('App\Comment','object_id')->where('object_type','clinic');
    }

}
