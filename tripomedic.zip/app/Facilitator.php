<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Facilitator extends Model
{
    protected $fillable = [
        'name',
        'alias',
        'excerpt',
        'description',
        'address',
        'tel',
        'email',
        'website',
        'certificate',
        'services',
        'credit',
      //  'logo',
        'featured_image',
        // 'gallery',
        'featured',
    ];
    private $packages;


    public function comments()
    {
        return $this->hasMany('App\Comment','object_id')->where('object_type','facilitator');
    }

    public function packages()
    {
        return $this->hasMany('App\Package');
    }
}
