<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class City extends Model
{
    protected $primaryKey = 'city_code';
    protected $fillable = [
        'name',
        'alias',
        'excerpt',
        'description',
        'location',
        'city_code',
        'services',
        'featured_image',
        // 'gallery',

    ];
    public function clinics(){
        return $this->hasMany('App\Clinic');
    }

    public function hospitals(){
        return $this->hasMany('App\Hospital','city_code','city_code');
    }
}
