<?php $__env->startSection('content'); ?>
    <div class="container mt-3">
        <div class="row">
            <div class="col-12">
                <div class="description text-justify px-3"><?php echo $lead; ?>

                </div>
            </div>
        </div>
    </div>
    <section id="filter" class="mt-3">
        <div class="container d-flex flex-column position-relative justify-content-center">
            <div class="row justify-content-center">
                <form action="/facilitators" method="POST" class="text-center">
                    <?php echo method_field('POST'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="treatment" class="form-label mb-1"><?php echo e(__('form.treatment')); ?></label>
                        <select class="form-control form-control-sm radius" name="treatment" id="treatment">
                            <?php $__currentLoopData = \App\Procedure::where('type','treatment')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($treat->id); ?>" <?php echo e(app('request')->input('treatment') == $treat->id ? 'checked' :''); ?> >
                                    <?php if(app('request')->input('treatment') == $treat->id)
                                        $treatForTitle = $treat->name ;
                                        ?>
                                    <?php echo e($treat->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>
                    <div class="form-group">
                        <label for="city" class="form-label mb-1"><?php echo e(__('form.city')); ?></label>
                        <select class="form-control form-control-sm radius" name="city" id="city">
                            <?php $__currentLoopData = \App\City::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($city->id); ?>" <?php echo e(app('request')->input('city') == $city->id ? 'checked' :''); ?> >
                                    <?php echo e($city->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        
                        <label class="form-label form-check-label w-100 d-flex align-items-center justify-content-center form-check p-0"
                               for="facilitator"><?php echo e(__('form.facilitator')); ?>

                            <input class="form-check-input" type="checkbox" name="facilitator"
                                   id="facilitator"
                                   value="1" <?php echo e(app('request')->input('facilitator')or ''); ?> >
                            <span class="form-check-sign">
                                <span class="check"></span>
                              </span>
                        </label>

                    </div>
                    <div class="position-absolute btn-btcenter">
                        <button type="submit" class="tripo-btn btn-white text-nowrap">
                            <?php echo e(__('home.buttons.find_now')); ?>

                        </button>
                    </div>

                </form>
            </div>
        </div>
    </section>

    <section id="facilitators-result">
        <div class="container">
            <div class="row">
                <div class="section-head d-flex justify-content-center hr">
                    <h2 class="px-1"><?php echo trans_choice('home.facilitators.result_title', $type ) ?></h2>
                </div>
            </div>

            <?php if(isset($facilitators)): ?>
                    <ul class="facilitators-list list-unstyled">
                        <?php $__currentLoopData = $facilitators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facilitator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="result-item row mb-3 align-items-center">
                                <div class="col-4">
                                    <a href="/facilitators/<?php echo e($facilitator->id); ?>">
                                        <img src="<?php echo e($facilitator->logo); ?>" alt="<?php echo e($facilitator->name); ?>">
                                    </a>
                                </div>
                                <div class="col-8 details p-1">
                                    <p class="name"><a
                                            href="/facilitators/<?php echo e($facilitator->id); ?>"><?php echo e($facilitator->name); ?></a>
                                    </p>
                                    <p class="excerpt"> <?php echo e(Str::limit($facilitator->excerpt,20)); ?></p>
                                    <p class="rate"></p>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
            <?php endif; ?>
            <?php if (! ($facilitators)): ?>

            <?php endif; ?>
        </div>
    </section>
    <?php echo $__env->make('partial.advice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partial.social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Red\tripomedic\resources\views/facilitators/index.blade.php ENDPATH**/ ?>