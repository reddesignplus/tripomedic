<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">

                        <?php if(session('status')): ?>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="alert alert-success">
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <i class="material-icons">close</i>
                                        </button>
                                        <span><?php echo e(session('status')); ?></span>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>


                            <form action="<?php echo e(route('admin.clinics.update',['clinic'=>$clinic])); ?>"
                                  method="post" enctype="multipart/form-data">
                                <?php echo method_field('PUT'); ?>
                                <?php echo csrf_field(); ?>


                                        <div class="card-header card-header-tabs card-header-primary">
                                            <div class="nav-tabs-navigation">
                                                <div class="nav-tabs-wrapper">
                                                    <span class="nav-tabs-title"><?php echo e($clinic->name); ?></span>
                                                    <ul class="nav nav-tabs" data-tabs="tabs">
                                                        <li class="nav-item">
                                                            <a class="nav-link active" href="#profile" data-toggle="tab">
                                                                <i class="material-icons">bug_report</i> Bugs
                                                                <div class="ripple-container"></div>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a class="nav-link" href="#messages" data-toggle="tab">
                                                                <i class="material-icons">code</i> Website
                                                                <div class="ripple-container"></div>
                                                            </a>
                                                        </li>
                                                        <li class="nav-item">
                                                            <a class="nav-link" href="#settings" data-toggle="tab">
                                                                <i class="material-icons">cloud</i> Server
                                                                <div class="ripple-container"></div>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-body">
                                            <div class="tab-content">
                                                <div class="tab-pane active" id="profile">
                                                    <div class="form-row my-5">
                                                        <div class="form-group col-5">
                                                            <label for="name"><?php echo e(__('home.name')); ?></label>
                                                            <input type="text" class="form-control" id="name" name="name"
                                                                   value="<?php echo e(old('name') ?? $clinic->name); ?>" placeholder="">
                                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                        <div class="form-group col-5">
                                                            <label for="alias"><?php echo e(__('home.alias')); ?></label>
                                                            <input type="text" class="form-control" id="alias" name="alias"
                                                                   value="<?php echo e(old('alias') ?? $clinic->alias); ?>">
                                                            <?php $__errorArgs = ['alias'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                        <div class="togglebutton col">
                                                            <label>
                                                                <span><?php echo e(__('home.featured')); ?></span>
                                                                <input type="checkbox"
                                                                       <?php echo e($clinic->featured || old('featured') == 'on' ? 'checked': ''); ?> name="featured">
                                                                <span class="toggle"></span>
                                                            </label>
                                                        </div>

                                                    </div>
                                                    <div class="form-row my-5">
                                                        <div class="form-group col-8">
                                                            <label for="excerpt"><?php echo e(__('home.excerpt')); ?></label>
                                                            <input type="text" class="form-control" id="excerpt" name="excerpt"
                                                                   value="<?php echo e($clinic->excerpt); ?>">
                                                            <?php $__errorArgs = ['excerpt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                        <div class="form-row col-4">
                                                            <div class="form-group">
                                                                <label for="created_at"><?php echo e(__('home.created')); ?></label>
                                                                <input class="form-control" type="text"
                                                                       value="<?php echo e($clinic->created_at->format('Y,M,j - H:i')); ?>"
                                                                       readonly>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="created_at"><?php echo e(__('home.updated')); ?></label>
                                                                <input class="form-control" type="text"
                                                                       value="<?php echo e($clinic->updated_at->format('Y,M,j - H:i')); ?>"
                                                                       readonly>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-row mb-5">
                                                        <div class="form-group col-3">
                                                            <label for="city_code"><?php echo e(__('home.cities')); ?></label>
                                                            <select class="form-control" id="city_code" name="city_code">
                                                                <?php $__currentLoopData = \App\City::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option
                                                                        value="<?php echo e($option->city_code); ?>" <?php echo e($option->city_code == $clinic->city_code ? "selected" : ""); ?>><?php echo e($option->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <?php $__errorArgs = ['city_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        <div class="form-group col-3">
                                                            <label for="hospital_id"><?php echo e(__('home.hospitals')); ?></label>
                                                            <select class="form-control" id="hospital_id" name="hospital_id">
                                                                <option value="">-----</option>
                                                                <?php $__currentLoopData = \App\Hospital::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option
                                                                        value="<?php echo e($option->id); ?>" <?php echo e($option->id == $clinic->hospital_id ? "selected" : ""); ?>><?php echo e($option->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <?php $__errorArgs = ['hospital_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        <div class="form-group col-3">
                                                            <label for="languages"><?php echo e(__('home.languages')); ?></label>
                                                            <select class="form-control" id="languages" name="languages">
                                                                <option value="en">English</option>
                                                                <option value="ar">arabic</option>
                                                                <option value="fa">farsi</option>
                                                                <option value="de">dutch</option>
                                                                <option value="es">Spanish</option>

                                                            </select>
                                                        </div>
                                                        <?php $__errorArgs = ['languages'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                                    </div>
                                                    <div class="form-row mb-5">
                                                        <div class="form-group pt-3">
                                                            <label for="description"><?php echo e(__('home.description')); ?></label>
                                                            <textarea class="form-control description" id="description" name="description"
                                                                      rows="3"><?php echo e(old('description') ?? $clinic->description); ?></textarea>
                                                        </div>
                                                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>

                                                </div>
                                                <div class="tab-pane" id="messages">
                                                    <div class="form-row my-5">
                                                        <div class="form-group col">
                                                            <label for="certificate"><?php echo e(__('home.certificate')); ?></label>
                                                            <input type="text" class="form-control" id="certificate" name="certificate"
                                                                   value="<?php echo e(old('certificate') ?? $clinic->certificate); ?>">
                                                            <?php $__errorArgs = ['certificate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                        <div class="form-group col">
                                                            <label for="grade"><?php echo e(__('home.grade')); ?></label>
                                                            <input type="text" class="form-control" id="grade" name="grade"
                                                                   value="<?php echo e(old('grade') ?? $clinic->grade); ?>">
                                                            <?php $__errorArgs = ['grade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="form-row mb-5">

                                                        <div class="form-group col-sm-4">
                                                            <label for="tel"><?php echo e(__('home.tel')); ?></label>
                                                            <input type="text" class="form-control" id="tel" name="tel"
                                                                   value="<?php echo e(old('tel') ?? $clinic->tel); ?>">
                                                            <?php $__errorArgs = ['tel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>

                                                        <div class="form-group col-4">
                                                            <label for="website"><?php echo e(__('home.website')); ?></label>
                                                            <input type="text" class="form-control" id="website" name="website"
                                                                   value="<?php echo e(old('website') ?? $clinic->website); ?>">
                                                            <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>

                                                        <div class="form-group col-4">
                                                            <label for="email"><?php echo e(__('home.email')); ?></label>
                                                            <input type="email" class="form-control" id="email" name="email"
                                                                   value="<?php echo e(old('email') ?? $clinic->email); ?>">
                                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="tab-pane" id="settings">
                                                    <div class="form-row">
                                                        <div class="form-group col">
                                                            <div class="fileinput fileinput-new text-center"
                                                                 data-provides="fileinput">
                                                                <div class="fileinput-new thumbnail img-raised">
                                                                    <img class="img-fluid" src="<?php echo e(old('logo') ?? $clinic->logo); ?>">
                                                                </div>
                                                                <div class="fileinput-preview fileinput-exists thumbnail img-raised"></div>
                                                                <div class="col-3">
                                                <span class="btn btn-raised btn-round btn-default btn-file">
                                                    <span class="fileinput-new">Select image</span>
                                                    <span class="fileinput-exists">Change</span>
                                                    <input type="file" name="logo"/>
                                                    <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
                                                                    <a href="#pablo" class="btn btn-danger btn-round fileinput-exists"
                                                                       data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="form-group col">
                                                            <div class="fileinput fileinput-new text-center"
                                                                 data-provides="fileinput">
                                                                <div class="fileinput-new thumbnail img-raised">
                                                                    <img class="img-fluid" src="<?php echo e(old('featured_image') ?? $clinic->featured_image); ?>">
                                                                </div>
                                                                <div class="fileinput-preview fileinput-exists thumbnail img-raised"></div>
                                                                <div class="col-3">
                                                <span class="btn btn-raised btn-round btn-default btn-file">
                                                    <span class="fileinput-new">Select image</span>
                                                    <span class="fileinput-exists">Change</span>
                                                    <input type="file" name="featured_image"/>
                                                    <?php $__errorArgs = ['featured_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </span>
                                                                    <a href="#pablo" class="btn btn-danger btn-round fileinput-new" data-dismiss="fileinput">
                                                                        <i class="fa fa-times"></i> Remove
                                                                    </a>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>

                                                    <div class="form-group form-file-upload form-file-multiple">
                                                        <input type="file" multiple="" class="inputFileHidden">
                                                        <div class="input-group">
                                                            <input type="text" class="form-control inputFileVisible"
                                                                   placeholder="Multiple Files" multiple name="gallery">
                                                            <span class="input-group-btn">
                                            <button type="button" class="btn btn-fab btn-round btn-info"><i
                                                    class="material-icons">layers</i>
                                            </button>
                                        </span>
                                                            <?php $__errorArgs = ['gallery'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
<div class="card-footer justify-content-end">

    <div class="form-row">
        <button type="submit" class="btn btn-primary"><?php echo e(__('home.update')); ?></button>
        <a href="<?php echo e(route('admin.clinics')); ?>"
           class="btn btn-outline-danger"><?php echo e(__('home.cancel')); ?></a>
    </div>
</div>

                            </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', ['activePage' => 'clinics', 'titlePage' => __('home.clinic')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Red\tripomedic\resources\views/clinic/edit.blade.php ENDPATH**/ ?>