<?php $__env->startSection('content'); ?>

    <section id="inquiry">
        <div class="d-flex justify-content-center form-title mb-3"><?php echo e($inquiry->title); ?></div>
        <div class="container d-flex inquiry justify-content-center position-relative">
            <div class="row align-items-center">
                <form action="/inquiry" method="post" class="text-center">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="name" class="form-label"><?php echo e(__('form.name')); ?></label>
                        <input type="text" name="name" id="name" class="form-control radius"/>
                    </div>
                    <div class="form-group">
                        <label for="email" class="form-label"><?php echo e(__('form.email')); ?></label>
                        <input id="email" type="email"
                               class="form-control radius <?php $__errorArgs = ['email', 'login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                        <?php $__errorArgs = ['email', 'login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e(__('form.error.email')); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="treatment" class="form-label mb-1"><?php echo e(__('form.treatment')); ?></label>
                        <select class="form-control form-control-sm radius" name="treatment" id="treatment">
                            <?php $__currentLoopData = \App\Treatment::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    value="<?php echo e($treat->id); ?>" <?php echo e(app('request')->input('treatment') == $treat->id ? 'checked' :''); ?> >
                                    <?php echo e($treat->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="city" class="form-label mb-1"><?php echo e(__('form.city')); ?></label>
                        <select class="form-control form-control-sm radius" name="city" id="city">
                            <?php $__currentLoopData = \App\City::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    value="<?php echo e($city->id); ?>" <?php echo e(app('request')->input('city') == $city->id ? 'checked' :''); ?> >
                                    <?php echo e($city->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="position-absolute btn-btcenter">
                        <button type="submit" class="tripo-btn btn-white text-nowrap">
                            <?php echo e(__('form.submit_inquiry')); ?>

                        </button>
                    </div>

                </form>
            </div>
        </div>   </section>
    <section>
        <div class="container">
            <div class="row">
                <div class="col-12 description">
                    <?php echo $inquiry->content; ?>

                </div>

            </div>
        </div>
    </section>



    <?php echo $__env->make('partial.advice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partial.social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Red\tripomedic\resources\views/inquiry.blade.php ENDPATH**/ ?>