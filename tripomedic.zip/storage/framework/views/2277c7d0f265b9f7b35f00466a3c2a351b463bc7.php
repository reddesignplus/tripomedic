<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title ">Simple Table</h4>
            <p class="card-category"> Here is a subtitle for this table</p>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-hover">

                <thead class=" text-primary">
                  <th>
                    ID
                  </th>
                  <th>
                      <?php echo e(__("home.name")); ?>

                  </th>
                  <th>
                    <?php echo e(__("home.credit")); ?>

                  </th>
                  <th>
                      <?php echo e(__("home.city")); ?>

                  </th>
                  <th>
                      <?php echo e(__("home.action")); ?>

                  </th>
                </thead>

                <tbody>
                <?php $__currentLoopData = \App\Hospital::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <tr>
                    <td>
                      <?php echo e($hospital->id); ?>

                    </td>
                    <td>
                        <?php echo e($hospital->name); ?>

                    </td>
                    <td>
                        <?php echo e($hospital->credit); ?>

                    </td>
                    <td>
                        <?php echo e($hospital->featured); ?>

                    </td>
                      <td>

                      </td>

                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', ['activePage' => 'table', 'titlePage' => __('Table List')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Red\tripomedic\resources\views/admin/pages/table_list.blade.php ENDPATH**/ ?>