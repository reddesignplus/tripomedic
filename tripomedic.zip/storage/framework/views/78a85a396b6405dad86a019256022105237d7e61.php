<section id="packages">
    <div class="container">
        <div class="row">
            <div class="section-head d-flex justify-content-center hr">
                <h2 class="px-1"><?php echo e(__('home.special_packages')); ?></h2>
            </div>
        </div>
        <div class="row">
            <div class="owl-carousel owl-theme" id="special-carousel">

                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item"  style="width:330px">
                        <div class="package-img">
                            <a href="packages/<?php echo e($package->id); ?>">
                                <img src="<?php echo e($package->featured_image); ?>" class="border radius"
                                     alt="<?php echo e($package->excerpt); ?>">
                            </a>
                        </div>
                        <div class="content align-items-center position-absolute d-flex text-center px-2">
                            <a href="packages/<?php echo e($package->id); ?>">
                                <p class="package-price"><?php echo e(__('home.price_from')); ?> <?php echo e($package->price); ?></p>
                                <p><?php echo e($package->name); ?></p>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>

</section>
<?php /**PATH C:\Users\Red\tripomedic\resources\views/partial/packages.blade.php ENDPATH**/ ?>