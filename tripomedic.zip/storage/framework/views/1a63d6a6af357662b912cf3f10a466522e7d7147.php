<?php $__env->startSection('content'); ?>
    <section id="cities" class="mt-3">
        <div class="container">
            <div class="row mb-3">
                <div class="col position-relative">
                    <img class="border radius" src="/images/blog-bg.jpg" alt="<?php echo e(__('blog.page_title')); ?>">
                    <p class="position-absolute " style="transform: translate(-50%,-50%);top:50%;left:50%;font-size:12px;color: #fff"><?php echo e(__('blog.paeg_title')); ?></p>
                </div>

            </div>
            <div class="row">
                <?php $__currentLoopData = \App\Blog::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="blog-item col-12 col-md-6 mb-4">
                        <div class="pb-4">
                            <div class="item-img position-relative">
                                <a href="/blog/<?php echo e($item->id); ?>">
                                    <img src="<?php echo e($item->featured_image); ?>" class="border radius w-100"
                                         alt="<?php echo e($item->title); ?>">
                                    <div class="title position-absolute red p-3"><?php echo e($item->title); ?></div>
                                </a>
                            </div>
                            <div class="content px-3 pt-1 mb-3">
                                <div class="content"><?php echo e($item->excerpt); ?></div>
                            </div>
                            <div class="row justify-content-center">
                                <a href="/blog/<?php echo e($item->id); ?>" class="tripo-btn btn-white"><?php echo e(__('home.more_about')); ?> <?php echo e(Str::limit($item->title,10)); ?></a>

                            </div>
                        </div>

                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

    <?php echo $__env->make('partial.social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Red\tripomedic\resources\views/blog/index.blade.php ENDPATH**/ ?>