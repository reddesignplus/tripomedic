<section id="comments" class="<?php echo e($class ?? ''); ?>">
    <div class="container">
        <?php if($showTitle): ?>
            <div class="row">
                <div class="section-head d-flex justify-content-center hr">
                    <h2 class="px-1"><?php echo e(__('comments.title')); ?></h2>
                </div>
            </div>
        <?php endif; ?>
        <div class="row mb-2 m-0 total-count"><?php echo e(count($comments)); ?> <?php echo e(__('comments.total_count')); ?></div>
        <div class="row justify-content-center">
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6">
                    <div class="comment-item d-flex mb-3 pb-3">
                        <div class="detail w-25">
                            <div class="rate"><?php echo e($item->rate); ?>

                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star checked"></span>
                            <span class="fa fa-star"></span>
                            <span class="fa fa-star"></span>
                            </div>
                            <div class="date pr-1"><?php echo e($item->created_at->format('j F, Y')); ?></div>
                        </div>
                        <div class="content w-75">
                            <?php echo e($item->comment); ?>

                        </div>
                    </div>

                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php if(count($comments) > 2 ): ?>
            <div class="row">
                <div class="btn-readmore d-flex flex-column align-items-center position-relative w-100">
                    <a href="#" class="tripo-btn btn-white"><?php echo e(__('home.buttons.showMore')); ?></a>
                    <div class="arrow"></div>

                </div>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php /**PATH C:\Users\Red\tripomedic\resources\views/partial/comments.blade.php ENDPATH**/ ?>