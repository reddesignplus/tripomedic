<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title "><?php echo e(__('home.add_new')); ?></h4>
                            <p class="card-category"><?php echo e(__('home.facilitator_sub')); ?></p>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('admin.facilitators.store')); ?>"
                                  method="post" enctype="multipart/form-data">
                                <?php echo method_field('PUT'); ?>
                                <?php echo csrf_field(); ?>

                                <div class="form-row my-5">
                                    <div class="form-group col">
                                        <label for="name"><?php echo e(__('home.name')); ?></label>
                                        <input type="text" class="form-control" id="name" name="name"
                                               value="<?php echo e(old('name')); ?>" placeholder="">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col">
                                        <label for="alias"><?php echo e(__('home.alias')); ?></label>
                                        <input type="text" class="form-control" id="alias" name="alias"
                                               value="<?php echo e(old('alias')); ?>">
                                        <?php $__errorArgs = ['alias'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-row my-5">
                                    <div class="form-group col">
                                        <label for="excerpt"><?php echo e(__('home.excerpt')); ?></label>
                                        <input type="text" class="form-control" id="excerpt" name="excerpt"
                                               value="<?php echo e(old('excerpt')); ?>">
                                    </div>
                                    <?php $__errorArgs = ['excerpt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-row">
                                    <div class="form-group col">
                                        <label for="address"><?php echo e(__('home.address')); ?></label>
                                        <input type="text" class="form-control" id="address" name="address"
                                               value="<?php echo e(old('address')); ?>">
                                    </div>
                                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="form-row">
                                    <div class="form-group pt-3">
                                        <label for="description"><?php echo e(__('home.description')); ?></label>
                                        <textarea class="form-control description" id="description" name="description"
                                                  rows="3"><?php echo e(old('description')); ?></textarea>
                                    </div>
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-row">

                                    <div class="form-group col">
                                        <label for="tel"><?php echo e(__('home.tel')); ?></label>
                                        <input type="text" class="form-control" id="tel" name="tel"
                                               value="<?php echo e(old('tel')); ?>">
                                        <?php $__errorArgs = ['tel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group col">
                                        <label for="website"><?php echo e(__('home.website')); ?></label>
                                        <input type="text" class="form-control" id="website" name="website"
                                               value="<?php echo e(old('website')); ?>">
                                        <?php $__errorArgs = ['website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group col">
                                        <label for="email"><?php echo e(__('home.email')); ?></label>
                                        <input type="email" class="form-control" id="email" name="email"
                                               value="<?php echo e(old('email')); ?>">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="form-group col">
                                        <label for="certificate"><?php echo e(__('home.certificate')); ?></label>
                                        <input type="text" class="form-control" id="certificate" name="certificate"
                                               value="<?php echo e(old('certificate')); ?>">
                                        <?php $__errorArgs = ['certificate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col">
                                        <label for="services"><?php echo e(__('home.services')); ?></label>
                                        <input type="text" class="form-control" id="services" name="services"
                                               value="<?php echo e(old('services')); ?>">
                                        <?php $__errorArgs = ['services'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
<div class="form-row"> <div class="form-group col-3">
        <label for="city_code"><?php echo e(__('home.credit')); ?></label>
        <select class="form-control" id="credit" name="credit">
            <?php $__currentLoopData = \App\Credit::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($option->type); ?>"><?php echo e($option->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <?php $__errorArgs = ['credit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
                                <div class="form-row">
                                    <div class="form-group col">
                                        <div class="fileinput fileinput-new text-center col-3" data-provides="fileinput">
                                            <div class="fileinput-new thumbnail img-raised">
                                                <img src="<?php echo e(old('logo')); ?>">
                                            </div>
                                            <div class="fileinput-preview fileinput-exists thumbnail img-raised"></div>
                                            <div class="col-3">
                                        <span class="btn btn-raised btn-round btn-default btn-file">
            <span class="fileinput-new">Select image</span>
            <span class="fileinput-exists">Change</span>
            <input type="file" name="logo"/>
                                              <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </span>
                                                <a href="#pablo" class="btn btn-danger btn-round fileinput-exists"
                                                   data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="form-group col">
                                        <div class="fileinput fileinput-new text-center col-3" data-provides="fileinput">
                                            <div class="fileinput-new thumbnail img-raised">
                                                <img src="<?php echo e(old('featured_image')); ?>">
                                            </div>
                                            <div class="fileinput-preview fileinput-exists thumbnail img-raised"></div>
                                            <div class="col-3">
                                        <span class="btn btn-raised btn-round btn-default btn-file">
            <span class="fileinput-new">Select image</span>
            <span class="fileinput-exists">Change</span>
            <input type="file" name="featured_image"/>
                                              <?php $__errorArgs = ['featured_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </span>
                                                <a href="#pablo" class="btn btn-danger btn-round fileinput-exists"
                                                   data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                            </div>
                                        </div>

                                    </div>
                                </div>






                                <div class="form-row">
                                    <div class="togglebutton">
                                        <label>
                                            <span><?php echo e(__('home.featured')); ?></span>
                                            <input type="checkbox"
                                                   value="<?php echo e(old('featured')); ?>" <?php echo e(old('featured') == 0 ? '' :'checked'); ?> name="featured">
                                            <span class="toggle"></span>
                                        </label>
                                    </div>

                                    <div class="form-group col-3">
                                        <label for="created_at"><?php echo e(__('home.created')); ?></label>
                                        <input class="form-control" type="text"
                                               value="<?php echo e(now()); ?>"
                                               readonly>
                                    </div>
                                    <div class="form-group col-3">
                                        <label for="created_at"><?php echo e(__('home.updated')); ?></label>
                                        <input class="form-control" type="text"
                                               value="<?php echo e(\Carbon\Carbon::now()); ?>"
                                               readonly>
                                    </div>
                                </div>
                                <div class="form-row float-right">
                                    <button type="submit" class="btn btn-primary"><?php echo e(__('home.add_new')); ?></button>
                                    <a href="<?php echo e(route('admin.facilitators')); ?>" class="btn btn-danger"><?php echo e(__('home.cancel')); ?></a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', ['activePage' => 'facilitators', 'titlePage' => __('home.facilitator')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Red\tripomedic\resources\views/facilitators/add.blade.php ENDPATH**/ ?>