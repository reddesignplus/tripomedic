<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">

            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

        </div>
    </div>
    <section id="slider" class="m-0">

        <div class="slider-container">
            <div class="slider-control left inactive"></div>
            <div class="slider-control right"></div>
            <ul class="d-none slider-pagi"></ul>
            <div class="slider">
                <div class="slide slide-0 active">
                    <div class="slide__bg"></div>
                    <div class="slide__content">
                        <svg class="slide__overlay" viewBox="0 0 720 405" preserveAspectRatio="xMaxYMax slice">
                            <path class="slide__overlay-path" d="M0,0 150,0 500,405 0,405"/>
                        </svg>
                        <div class="d-none slide__text">
                            <h2 class="slide__text-heading">Project name 1</h2>
                            <p class="slide__text-desc">Lorem ipsum dolor sit amet</p>
                            <a class="slide__text-link">Project link</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="position-absolute btn-btcenter"><a class="tripo-btn btn-white"
                                                           href="#findclinic"><?php echo e(__('home.buttons.find_now')); ?></a>
            </div>

        </div>
    </section>

    <section id="services">
        <div class="container">
            <div class="row">
                <div class="section-head d-flex justify-content-center hr">
                    <h2 class="px-1"><?php echo e(__('home.services')); ?></h2>
                </div>
            </div>
            <div class="row justify-content-around mx-3">
                <div class="box p-3">

                    <a href="/clinics">
                        <div class="icon justify-content-center align-items-center d-flex"><span
                                class="flaticon-clinic"></span></div>
                        <h3 class="title m-0"><?php echo e(__('home.clinics')); ?></h3>
                        <p class="m-0"><?php echo e(__('home.clinics_sub')); ?></p>
                    </a>

                </div>
                <div class="box p-3">
                    <a href="/doctors">
                        <div class="icon justify-content-center align-items-center d-flex"><span
                                class="flaticon-doctor"></span></div>
                        <h3 class="title m-0"><?php echo e(__('home.doctors')); ?></h3>
                        <p class="m-0"><?php echo e(__('home.doctors_sub')); ?></p>
                    </a>
                </div>
                <div class="box p-3">
                    <a href="/facilitators">
                        <div class="icon justify-content-center align-items-center d-flex"><span
                                class="flaticon-facilitator"></span></div>
                        <h3 class="title m-0"><?php echo e(__('home.facilitator')); ?></h3>
                        <p class="m-0"><?php echo e(__('home.facilitator_sub')); ?></p>
                    </a>
                </div>
                <div class="box p-3">
                    <a href="/cities">
                        <div class="icon justify-content-center align-items-center d-flex"><span
                                class="flaticon-seesight"></span></div>
                        <h3 class="title m-0"><?php echo e(__('home.seesight')); ?></h3>
                        <p class="m-0"><?php echo e(__('home.seesight_sub')); ?></p>
                    </a>
                </div>
                <div class="box p-3">
                    <a href="/treatments">
                        <div class="icon justify-content-center align-items-center d-flex"><span
                                class="flaticon-treatment"></span></div>
                        <h3 class="title m-0"><?php echo e(__('home.treatments')); ?></h3>
                        <p class="m-0"><?php echo e(__('home.treatments_sub')); ?></p>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <?php echo $__env->make('partial.packages', ['packages' => $packages], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <section id="findclinic">
        <div class="container d-flex flex-column position-relative justify-content-center">
            <div class="row justify-content-center">
                 <form action="/clinics" method="POST">
                     <?php echo method_field('POST'); ?>
                     <?php echo csrf_field(); ?>
                     <p class="form-label text-center pb-4 w-75 m-auto"><?php echo e(__('home.find_clinic')); ?></p>
                    <div class="d-flex align-items-center mb-2">
                        <label for="city" class="form-label"><?php echo e(__('city.city')); ?></label>
                        <select name="city" id="city" class="form-control radius col-10"><?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option value="<?php echo e($city->city_code); ?>"> <?php echo e($city->name); ?></option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="d-flex  align-items-center">
                        <label for="treatment" class="form-label"><?php echo e(__('treatment.treatment')); ?></label>
                        <select name="treatment" id="treatment" class="form-control radius col-10"><?php $__currentLoopData = $treatments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treatment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option value="<?php echo e($treatment->id); ?>"> <?php echo e($treatment->name); ?></option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="position-absolute btn-btcenter">
                       <button type="submit" class="tripo-btn btn-white text-nowrap"><?php echo e(__('home.find_button')); ?></button>
                    </div>
                 </form>

            </div>
        </div>
    </section>

    <section id="steps">
        <div class="container p-4">
            <div class="row">
                <div class="path d-flex justify-content-center w-100 align-items-center">
                    <div class="step rounded-circle p-3">
                        <span class="flaticon-doctor"></span>
                    </div>
                    <div class="step rounded-circle p-3">
                        <span class="flaticon-clinic"></span>
                    </div>
                    <div class="step rounded-circle p-3">
                        <span class="flaticon-seesight"></span>
                    </div>
                    <div class="step rounded-circle p-3">
                        <span class="flaticon-treatment"></span>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center mt-4">
                <a class="tripo-btn btn-white" href="/about"><?php echo e(__('home.how_we_do')); ?></a>
            </div>
        </div>
    </section>

    <section id="cities">

        <div class="container">
            <div class="row">
                <div class="section-head d-flex justify-content-center hr">
                    <h2 class="px-1"><?php echo e(__('home.cities')); ?></h2>
                </div>
            </div>
            <div class="row">
                <div class="owl-carousel owl-theme" id="cities-carousel">

                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <div class="package-img">
                                <a href="/cities/<?php echo e($city->id); ?>" class="tripo-btn btn-white p-0">
                                    <img src="<?php echo e($city->featured_image); ?>" class="border radius"
                                         alt="<?php echo e($city->excerpt); ?>">
                                    <p class="btn-btcenter position-absolute"><?php echo e($city->name); ?></p>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </section>
<div class="container p-0">
    <div class="d-lg-flex">
        <?php echo $__env->make('partial.advice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('partial.social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

</div>



    <?php echo $__env->make('partial.blog',['type'=>'default'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php echo $__env->make('partial.subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Red\tripomedic\resources\views/home.blade.php ENDPATH**/ ?>