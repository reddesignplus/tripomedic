<footer class="footer">
    <div class="container">
        <nav class="float-left">
        <ul>
            <li>
            <a href="https://www.tripomedic.com">
                <?php echo e(__('tripomedic')); ?>

            </a>
            </li>
            <li>
            <a href="https://www.tripomedic.com/about">
                <?php echo e(__('home.about-us')); ?>

            </a>
            </li>
            <li>
            <a href="http://www.tripomedic.com/blog">
                <?php echo e(__('home.blog')); ?>

            </a>
            </li>
            <li>
            <a href="https://www.tripomedic.com/license">
                <?php echo e(__('Licenses')); ?>

            </a>
            </li>
        </ul>
        </nav>
        <div class="copyright float-right">
        &copy;
        <script>
            document.write(new Date().getFullYear())
        </script>, made with <i class="material-icons">favorite</i> by
        <a href="https://www.tripomedic.com" target="_blank">TripoMedic </a> and <a href="https://www.reddesign.studio" target="_blank">Red Design Studio</a>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\Red\tripomedic\resources\views/admin/layouts/footers/guest.blade.php ENDPATH**/ ?>