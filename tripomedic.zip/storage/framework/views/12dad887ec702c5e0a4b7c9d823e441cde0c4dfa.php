<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">

                            <form action="<?php echo e(route('admin.cities.update',['city'=>$city])); ?>"
                                  method="post" enctype="multipart/form-data">
                                <?php echo method_field('PUT'); ?>
                                <?php echo csrf_field(); ?>
                                <div class="card-header card-header-tabs card-header-primary">
                                    <div class="nav-tabs-navigation">
                                        <div class="nav-tabs-wrapper">
                                            <span class="nav-tabs-title"><?php echo e($city->name); ?></span>
                                            <p class="card-category"><?php echo e(__('home.seesight_sub')); ?></p>
                                            <ul class="nav nav-tabs" data-tabs="tabs">
                                                <li class="nav-item">
                                                    <a class="nav-link active" href="#content" data-toggle="tab">
                                                        <i class="material-icons">file_copy</i> Content
                                                        <div class="ripple-container"></div>
                                                    </a>
                                                </li>
                                                <li class="nav-item">
                                                    <a class="nav-link" href="#images" data-toggle="tab">
                                                        <i class="material-icons">collections</i> Images
                                                        <div class="ripple-container"></div>
                                                    </a>
                                                </li>
                                                <li class="nav-item">
                                                    <a class="nav-link" href="#details" data-toggle="tab">
                                                        <i class="material-icons">details</i> Details
                                                        <div class="ripple-container"></div>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="tab-content">
                                        <div class="tab-pane active" id="content">
                                <div class="form-row my-5">
                                    <div class="form-group col">
                                        <label for="name"><?php echo e(__('home.name')); ?></label>
                                        <input type="text" class="form-control" id="name" name="name"
                                               value="<?php echo e(old('name') ?? $city->name); ?>" placeholder="">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col">
                                        <label for="alias"><?php echo e(__('home.alias')); ?></label>
                                        <input type="text" class="form-control" id="alias" name="alias"
                                               value="<?php echo e(old('alias') ?? $city->alias); ?>">
                                        <?php $__errorArgs = ['alias'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-row my-5">
                                    <div class="form-group col">
                                        <label for="excerpt"><?php echo e(__('home.excerpt')); ?></label>
                                        <input type="text" class="form-control" id="excerpt" name="excerpt"
                                               value="<?php echo e($city->excerpt); ?>">
                                    </div>


                                        <div class="form-group col-3">
                                            <label for="created_at"><?php echo e(__('home.created')); ?></label>
                                            <input class="form-control" type="text"
                                                   placeholder="    <?php echo e($city->created_at->format('Y,M,j - H:i')); ?>"
                                                   readonly>
                                        </div>
                                        <div class="form-group col-3">
                                            <label for="created_at"><?php echo e(__('home.updated')); ?></label>
                                            <input class="form-control" type="text"
                                                   placeholder="    <?php echo e($city->updated_at->format('Y,M,j - H:i')); ?>"
                                                   readonly>
                                        </div>

                                </div>

                                <div class="form-row">
                                                                        <div class="form-group">
                                        <label for="city_code"><?php echo e(__('home.city_code')); ?></label>
                                        <input type="text" class="form-control" value="<?php echo e(old('city_code') ?? $city->city_code); ?>" name="city_code">
                                        <?php $__errorArgs = ['city_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label for="location"><?php echo e(__('home.location')); ?></label>

                                        <input type="text" class="form-control" value="<?php echo e(old('location') ?? $city->location); ?>" name="location">
                                        <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>


                                </div>

                                <div class="form-row">
                                    <div class="form-group pt-3">
                                        <label for="description"><?php echo e(__('home.description')); ?></label>
                                        <textarea class="form-control description" id="description" name="description"
                                                  rows="3"><?php echo e(old('description') ?? $city->description); ?></textarea>
                                    </div>
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>


                                        </div>
                                        <div class="tab-pane" id="images">
                                            <div class="fileinput fileinput-new text-center col-3" data-provides="fileinput">
                                                <div class="fileinput-new thumbnail img-raised">
                                                    <img src="<?php echo e($city->featured_image); ?>" alt="<?php echo e($city->name); ?>">
                                                </div>
                                                <div class="fileinput-preview fileinput-exists thumbnail img-raised"></div>
                                                <div class="col-3">
                                        <span class="btn btn-raised btn-round btn-default btn-file">
            <span class="fileinput-new">Select image</span>
            <span class="fileinput-exists">Change</span>
            <input type="file" name="featured_image"/>
                                              <?php $__errorArgs = ['featured_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </span>
                                                    <a href="#pablo" class="btn btn-danger btn-round fileinput-exists"
                                                       data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                                </div>
                                            </div>
                                            <div class="form-group form-file-upload form-file-multiple">
                                                <input type="file" multiple="" class="inputFileHidden">
                                                <div class="input-group">
                                                    <input type="text" class="form-control inputFileVisible"
                                                           placeholder="Multiple Files" multiple name="gallery">
                                                    <span class="input-group-btn">
            <button type="button" class="btn btn-fab btn-round btn-info">
                <i class="material-icons">layers</i>
            </button>
        </span>
                                                    <?php $__errorArgs = ['gallery'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="tab-pane" id="details">
                                            <div class="form-row">
                                                <div class="form-group pt-3">
                                                    <label for="services"><?php echo e(__('home.services')); ?></label>
                                                    <textarea class="form-control" id="services" name="services"
                                                              rows="3"><?php echo e(old('services') ?? $city->services); ?></textarea>
                                                </div>
                                                <?php $__errorArgs = ['services'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                        <div class="card-footer">
                                            <div class="form-row float-right">
                                                <button type="submit" class="btn btn-primary"><?php echo e(__('home.update')); ?></button>
                                                <a href="<?php echo e(route('admin.cities')); ?>" class="btn btn-danger"><?php echo e(__('home.cancel')); ?></a>
                                            </div>
                                        </div>




                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', ['activePage' => 'cities', 'titlePage' => __('home.treatments')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Red\tripomedic\resources\views/cities/edit.blade.php ENDPATH**/ ?>