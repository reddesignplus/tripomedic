<form action="/comment/add" method="post" class=" d-flex flex-column align-items-center text-center">
   <?php echo method_field('POST'); ?>
    <?php echo csrf_field(); ?>
    <input type="hidden" value="1" name="object_type">
    <input type="hidden" value="1" name="object_id">
    <div class="mb-2">
        <label for="comment" class="form-label"><?php echo e(__('form.comment')); ?></label>
        <textarea name="comment" rows="5" id="comment" class="form-control radius"></textarea>
    </div>
    <div class="mb-2">
        <label for="name" class="form-label"><?php echo e(__('form.name')); ?></label>
        <input type="text" name="name" id="name" class="form-control radius" />
    </div>
    <div class="mb-2">
        <label for="email" class="form-label"><?php echo e(__('form.email')); ?></label>
        <input id="email" type="email" name="email" class="form-control radius <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >

        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger"><?php echo e(__('form.error.email')); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-2">
        <button type="submit" class="tripo-btn btn-white"><?php echo e(__('form.submit_comment')); ?></button>
    </div>
</form>
<?php /**PATH C:\Users\Red\tripomedic\resources\views/partial/commentForm.blade.php ENDPATH**/ ?>