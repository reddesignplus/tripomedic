<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title "><?php echo e(__('home.blog')); ?></h4>
                            <p class="card-category"><?php echo e(__('home.blog')); ?></p>
                        </div>
                        <div class="card-body">
                            <div class="actions float-right">
                                <a class="btn btn-primary" href="<?php echo e(route('admin.blog.create')); ?>"><?php echo e(__('home.add_new')); ?></a>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-hover">

                                    <thead class=" text-primary">
                                    <th>
                                        ID
                                    </th>
                                    <th>
                                        <?php echo e(__("blog.status")); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__("blog.title")); ?>

                                    </th>

                                    <th>
                                        <?php echo e(__("blog.published")); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__("home.action")); ?>

                                    </th>
                                    </thead>

                                    <tbody>
                                    <?php $__currentLoopData = \App\Blog::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($blog->id); ?>

                                            </td>
                                            <td>
                                                <button  type="button" class="btn btn-fab btn-fab-mini btn-round <?php echo e($blog->featured == 'on' ? 'btn-warning' : 'btn-default'); ?>">
                                                    <i class="material-icons">star</i>
                                                </button>
                                                <span class="badge badge-success"><?php echo e($blog->status); ?></span>
                                            </td>
                                            <td>
                                               <p class="m-0"><a href="<?php echo e(route('admin.blog.edit',$blog)); ?>"><?php echo e($blog->title); ?></a></p>
                                                <sub>alias: <?php echo e($blog->alias); ?></sub>
                                            </td>
                                            <td>
                                                <?php echo e($blog->published_date); ?>

                                            </td>
                                            <td>
                                                <button type="button" class="btn btn-fab  btn-fab-mini btn-round btn-primary">
                                                    <i class="material-icons">edit</i>
                                                </button>


                                                <button type="button" class="btn btn-fab  btn-fab-mini btn-round btn-outline-danger">
                                                    <i class="material-icons">delete</i>
                                                </button>
                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', ['activePage' => 'blog', 'titlePage' => __('home.blog')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Red\tripomedic\resources\views/blog/list.blade.php ENDPATH**/ ?>