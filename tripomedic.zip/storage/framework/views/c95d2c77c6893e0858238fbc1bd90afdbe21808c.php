<section id="blog" class="<?php echo e($class ?? ''); ?>">
    <div class="container">
        <?php if($showTitle): ?>

        <div class="row">
            <div class="section-head d-flex justify-content-center hr">
                <h2 class="px-1"><?php echo e(__('home.blog')); ?></h2>
            </div>
        </div>
        <?php endif; ?>
        <div class="row">
                <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="blog-item col-12 col-md-6 mb-4">
                        <div class="pb-4">
                            <div class="item-img position-relative">
                                <a href="/blog/<?php echo e($item->id); ?>">
                                    <img src="<?php echo e($item->featured_image); ?>" class="border radius w-100"
                                         alt="<?php echo e($item->title); ?>">
                                    <div class="title position-absolute red p-3"><?php echo e($item->title); ?></div>
                                </a>
                            </div>
                            <div class="content px-3 pt-1 mb-3">
                                    <div class="content"><?php echo e($item->excerpt); ?></div>
                            </div>
                            <div class="row justify-content-center">
                                <a href="/blog/<?php echo e($item->id); ?>" class="tripo-btn btn-white"><?php echo e(__('home.more_about')); ?> <?php echo e(Str::limit($item->title,10)); ?></a>

                            </div>
                        </div>

                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

            <?php if($showMore): ?>
        <div class="row">
            <div class="section-head d-flex justify-content-center hr">
                <p style="background-color: white" class="m-0 p-1">
                    <a href="/blog" class="position-relative tripo-btn btn-blue btn-border"><?php echo e(__('home.see_all_blog')); ?></a>
                </p>

            </div>
        </div>
            <?php endif; ?>
    </div>
</section>
<?php /**PATH C:\Users\Red\tripomedic\resources\views/partial/blog.blade.php ENDPATH**/ ?>