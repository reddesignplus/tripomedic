<?php echo e($objects); ?>

<?php /**PATH C:\Users\Red\tripomedic\resources\views/admin/index.blade.php ENDPATH**/ ?>