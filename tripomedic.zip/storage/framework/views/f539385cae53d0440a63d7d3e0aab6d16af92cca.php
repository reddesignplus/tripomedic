<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title "><?php echo e(__('home.add_new')); ?></h4>
                            <p class="card-category"><?php echo e(__('home.treatments_sub')); ?></p>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('admin.treatments.store')); ?>"
                                  method="post" enctype="multipart/form-data">
                                <?php echo method_field('PUT'); ?>
                                <?php echo csrf_field(); ?>
                                <input type="hidden" value="<?php echo e($type); ?>"b name="type">
                                <div class="form-row my-5">
                                    <div class="form-group col">
                                        <label for="name"><?php echo e(__('home.name')); ?></label>
                                        <input type="text" class="form-control" id="name" name="name"
                                               value="<?php echo e(old('name')); ?>" placeholder="">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="form-group col">
                                        <label for="alias"><?php echo e(__('home.alias')); ?></label>
                                        <input type="text" class="form-control" id="alias" name="alias"
                                               value="<?php echo e(old('alias')); ?>">
                                        <?php $__errorArgs = ['alias'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="form-row my-5">
                                    <div class="form-group col">
                                        <label for="excerpt"><?php echo e(__('home.excerpt')); ?></label>
                                        <input type="text" class="form-control" id="excerpt" name="excerpt"
                                               value="<?php echo e(old('excerpt')); ?>">
                                    </div>
                                </div>

                                <div class="form-row"> <?php if($type == 'procedure'): ?>
                                        <div class="form-group col-3">
                                            <label for="treatparent"><?php echo e(__('home.treatments')); ?></label>
                                            <select class="form-control" id="treatparent" name="parent">
                                                <?php $__currentLoopData = \App\Procedure::where('type','treatment')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($option->id); ?>"><?php echo e($option->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <?php $__errorArgs = ['parent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                           <?php else: ?>
                                        <input type="hidden" value="0" name="parent">
                                    <?php endif; ?>
                                    <div class="input-group">
                                        <label for="icon"><?php echo e(__('home.icon')); ?></label>
                                        <div class="input-group-append"><span class="input-group-text"><i
                                                    class="fa fa-group"></i></span></div>
                                        <input type="text" class="form-control" value="<?php echo e(old('icon')); ?>" name="icon">
                                        <?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="form-row">
                                    <div class="form-group pt-3">
                                        <label for="description"><?php echo e(__('home.description')); ?></label>
                                        <textarea class="form-control description" id="description" name="description"
                                                  rows="3"><?php echo e(old('description')); ?></textarea>
                                    </div>
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="fileinput fileinput-new text-center col-3" data-provides="fileinput">
                                    <div class="fileinput-new thumbnail img-raised">
                                        <img src="" alt="">
                                    </div>
                                    <div class="fileinput-preview fileinput-exists thumbnail img-raised"></div>
                                    <div class="col-3">
                                        <span class="btn btn-raised btn-round btn-default btn-file">
            <span class="fileinput-new">Select image</span>
            <span class="fileinput-exists">Change</span>
            <input type="file" name="featured_image"/>
                                              <?php $__errorArgs = ['featured_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </span>
                                        <a href="#pablo" class="btn btn-danger btn-round fileinput-exists"
                                           data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                    </div>
                                </div>
                                <div class="form-group form-file-upload form-file-multiple">
                                    <input type="file" multiple="" class="inputFileHidden">
                                    <div class="input-group">
                                        <input type="text" class="form-control inputFileVisible"
                                               placeholder="Multiple Files" multiple name="gallery">
                                        <span class="input-group-btn">
            <button type="button" class="btn btn-fab btn-round btn-info">
                <i class="material-icons">layers</i>
            </button>
        </span>
                                        <?php $__errorArgs = ['gallery'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <?php if($type == 'procedure'): ?>
                                    <div class="togglebutton">
                                        <label>
                                            <span><?php echo e(__('home.featured')); ?></span>
                                            <input type="checkbox"
                                                   value="<?php echo e(old('featured')); ?>" <?php echo e(old('featured') == 0 ? '' :'checked'); ?> name="featured">
                                            <span class="toggle"></span>
                                        </label>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col">
                                            <label for="gender"><?php echo e(__('home.gender')); ?></label>
                                            <div class="form-check form-check-radio">
                                                <label class="form-check-label">
                                                    <input class="form-check-input" type="radio" name="gender" id="men"
                                                           value="men" <?php echo e(old('gender') =='child'? 'men' : ''); ?>><?php echo e(__('doctors.men')); ?>

                                                    <span class="circle"><span class="check"></span></span>
                                                </label>

                                            </div>
                                            <div class="form-check form-check-radio">
                                                <label class="form-check-label">
                                                    <input class="form-check-input" type="radio" name="gender"
                                                           id="women"
                                                           value="women" <?php echo e(old('gender')  =='women' ? 'checked' : ''); ?>><?php echo e(__('doctors.women')); ?>

                                                    <span class="circle"><span class="check"></span></span>
                                                </label>
                                            </div>
                                        </div>

                                        <div class="form-group col">
                                            <label for="age"><?php echo e(__('home.age')); ?></label>
                                            <div class="form-check form-check-radio ">
                                                <label class="form-check-label">
                                                    <input class="form-check-input" type="radio" name="age" id="child"
                                                           value="child" <?php echo e(old('age')=='child'? 'checked' : ''); ?>><?php echo e(__('doctors.child')); ?>

                                                    <span class="circle"><span class="check"></span></span>
                                                </label>
                                            </div>
                                            <div class="form-check form-check-radio">
                                                <label class="form-check-label">
                                                    <input class="form-check-input" type="radio" name="age"
                                                           id="adult"
                                                           value="adult" <?php echo e(old('age') =='adult'? 'checked' : ''); ?>><?php echo e(__('doctors.adult')); ?>

                                                    <span class="circle"><span class="check"></span></span>
                                                </label>
                                            </div>

                                        </div>
                                    </div>
                                <?php endif; ?>
                                <div class="form-row">
                                    <div class="form-group col-3">
                                        <label for="created_at"><?php echo e(__('home.created')); ?></label>
                                        <input class="form-control" type="text"
                                               value="<?php echo e(now()); ?>"
                                               readonly>
                                    </div>
                                    <div class="form-group col-3">
                                        <label for="created_at"><?php echo e(__('home.updated')); ?></label>
                                        <input class="form-control" type="text"
                                               value="<?php echo e(now()); ?>"
                                               readonly>
                                    </div>
                                </div>
                                <div class="form-row float-right">
                                    <button type="submit" class="btn btn-primary"><?php echo e(__('home.store')); ?></button>
                                    <a href="<?php echo e(route('admin.treatments')); ?>" class="btn btn-danger"><?php echo e(__('home.cancel')); ?></a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', ['activePage' => $type, 'titlePage' => __('home.treatments')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Red\tripomedic\resources\views/treatments/add.blade.php ENDPATH**/ ?>