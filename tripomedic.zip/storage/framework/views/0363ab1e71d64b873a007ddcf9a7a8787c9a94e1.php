<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <form action="<?php echo e(route('admin.doctors.update',['doctor'=>$doctor])); ?>"
                              method="post" enctype="multipart/form-data">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>

                            <div class="card-header card-header-tabs card-header-primary">
                                <div class="nav-tabs-navigation">
                                    <div class="nav-tabs-wrapper">
                                        <span class="nav-tabs-title"><?php echo e($doctor->name); ?> <?php echo e($doctor->family); ?></span>
                                        <ul class="nav nav-tabs" data-tabs="tabs">
                                            <li class="nav-item">
                                                <a class="nav-link active" href="#content" data-toggle="tab">
                                                    <i class="material-icons">file_copy</i> Content
                                                    <div class="ripple-container"></div>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" href="#images" data-toggle="tab">
                                                    <i class="material-icons">collections</i> Images
                                                    <div class="ripple-container"></div>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" href="#details" data-toggle="tab">
                                                    <i class="material-icons">details</i> Details
                                                    <div class="ripple-container"></div>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="tab-content">
                                    <div class="tab-pane active" id="content">
                                        <div class="togglebutton">
                                            <label>
                                                <span><?php echo e(__('home.featured')); ?></span>
                                                <input type="checkbox"
                                                       <?php echo e($doctor->featured || old('featured') == 'on' ? 'checked' : ""); ?> name="featured">
                                                <span class="toggle"></span>
                                            </label>
                                        </div>


                                        <div class="form-row">
                                            <div class="form-group col-3">
                                                <label for="created_at"><?php echo e(__('home.created')); ?></label>
                                                <input class="form-control" type="text"
                                                       placeholder="    <?php echo e($doctor->created_at->format('Y,M,j - H:i')); ?>"
                                                       readonly>
                                            </div>
                                            <div class="form-group col-3">
                                                <label for="created_at"><?php echo e(__('home.updated')); ?></label>
                                                <input class="form-control" type="text"
                                                       placeholder="    <?php echo e($doctor->updated_at->format('Y,M,j - H:i')); ?>"
                                                       readonly>
                                            </div>
                                        </div>

                                        <div class="form-row my-5">
                                            <div class="form-group col">
                                                <label for="name"><?php echo e(__('home.name')); ?></label>
                                                <input type="text" class="form-control" id="name" name="name"
                                                       value="<?php echo e(old('name') ?? $doctor->name); ?>" placeholder="">
                                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group col">
                                                <label for="name"><?php echo e(__('doctor.family')); ?></label>
                                                <input type="text" class="form-control" id="family" name="family"
                                                       value="<?php echo e(old('family') ?? $doctor->family); ?>" placeholder="">
                                                <?php $__errorArgs = ['family'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group col">
                                                <label for="alias"><?php echo e(__('home.alias')); ?></label>
                                                <input type="text" class="form-control" id="alias" name="alias"
                                                       value="<?php echo e(old('alias') ?? $doctor->alias); ?>">
                                                <?php $__errorArgs = ['alias'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="form-row my-5">
                                            <div class="form-group col">
                                                <label for="excerpt"><?php echo e(__('home.excerpt')); ?></label>
                                                <input type="text" class="form-control" id="excerpt" name="excerpt"
                                                       value="<?php echo e(old('excerpt') ?? $doctor->excerpt); ?>">
                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group pt-3">
                                                <label for="description"><?php echo e(__('home.description')); ?></label>
                                                <textarea class="form-control description" id="description"
                                                          name="description"
                                                          rows="3"><?php echo e(old('description') ?? $doctor->description); ?></textarea>
                                            </div>
                                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                    </div>
                                    <div class="tab-pane" id="images">
                                        <div class="fileinput fileinput-new text-center col-3"
                                             data-provides="fileinput">
                                            <div class="fileinput-new thumbnail img-raised">
                                                <img src="<?php echo e($doctor->avatar); ?>" alt="<?php echo e($doctor->name); ?>">
                                            </div>
                                            <div class="fileinput-preview fileinput-exists thumbnail img-raised"></div>
                                            <div class="col-3">
                                        <span class="btn btn-raised btn-round btn-default btn-file">
            <span class="fileinput-new">Select image</span>
            <span class="fileinput-exists">Change</span>
            <input type="file" name="featured_image"/>
                                              <?php $__errorArgs = ['featured_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </span>
                                                <a href="#pablo" class="btn btn-danger btn-round fileinput-exists"
                                                   data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="tab-pane" id="details">
                                        <div class="form-row">
                                            <div class="form-group col">
                                                <label for="address"><?php echo e(__('home.address')); ?></label>
                                                <input type="text" class="form-control" id="address" name="address"
                                                       value="<?php echo e(old('address') ?? $doctor->address); ?>">
                                            </div>
                                        </div>
                                        <div class="form-row">

                                            <div class="form-group col">
                                                <label for="tel"><?php echo e(__('home.tel')); ?></label>
                                                <input type="text" class="form-control" id="tel" name="tel"
                                                       value="<?php echo e(old('tel') ?? $doctor->tel); ?>">
                                            </div>

                                            <div class="form-group col">
                                                <label for="website"><?php echo e(__('home.website')); ?></label>
                                                <input type="text" class="form-control" id="website" name="website"
                                                       value="<?php echo e(old('website') ?? $doctor->website); ?>">
                                            </div>

                                            <div class="form-group col">
                                                <label for="email"><?php echo e(__('home.email')); ?></label>
                                                <input type="email" class="form-control" id="email" name="email"
                                                       value="<?php echo e(old('email') ?? $doctor->email); ?>">

                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col">
                                                <label for="certificate"><?php echo e(__('home.certificate')); ?></label>
                                                <input type="text" class="form-control" id="certificate" name="certificate"
                                                       value="<?php echo e(old('certificate') ?? $doctor->certificate); ?>">

                                            </div>
                                            <div class="form-group col">
                                                <label for="grade"><?php echo e(__('home.grade')); ?></label>
                                                <input type="text" class="form-control" id="grade" name="grade"
                                                       value="<?php echo e(old('grade') ?? $doctor->grade); ?>">

                                            </div>
                                        </div>
                                        <div class="form-row">
                                            <div class="form-group col">
                                                <label for="gender"><?php echo e(__('home.gender')); ?></label>
                                                <div class="form-check form-check-radio">
                                                    <label class="form-check-label">
                                                        <input class="form-check-input" type="radio" name="gender" id="men"
                                                               value="men" <?php echo e(old('gender')  || $doctor->gender =='men'? 'checked' : ''); ?>><?php echo e(__('doctors.men')); ?>

                                                        <span class="circle"><span class="check"></span></span>
                                                    </label>

                                                </div>
                                                <div class="form-check form-check-radio">
                                                    <label class="form-check-label">
                                                        <input class="form-check-input" type="radio" name="gender"
                                                               id="women"
                                                               value="women" <?php echo e(old('gender')  || $doctor->gender =='women' ? 'checked' : ''); ?>><?php echo e(__('doctors.women')); ?>

                                                        <span class="circle"><span class="check"></span></span>
                                                    </label>
                                                </div>
                                            </div>

                                            <div class="form-group col">
                                                <label for="age"><?php echo e(__('home.age')); ?></label>
                                                <div class="form-check form-check-radio ">
                                                    <label class="form-check-label">
                                                        <input class="form-check-input" type="radio" name="age" id="child"
                                                               value="child" <?php echo e(old('age') || $doctor->age =='child'? 'checked' : ''); ?>><?php echo e(__('doctors.child')); ?>

                                                        <span class="circle"><span class="check"></span></span>
                                                    </label>
                                                </div>
                                                <div class="form-check form-check-radio">
                                                    <label class="form-check-label">
                                                        <input class="form-check-input" type="radio" name="age"
                                                               id="adult"
                                                               value="adult" <?php echo e(old('age') || $doctor->age =='adult'? 'checked' : ''); ?>><?php echo e(__('doctors.adult')); ?>

                                                        <span class="circle"><span class="check"></span></span>
                                                    </label>
                                                </div>

                                            </div>
                                        </div>
                                    </div>


                                </div>
                            </div>
                                <div class="card-footer justify-content-end">
                                    <div class="form-row float-right">
                                        <button type="submit" class="btn btn-primary"><?php echo e(__('home.update')); ?></button>
                                        <a href="<?php echo e(route('admin.doctors')); ?>"
                                           class="btn btn-danger"><?php echo e(__('home.cancel')); ?></a>
                                    </div>
                                </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', ['activePage' => 'doctors', 'titlePage' => __('home.doctors')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Red\tripomedic\resources\views/doctor/edit.blade.php ENDPATH**/ ?>