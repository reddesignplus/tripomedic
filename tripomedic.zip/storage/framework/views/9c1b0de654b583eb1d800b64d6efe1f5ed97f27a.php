<?php $__env->startSection('content'); ?>

    <section class="blog-item">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="item">
                            <img src="<?php echo e($item->featured_image); ?>" alt="<?php echo e($item->title); ?>" class="border radius">
                            <h1 class="title mt-2"><?php echo e($item->title); ?></h1>
                        <div class="description"><?php echo $item->content; ?></div>
                    </div>
                </div>
            </div>
        </div>

                        <?php echo $__env->make('partial.comments', ['showTitle'=>true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container comment-form">
            <div class="row">
                <div class="section-head d-flex justify-content-center hr">
                    <h2 class="px-1"><?php echo e(__('form.comment_form_title')); ?></h2>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="comment-form">
                        <?php echo $__env->make('partial.commentForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>

        </div>
    </section>
        <section id="related-item">
            <div class="container">
                <div class="row">
                    <div class="section-head d-flex justify-content-center hr">
                        <h2 class="px-1"><?php echo e(__('home.related_items')); ?></h2>
                    </div>
                </div>
            </div>
        </section>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Red\tripomedic\resources\views/blog/single.blade.php ENDPATH**/ ?>