<?php if(1): ?>
<?php $__env->startSection('content'); ?>
    <?php if(!empty($best)): ?>
        <div class="container mt-3">
            <div class="row">
                <div class="col-12">
                    <div class="best">
                        <a href="/clinics/<?php echo e($best->id); ?>" class="tripo-btn btn-white p-0">
                            <img class="border radius w-100" src="<?php echo e($best->featured_image); ?>"
                                 alt="<?php echo e(__('clinic.best')); ?> <?php echo e($best->name); ?>">
                            <p class="position-absolute btn-btcenter"><?php echo e(__('clinics.best')); ?> <?php echo e($best->name); ?></p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="container mt-3">
        <div class="row">
            <div class="col-12">
                <div class="description text-justify px-3"><?php echo $lead; ?>

                </div>
            </div>
        </div>
    </div>
    <section id="filter" class="mt-3">
        <div class="container clinic-compare d-flex flex-column position-relative justify-content-center">
            <div class="row justify-content-center">
                <form action="/clinics" method="POST" class="text-center">
                    <?php echo method_field('POST'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="treatment" class="form-label mb-1"><?php echo e(__('form.treatment')); ?></label>
                        <select class="form-control form-control-sm radius" name="treatment" id="treatment">
                            <?php $__currentLoopData = \App\Procedure::where('type','treatment')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    value="<?php echo e($treat->id); ?>" <?php echo e(app('request')->input('treatment') == $treat->id ? 'checked' :''); ?> >
                                    <?php echo e($treat->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="city" class="form-label mb-1"><?php echo e(__('form.city')); ?></label>
                        <select class="form-control form-control-sm radius" name="city" id="city">
                            <?php $__currentLoopData = \App\City::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    value="<?php echo e($city->id); ?>" <?php echo e(app('request')->input('city') == $city->id ? 'checked' :''); ?> >
                                    <?php echo e($city->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="facilities" class="form-label mb-1"><?php echo e(__('form.facilities')); ?></label>
                        <select class="form-control form-control-sm radius" name="facilities" id="facilities">
                            <?php $__currentLoopData = \App\Facilitator::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facilities): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    value="<?php echo e($facilities->id); ?>" <?php echo e(app('request')->input('facilities') == $facilities->id ? 'checked' :''); ?> >
                                    <?php echo e($facilities->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="language" class="form-label mb-1"><?php echo e(__('form.language')); ?></label>
                        <select class="form-control form-control-sm radius" name="language" id="language" type="text"
                                value="<?php echo e(app('request')->input('language') or old('language')); ?>">
                            <?php $__currentLoopData = ['ar','en','fa','es']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    value="<?php echo e($lang); ?>" <?php echo e(app('request')->input('lang') == $lang ? 'checked' :''); ?> >
                                    <?php echo e(__('home.language.'.$lang)); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="price" class="form-label mb-1"><?php echo e(__('form.price')); ?></label>
                        <input class="form-control form-control-sm radius" name="price" id="price"
                               type="text" vale="<?php echo e(app('request')->input('price') or old('price')); ?>" >
                    </div>
                    <div class="form-group">
                        <label for="rate" class="form-label mb-1"><?php echo e(__('form.rate')); ?></label>
                        <input class="form-control form-control-sm radius" name="rate" id="rate"
                               type="text" value=" <?php echo e(app('request')->input('rate') or old('rate')); ?>" >
                    </div>
                    <div class="form-group">


                                    <label class="form-label form-check-label w-100 d-flex align-items-center justify-content-center form-check p-0"
                                           for="facilitator"><?php echo e(__('form.facilitator')); ?>

                                        <input class="form-check-input" type="checkbox" name="facilitator"
                                               id="facilitator"
                                               value="1" <?php echo e(app('request')->input('facilitator')or ''); ?> >
                                        <span class="form-check-sign">
                                <span class="check"></span>
                              </span>
                                    </label>



                    </div>
                    <div class="position-absolute btn-btcenter">
                        <button type="submit" class="tripo-btn btn-white text-nowrap">
                            <?php echo e(__('home.find_button')); ?>

                        </button>
                    </div>

                </form>
            </div>
        </div>
    </section>
    <section id="clinics-result">
        <div class="container">
            <div class="row">
                <div class="section-head d-flex justify-content-center hr">
                    <h2 class="px-1"><?php echo trans_choice('clinics.result_title', $type,['count' =>count($clinics)]) ?></h2>
                </div>
            </div>

            <?php if(isset($clinics)): ?>
                <form action="/clinic-compare" method="post" enctype="multipart/form-data">
                    <?php echo method_field('POST'); ?>
                    <?php echo csrf_field(); ?>
                    <ul class="clinics-list list-unstyled">
                        <?php $__currentLoopData = $clinics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clinic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="result-item row mb-3 align-items-center">
                                <div class="col-4">
                                    <a href="/clinics/<?php echo e($clinic->id); ?>">
                                        <img src="<?php echo e($clinic->logo); ?>" alt="<?php echo e($clinic->name); ?>">
                                    </a>
                                </div>

                                <div class="col-8 details p-1">
                                    <p class="name"><a
                                            href="/clinics/<?php echo e($clinic->id); ?>"><?php echo e($clinic->name); ?></a>
                                    </p>
                                    <p class="excerpt"> <?php echo e($clinic->procedures->first()['name']); ?></p>
                                    <div class="row align-items-center justify-content-between m-0">
                                        <div class="location btn-green py-1 px-3"><span
                                                class="flaticon-location"></span><?php echo e($clinic->city['name']); ?></div>
                                        <span class="rate"><i class="icon icon-star"></i></span>

                                            <div class="form-check">
                                                <label class="form-check-label"
                                                   for="clinics[]">
                                                    <input class="form-check-input" type="checkbox" name="clinics[]"
                                                       id="clinic-<?php echo e($clinic->id); ?>"
                                                       value="<?php echo e($clinic->id); ?>">
                                                    <span class="form-check-sign">
                                                        <span class="check"></span>
                                                    </span>
                                                </label>

                                            </div>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul> <?php $__errorArgs = ['clinics'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="small "><?php echo e(__('clinics.compare_warning')); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <button type="submit" class="compare"></button>
                </form>
            <?php endif; ?>
            <?php if (! ($clinics)): ?>

            <?php endif; ?>
        </div>
    </section>
    <?php echo $__env->make('partial.advice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partial.social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Red\tripomedic\resources\views/clinic/index.blade.php ENDPATH**/ ?>