<section id="subscribe" class="mt-0">
    <div class="container d-flex flex-column position-relative justify-content-center">
        <div class="row justify-content-center">
                <form action="/subscribe/add" method="post">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <p class="form-label text-center mb-4 w-100"><?php echo e(__('home.subscribe_text')); ?></p>
                    <div class="d-flex align-items-center">
                        <input id="email" type="email" name="email" class="form-control radius <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="position-absolute btn-btcenter">
                       <button type="submit" class="tripo-btn btn-white"><?php echo e(__('home.subscribe_button')); ?></button>
                    </div>
                </form>

        </div>
    </div>
</section>
<?php /**PATH C:\Users\Red\tripomedic\resources\views/partial/subscribe.blade.php ENDPATH**/ ?>