<?php $__env->startSection('content'); ?>

    <section id="cities" class="mt-3">
        <div class="container">
            <div class="row mb-3">
                <div class="col position-relative">
                    <img class="border radius" src="<?php echo e($cities->featured_image); ?>" alt="<?php echo e($cities->title); ?>">
                    <p class="position-absolute " style="transform: translate(-50%,-50%);top:50%;left:50%;font-size:12px"><?php echo e($cities->title); ?></p>
                </div>
            </div>
            <div class="row content">
                <div class="col description">
                    <?php echo $cities->content; ?>

                </div>
            </div>
            <div class="row cities-list align-items-center justify-content-around mb-4">
                <?php $__currentLoopData = \App\City::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/cities/?c=<?php echo e($item->city_code); ?>" class="location btn-green py-1 px-1 d-inline-block">
                        <span class="flaticon-location"></span><?php echo e($item->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

            <div class="row">
                <div class="col-12 position-relative">
                    <a href="/cities/<?php echo e($city->city_code); ?>">
                        <img src="<?php echo e($city->featured_image); ?>" alt="<?php echo e($city->name . $city->excerpt); ?>" class="border radius">
                        <p class="position-absolute btn-btcenter"> <?php echo e($city->name); ?></p>
                    </a>
                </div>

            </div>

            <div class="row content gallery justify-content-center align-items-center mb-4">

                    <?php echo e($city->content); ?>

                    <?php echo e($city->serices); ?>

                    <?php $cityGallery = (json_decode($city->gallery,true));
                    ?>
                    <?php $__currentLoopData = $cityGallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($key == "images"): ?>
                            <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item col-6 mb-2">
                                    <img src="<?php echo e($item['url']); ?>" alt="<?php echo e($item['title']); ?>" class="w-100 border radius">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item col-12">
                                <video  alt="<?php echo e($item['title']); ?>" class="w-100 border radius" controls>
                                    <source src="<?php echo e($item['url']); ?>" type="video/mp4">
                                    Your browser does not support the video ta
                                </video>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

        </div>

        
        <div class="container">
            <div class="row">
                <div class="col-12 position-relative">
                    <img src="/images/ads/image-03.jpg" alt="" class="border radius">
                    <p class="position-absolute btn-btcenter">
                        الإعلان في الأشياء الطبية
                    </p>
                </div>
            </div>
        </div>

        
        <section id="bestHospitals">

            <div class="container">
                <div class="row">
                    <div class="section-head d-flex justify-content-center hr">
                        <h2 class="px-1"><?php echo e(__('home.best_hospitals')); ?></h2>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <?php $__currentLoopData = $city->hospitals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col best-item d-flex align-items-center">
                            <div class="image w-50"><img class="img-fluid border radius" src="<?php echo e($hospital->featured_image); ?>" alt="<?php echo e($hospital->name); ?>"></div>
                            <span class="name p-3"><?php echo e($hospital->name); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>


        
        <div class="container">
            <div class="row best-clinics">
                <?php $__currentLoopData = \App\Hospital::where('featured',1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hospital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="best-item">
                        <div class="image"><img src="<?php echo e($hospital->featured_image); ?>" alt="<?php echo e($hospital->name); ?>"></div>
                        <div class="name"><?php echo e($hospital->name); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </section>


    <?php echo $__env->make('partial.advice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partial.social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Red\tripomedic\resources\views/cities/index.blade.php ENDPATH**/ ?>