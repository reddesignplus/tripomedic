<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <form action="<?php echo e(route('admin.blog.update',['blog'=>$blog])); ?>"
                              method="post" enctype="multipart/form-data">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="card-header card-header-tabs card-header-primary">
                                <div class="nav-tabs-navigation">
                                    <div class="nav-tabs-wrapper">
                                        <span class="nav-tabs-title"><?php echo e($blog->title); ?></span>
                                        <ul class="nav nav-tabs" data-tabs="tabs">
                                            <li class="nav-item">
                                                <a class="nav-link active" href="#content" data-toggle="tab">
                                                    <i class="material-icons">file_copy</i> Content
                                                    <div class="ripple-container"></div>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a class="nav-link" href="#images" data-toggle="tab">
                                                    <i class="material-icons">collections</i> Images
                                                    <div class="ripple-container"></div>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="tab-content">
                                    <div class="tab-pane active" id="content">
                                        <div class="form-row my-5">
                                            <div class="form-group col">
                                                <label for="title"><?php echo e(__('home.title')); ?></label>
                                                <input type="text" class="form-control" id="title" name="title"
                                                       value="<?php echo e(old('title') ?? $blog->title); ?>" placeholder="">
                                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group col">
                                                <div class="togglebutton">
                                                    <label>
                                                        <span><?php echo e(__('home.featured')); ?></span>
                                                        <input type="checkbox"
                                                               <?php echo e($blog->featured || old('featured') == 'on' ? 'checked' : ''); ?> name="featured">
                                                        <span class="toggle"></span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                            <div class="form-row">
                                                <div class="form-group col-3">
                                                    <label for="created_at"><?php echo e(__('home.published')); ?></label>
                                                    <input class="form-control" type="text"

                                                           value="<?php echo e(old('published_date') ?? $blog->published_date); ?>"
                                                           name="published_date">
                                                </div>
                                                <div class="form-group col-3">
                                                    <label for="created_at"><?php echo e(__('home.expire')); ?></label>
                                                    <input class="form-control" type="text"
                                                           value="<?php echo e(old('expire_date') ?? $blog->expire_date ?? ''); ?>"

                                                           name="expire_date">
                                                </div>
                                                <div class="form-group col-3">
                                                    <label for="created_at"><?php echo e(__('home.created')); ?></label>
                                                    <input class="form-control" type="text"
                                                           value="<?php echo e($blog->created_at->format('Y,M,j - H:i')); ?>"
                                                           readonly>
                                                </div>
                                                <div class="form-group col-3">
                                                    <label for="created_at"><?php echo e(__('home.updated')); ?></label>
                                                    <input class="form-control" type="text"
                                                           value="<?php echo e($blog->updated_at->format('Y,M,j - H:i')); ?>"
                                                           readonly/>
                                                </div>
                                            </div>

                                            <div class="form-row my-5">
                                                <div class="form-group col">
                                                    <label for="excerpt"><?php echo e(__('home.excerpt')); ?></label>
                                                    <input type="text" class="form-control" id="excerpt" name="excerpt"
                                                           value="<?php echo e(old('excerpt') ?? $blog->excerpt); ?>">
                                                </div>
                                            </div>

                                            <div class="form-row">
                                                <div class="form-group col-3">
                                                    <label for="treatparent"><?php echo e(__('home.treatments')); ?></label>
                                                    <select class="form-control" id="treatparent" name="parent">
                                                        <?php $__currentLoopData = \App\Procedure::where('type','treatment')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option
                                                                value="<?php echo e($option->id); ?>" <?php echo e($option->id == $blog->treatment ? "selected" : ""); ?>><?php echo e($option->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                    <?php $__errorArgs = ['parent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                            </div>

                                            <div class="form-row">
                                                <div class="form-group pt-3">
                                                    <label for="content"><?php echo e(__('home.description')); ?></label>
                                                    <textarea class="form-control description" id="content"
                                                              name="content"
                                                              rows="3"><?php echo e(old('content') ?? $blog->content); ?></textarea>
                                                </div>
                                                <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>

                                    </div>
                                    <div class="tab-pane" id="images">
                                            <div class="fileinput fileinput-new text-center col-3"
                                                 data-provides="fileinput">
                                                <div class="fileinput-new thumbnail img-raised">
                                                    <img src="<?php echo e($blog->featured_image); ?>" alt="<?php echo e($blog->name); ?>">
                                                </div>
                                                <div
                                                    class="fileinput-preview fileinput-exists thumbnail img-raised"></div>
                                                <div class="col-3">
                                        <span class="btn btn-raised btn-round btn-default btn-file">
            <span class="fileinput-new">Select image</span>
            <span class="fileinput-exists">Change</span>
            <input type="file" name="featured_image"/>
                                              <?php $__errorArgs = ['featured_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </span>
                                                    <a href="#pablo" class="btn btn-danger btn-round fileinput-exists"
                                                       data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                                                </div>
                                            </div>
                                            <div class="form-group form-file-upload form-file-multiple">
                                                <input type="file" multiple="" class="inputFileHidden">
                                                <div class="input-group">
                                                    <input type="text" class="form-control inputFileVisible"
                                                           placeholder="Multiple Files" multiple name="gallery">
                                                    <span class="input-group-btn">
            <button type="button" class="btn btn-fab btn-round btn-info">
                <i class="material-icons">layers</i>
            </button>
        </span>
                                                    <?php $__errorArgs = ['gallery'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer justify-content-end">
                                            <div class="form-row ">
                                                <button type="submit"
                                                        class="btn btn-primary"><?php echo e(__('home.update')); ?></button>
                                                <a href="<?php echo e(route('admin.blog')); ?>"
                                                   class="btn btn-danger"><?php echo e(__('home.cancel')); ?></a>
                                            </div>
                                        </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', ['activePage' => 'blog', 'titlePage' => __('home.treatments')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Red\tripomedic\resources\views/blog/edit.blade.php ENDPATH**/ ?>