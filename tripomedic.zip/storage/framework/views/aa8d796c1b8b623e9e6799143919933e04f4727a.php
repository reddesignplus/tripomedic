<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title "><?php echo e(__('home.facilitator')); ?></h4>
                            <p class="card-category"><?php echo e(__('home.facilitator_sub')); ?></p>
                        </div>
                        <div class="card-body">
                            <div class="actions float-right">
                                <a class="btn btn-primary" href="<?php echo e(route('admin.facilitators.create')); ?>"><?php echo e(__('home.add_new')); ?></a>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-hover">

                                    <thead class=" text-primary">
                                    <th>
                                        ID
                                    </th>
                                    <th>
                                        <?php echo e(__("home.featured")); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__("home.avatar")); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__("home.name")); ?>

                                    </th>
                                    <th>
                                        <?php echo e(__("home.city")); ?>

                                    </th>

                                    <th>
                                        <?php echo e(__("home.tel")); ?>

                                    </th>

                                    <th>
                                        <?php echo e(__("home.action")); ?>

                                    </th>
                                    </thead>

                                    <tbody>
                                    <?php $__currentLoopData = \App\Facilitator::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facilitator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($facilitator->id); ?>

                                            </td>
                                            <td>
                                                <button  type="button" class="btn btn-fab btn-fab-mini btn-round <?php echo e($facilitator->featured == 'on' ? 'btn-warning' : 'btn-default'); ?>">
                                                    <i class="material-icons">star</i>
                                                </button>
                                            </td>
                                            <td>
                                                <img src="<?php echo e($facilitator->logo); ?>" alt="<?php echo e($facilitator->name); ?>">
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('admin.facilitators.edit',$facilitator)); ?>"><?php echo e($facilitator->name); ?></a>
                                            </td>
                                            <td>
                                                <?php echo e($facilitator->city_code); ?>

                                            </td>
                                            <td>
                                                <?php echo e($facilitator->tel); ?>

                                            </td>


                                            <td>
<span class="input-group-btn">
            <button type="button" class="btn btn-fab btn-fab-mini btn-round btn-primary">
                <i class="material-icons">edit</i>
            </button>
        </span>
                                                <span class="input-group-btn">
            <button type="button" class="btn btn-fab btn-fab-mini btn-round btn-outline-danger">
                <i class="material-icons">delete</i>
            </button>
        </span>
                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', ['activePage' => 'facilitators', 'titlePage' => __('home.facilitator')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Red\tripomedic\resources\views/facilitators/list.blade.php ENDPATH**/ ?>