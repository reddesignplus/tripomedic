<?php $__env->startSection('content'); ?>
    <section class="profile">
        <div class="container">
            <div class="row justify-content-around mb-2">
                <div class="w-25 text-center px-3">
                    <a href="/cities/<?php echo e($doctor->city_code or '071'); ?>" class="location btn-green py-1 px-1 d-inline-block"><span class="flaticon-location"></span>شـیـــراز</a>
                </div>
               <div class="w-25 text-center px-3">
                   <span class="rate btn-green py-1 px-1"><?php echo e($doctor->rate); ?> 4.3</span>
               </div>

            </div>
            <div
                class="row flex-column align-items-center justify-content-center m-0 text-center detail position-relative doctor-item">
                <div class="avatar position-absolute"><img src="<?php echo e($doctor->avatar); ?>"
                                                           alt="<?php echo e($doctor->name); ?> <?php echo e($doctor->family); ?>"></div>
                <div class="mt-5">
                    <p class="name"><?php echo trans_choice(('doctors.gender'), $doctor->gender) ?> <?php echo e($doctor->name); ?> <?php echo e($doctor->family); ?></p>
                    <p class="excerpt"><?php echo e($doctor->procedures->first()["name"]); ?></p>
                    <a href="#comments" class="btn-green py-1 px-1 mb-3 total-count"><span class="icon-review"></span> <?php echo e(count($doctor->comments)); ?> <?php echo e(__('comments.total_count')); ?></a>
                </div>
                <a href="#" class="tripo-btn btn-white btn-btcenter position-absolute" data-toggle="modal" data-target="#inquiry" ><?php echo e(__('doctors.contact')); ?></a>
            </div>
        </div>
        <div class="container">
            <div class="row pt-30">
                <div class="description panel mx-3">
                    <?php echo $doctor->description; ?>

                    <div class="fade"></div>
                </div>

            </div>
            <div class="row">
                <div class="btn-readmore show d-flex flex-column align-items-center position-relative w-100">
                    <a href="#show" class="tripo-btn btn-white" id="show">  <?php echo e(__('home.buttons.showMore')); ?></a>
                    <div class="arrow"></div>

                </div>
            </div>
        </div>
        <div class="container mt-30">
            <div class="row">
                <div class="section-head d-flex justify-content-center hr">
                    <h2 class="px-1"><?php echo e(__('doctors.map')); ?></h2>
                </div>
            </div>
            <div class="map">
                <div class="mapouter">
                    <div class="gmap_canvas">
                        <iframe width="330" height="420" id="gmap_canvas" class="border radius"
                                src="https://maps.google.com/maps?q=Imam%20of%Khomeini%Hospital&t=&z=13&ie=UTF8&iwloc=&output=embed"
                                frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row flex-column align-content-center">
                <div class="contact-info">
                    <?php if($doctor->tel): ?>
                        <div class="section-head d-flex justify-content-center hr">
                            <span></span>
                        </div>
                        <p><?php echo e($doctor->tel); ?></p>
                    <?php endif; ?>
                    <?php if($doctor->website): ?>
                        <div class="section-head d-flex justify-content-center hr">
                            <span></span>
                        </div>  <p><?php echo e($doctor->website); ?></p>
                    <?php endif; ?>

                    <?php if($doctor->emial): ?>
                        <div class="section-head d-flex justify-content-center hr">
                            <span></span>
                        </div> <p><?php echo e($doctor->emial); ?></p>
                    <?php endif; ?>
                        <?php if($doctor->instagram): ?>
                            <div class="section-head d-flex justify-content-center hr">
                                <span></span>
                            </div> <p><?php echo e($doctor->instagram); ?></p>
                        <?php endif; ?>

                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="banner"></div>
            </div>
        </div>

        </div>
    </section>
    
    <div class="modal fade" id="inquiry" tabindex="-1" role="dialog" aria-labelledby="inquiry" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('form.inquiry_title')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Recipient:</label>
                            <input type="text" class="form-control" id="recipient-name">
                        </div>
                        <div class="form-group">
                            <label for="message-text" class="col-form-label">Message:</label>
                            <textarea class="form-control" id="message-text"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Send message</button>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('partial.comments', ['comments' => $doctor->comments,'showTitle'=>true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partial.advice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partial.social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Red\tripomedic\resources\views/doctor/profile.blade.php ENDPATH**/ ?>