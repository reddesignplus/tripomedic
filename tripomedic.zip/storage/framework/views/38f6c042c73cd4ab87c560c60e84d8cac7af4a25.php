<?php $__env->startSection('content'); ?>


<section id="steps">
    <div class="container p-4">
        <div class="row">
            <div class="path d-flex justify-content-center w-100 align-items-center">
                <div class="step rounded-circle p-3">
                    <span class="flaticon-doctor"></span>
                </div>
                <div class="step rounded-circle p-3">
                    <span class="flaticon-clinic"></span>
                </div>
                <div class="step rounded-circle p-3">
                    <span class="flaticon-seesight"></span>
                </div>
                <div class="step rounded-circle p-3">
                    <span class="flaticon-treatment"></span>
                </div>
            </div>
        </div>
        <div class="row justify-content-center mt-4">
            <a class="tripo-btn btn-white" href="#"><?php echo e(__('home.how_we_do')); ?></a>
        </div>
    </div>
</section>

<?php echo $__env->make('partial.social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Red\tripomedic\resources\views/about.blade.php ENDPATH**/ ?>