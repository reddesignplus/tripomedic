<?php $__env->startSection('content'); ?>

    <section id="filter" class="mt-3">
        <div class="container d-flex flex-column position-relative justify-content-center">
            <div class="row justify-content-center">
                <form action="/doctors" method="get">
                    <div class="form-group">
                        <label for="treatment" class="form-label"><?php echo e(__('treatment.treatment')); ?></label>
                        <select class="form-control form-control-sm radius" name="treatment" id="treatment">
                            <?php $__currentLoopData = \App\Procedure::where('type','treatment')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($treat->id); ?>" <?php echo e(app('request')->input('treatment') == $treat->id ? 'checked' :''); ?> >
                                    <?php echo e($treat->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="treatment" class="form-label"><?php echo e(__('treatment.treatment')); ?></label>
                        <select class="form-control form-control-sm radius" name="treatment" id="treatment">
                            <?php $__currentLoopData = \App\Procedure::where('type','procedure')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($treat->id); ?>" <?php echo e(app('request')->input('treatment') == $treat->id ? 'checked' :''); ?> >
                                    <?php echo e($treat->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="city" class="form-label"><?php echo e(__('home.city')); ?></label>
                        <select class="form-control form-control-sm radius" name="city" id="city">
                            <?php $__currentLoopData = \App\City::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($city->city_code); ?>" <?php echo e(app('request')->input('treatment') == $city->id ? 'checked' :''); ?> >
                                    <?php echo e($city->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-row justify-content-around">
                            <div class="col-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gender" id="gender"
                                           value="men" <?php echo e(app('request')->input('gender') == 'men' ? 'checked' :''); ?>>
                                    <label class="form-label" for="gender"><?php echo e(__('doctors.men')); ?></label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="gender" id="gender"
                                           value="women"  <?php echo e(app('request')->input('gender') == 'women' ? 'checked' :''); ?>>
                                    <label class="form-label" for="gender"><?php echo e(__('doctors.women')); ?></label>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="age" id="age"
                                           value="child"  <?php echo e(app('request')->input('age') == 'child' ? 'checked' :''); ?>>
                                    <label class="form-label" for="age"><?php echo e(__('doctors.child')); ?></label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="age" id="age"
                                           value="adult"  <?php echo e(app('request')->input('age') == 'adult' ? 'checked' :''); ?>>
                                    <label class="form-label" for="age"><?php echo e(__('doctors.adult')); ?></label>
                                </div>
                            </div>
                    </div>
                    <div class="position-absolute btn-btcenter">
                        <button type="submit" class="tripo-btn btn-white text-nowrap">
                            <?php echo e(__('home.find_button')); ?>

                        </button>
                    </div>

                </form>
            </div>
        </div>
    </section>
    <section id="doctors-result">
        <div class="container">
            <div class="row">
                <div class="section-head d-flex justify-content-center hr">
                    <h2 class="px-1"><?php echo trans_choice(('doctors.result_title'), $type) ?></h2>
                </div>
            </div>

            <?php if(isset($doctors)): ?>
                <ul class="doctors-list list-unstyled">
                    <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="result-item row">
                            <div class="col-4">
                                <a href="/doctors/<?php echo e($doctor->id); ?>">
                                    <img src="<?php echo e($doctor->avatar); ?>" alt="<?php echo e($doctor->name); ?><?php echo e($doctor->family); ?>">
                                </a>
                            </div>
                            <div class="col-8 details p-1">
                                <p class="name"><a
                                        href="/doctors/<?php echo e($doctor->id); ?>"><?php echo trans_choice(('doctors.gender'), $doctor->gender) ?> <?php echo e($doctor->name); ?> <?php echo e($doctor->family); ?></a>
                                </p>
                                <p class="excerpt"> <?php echo e($doctor->procedures->first()['name']); ?></p>
                                <span class="location btn-green py-1 px-3"><span class="flaticon-location"></span>شـیـــراز </span>
                                <span class="rate"></span>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
            <?php if (! ($doctors)): ?>

            <?php endif; ?>
            <div class="ads"><img src="/images/ads/image-01.png" alt=""></div>

        </div>
    </section>
    <?php echo $__env->make('partial.advice', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row divider m-4"></div>
    <?php echo $__env->make('partial.blog',['class'=>'mt-2'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partial.social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Red\tripomedic\resources\views/doctor/index.blade.php ENDPATH**/ ?>