<section id="advice" class="col-lg-6">

    <div class="container">
        <div class="row">
            <div class="section-head d-flex justify-content-center hr">
                <h2 class="px-1"><?php echo e(__('home.need_advice')); ?></h2>
            </div>
        </div>
        <div class="row justify-content-center">

            <a class="tripo-btn btn-white px-4 text-center w-75"
               href="https://wa.me/15551234567?text=Find%20your%20Best%20Package%20with%20TripoMedic">
                <div class="whatsapp p-1"><img src="/images/whatsapp.png" alt="whatsapp"></div>
                <p class="m-0"><?php echo e(__('home.contact_now')); ?></p>
            </a>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\Red\tripomedic\resources\views/partial/advice.blade.php ENDPATH**/ ?>