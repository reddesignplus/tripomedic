<?php $__env->startSection('content'); ?>
    <section class="profile">
        <div class="container">
            <div class="row justify-content-around mb-2">
                <div class="w-25 text-center px-3">
                    <a href="/cities/0<?php echo e($clinic->city->city_code); ?>" class="location btn-green py-1 px-1 d-inline-block"><span
                            class="flaticon-location"></span><?php echo e($clinic->city->name); ?></a>
                </div>
                <div class="w-25 text-center px-3">
                    <span class="rate btn-green py-1 px-1"><?php echo e($clinic->rate); ?> 4.3</span>
                </div>

            </div>
            <div
                class="row flex-column align-items-center justify-content-center m-0 text-center detail position-relative clinic-item">
                <div class="avatar position-absolute"><img src="<?php echo e($clinic->logo); ?>"
                                                           alt="<?php echo e($clinic->name); ?>"></div>
                <div class="mt-5">
                    <p class="name"><?php echo e($clinic->name); ?></p>
                    <p class="excerpt"><?php echo e($clinic->procedures->first()['name']); ?></p>
                    <a href="#comments" class="btn-green py-1 px-1 mb-3 total-count"><span
                            class="icon-review"></span> <?php echo e(count($clinic->comments)); ?> <?php echo e(__('comments.total_count')); ?></a>
                </div>
                <a href="#" class="tripo-btn btn-white btn-btcenter position-absolute" data-toggle="modal"
                   data-target="#inquiry"><?php echo e(__('clinics.contact')); ?></a>
            </div>
        </div>

        <div class="container mt-5">
            <div class="row">
                <div class="section-head d-flex justify-content-center hr">
                    <h2 class="px-1"><?php echo e(__('clinics.treats')); ?></h2>
                </div>
            </div>
            <div class="row">
                <div class="accordion col-12 w-100" id="treatments">
                    <?php $__currentLoopData = $treatments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card">

                            <button class="btn btn-link py-4 px-2" type="button" data-toggle="collapse"
                                    data-target="#collapse<?php echo e($key); ?>" aria-expanded="true"
                                    aria-controls="collapse<?php echo e($key); ?>">
                                <span class="treat-title float-right"><?php echo e(\App\Procedure::find($key)->name); ?></span>
                                <span class="float-left"><?php echo e(count($value)); ?></span>
                            </button>

                            <div id="collapse<?php echo e($key); ?>" class="collapse show" aria-labelledby="heading<?php echo e($key); ?>"
                                 data-parent="#treatments">
                                <div class="card-body p-0">
                                    <ul class="list-unstyled w-100 p-0">
                                        <?php for($i = 0; $i < count($value); $i++): ?>
                                            <li class="d-flex align-items-center justify-content-between py-4 px-2">
                                                <a href="/procedures/<?php echo e($value[$i]->id); ?>">
                                                    <?php echo e($value[$i]->name); ?>

                                                </a>
                                                <?php if($value[$i]->pivot['price']): ?>
                                                    <span class="float-left"> <?php echo e($value[$i]->pivot['price']); ?></span>
                                                <?php else: ?>
                                                    <a href="#" class="btn-gray float-left" data-toggle="modal"
                                                       data-target="#inquiry"><?php echo e(__('clinics.req_price')); ?></a>

                                                <?php endif; ?>
                                            </li>
                                        <?php endfor; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <div class="container mt-5">
            <div class="row">
                <div class="section-head d-flex justify-content-center hr">
                    <h2 class="px-1"><?php echo e(__('clinics.desc')); ?></h2>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="description mx-3">
                        <?php echo $clinic->description; ?>

                    </div>
                </div>

            </div>
            <div class="row">
                <div class="btn-readmore d-flex flex-column align-items-center position-relative w-100">
                    <a href="/blog" class="tripo-btn btn-white"><?php echo e(__('home.readmore')); ?></a>
                    <div class="arrow"></div>

                </div>
            </div>
        </div>
    </section>
    <?php echo $__env->make('partial.comments', ['comments' => $clinic->comments,'showTitle'=>true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section id="addresses">
        <div class="container mt-30">
            <div class="row">
                <div class="section-head d-flex justify-content-center hr">
                    <h2 class="px-1"><?php echo e(__('clinics.map')); ?></h2>
                </div>
            </div>
            <div class="map">
                <div class="mapouter">
                    <div class="gmap_canvas">
                        <iframe width="330" height="420" id="gmap_canvas" class="border radius"
                                src="https://maps.google.com/maps?q=Imam%20of%Khomeini%Hospital&t=&z=13&ie=UTF8&iwloc=&output=embed"
                                frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="container mt-4">
            <div class="row flex-column align-content-center text-center">
                <div class="contact-info">
                    <?php if($clinic->tel): ?>
                        <div class="section-head d-flex justify-content-center hr">
                            <span></span>
                        </div>
                        <p class="phones"><?php echo e($clinic->tel); ?></p>
                    <?php endif; ?>
                    <?php if($clinic->website): ?>
                        <div class="section-head d-flex justify-content-center hr">
                            <span></span>
                        </div>  <p><?php echo e($clinic->website); ?></p>
                    <?php endif; ?>

                    <?php if($clinic->emial): ?>
                        <div class="section-head d-flex justify-content-center hr">
                            <span></span>
                        </div> <p><?php echo e($clinic->emial); ?></p>
                    <?php endif; ?>
                    <?php if($clinic->instagram): ?>
                        <div class="section-head d-flex justify-content-center hr">
                            <span></span>
                        </div> <p><?php echo e($clinic->instagram); ?></p>
                    <?php endif; ?>

                </div>
            </div>
        </div>

    </section>



    <?php echo $__env->make('partial.city',['city'=>$clinic->city,'showTitle'=>true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('partial.social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    
    <div class="modal fade" id="inquiry" tabindex="-1" role="dialog" aria-labelledby="inquiry" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('form.inquiry_title')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Recipient:</label>
                            <input type="text" class="form-control" id="recipient-name">
                        </div>
                        <div class="form-group">
                            <label for="message-text" class="col-form-label">Message:</label>
                            <textarea class="form-control" id="message-text"></textarea>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Send message</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Red\tripomedic\resources\views/clinic/profile.blade.php ENDPATH**/ ?>