<section id="destination" class="<?php echo e($class ?? ''); ?>">
    <div class="container">
        <?php if($showTitle): ?>

            <div class="row">
                <div class="section-head d-flex justify-content-center hr">
                    <h2 class="px-1"><?php echo e(__('clinics.destination')); ?></h2>
                </div>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="city-item col-12 col-md-6 mb-4">
                <div class="pb-4">
                    <div class="item-img position-relative">
                        <a href="/cities/<?php echo e($city->id); ?>" class="tripo-btn p-0">
                            <img src="<?php echo e($city->featured_image); ?>" class="border radius w-100"
                                 alt="<?php echo e($city->name); ?>">
                            <p class="title position-absolute btn-btcenter"><?php echo e($city->name); ?></p>
                        </a>
                    </div>
                            <div class="description p-3 mb-3"><?php echo $city->description; ?> </div>
                </div>

            </div>

        </div>

    </div>
</section>
<?php /**PATH C:\Users\Red\tripomedic\resources\views/partial/city.blade.php ENDPATH**/ ?>