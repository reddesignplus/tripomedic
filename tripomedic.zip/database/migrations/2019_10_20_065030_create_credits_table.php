<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCreditsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('credits', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->string('alias',100);
            $table->longText('description');
            $table->enum('type',['gold','silver','bronze'])->default('bronze');
            $table->char('clinic',4)->default('2');
            $table->char('treatment',4)->default('2');
            $table->char('procedure',4)->default('2');
            $table->char('website',4)->default('1');
            $table->char('tel',4)->default('1');
            $table->boolean('address')->default(true);
            $table->char('comment',4)->default('4');
            $table->char('gallery',4)->default('2');
            $table->boolean('inquiry')->default(false);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('credits');
    }
}
