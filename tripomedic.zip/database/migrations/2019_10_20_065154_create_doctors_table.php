<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDoctorsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('doctors', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->string('family');
            $table->string('alias',100);
            $table->string('excerpt');
            $table->longText('description');
            $table->text('address');
            $table->string('city_code',6);
            $table->string('tel',70);
            $table->string('email',70);
            $table->string('website',100);
            $table->json('social');
            $table->json('certificate');
            $table->string('grade');
            $table->enum('gender',['men','women']);
            $table->enum('age',['adult','child']);
            $table->string('avatar');
            $table->boolean('featured')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('doctors');
    }
}
