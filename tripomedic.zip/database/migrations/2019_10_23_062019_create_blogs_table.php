<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBlogsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('blogs', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('title');
            $table->string('alias',100);
            $table->string('excerpt');
            $table->longText('content');
            $table->string('featured_image');
            $table->json('gallery');
            $table->integer('author')->nullable();
            $table->timestamp('published_date')->nullable()->useCurrent();
            $table->timestamp('expire_date')->nullable();
            $table->enum('status',['published','pending','trash'])->default('pending');
            $table->boolean('featured')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('blogs');
    }
}
