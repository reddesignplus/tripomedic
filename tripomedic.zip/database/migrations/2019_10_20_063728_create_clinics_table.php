<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateClinicsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('clinics', function (Blueprint $table) {
            $table->increments();
            $table->string('name');
            $table->string('alias',100);
            $table->string('excerpt');
            $table->longText('description');
            $table->text('address');
            $table->string('city_code',5);
            $table->string('location',100);
            $table->Integer('hospital_id')->default(0);
            $table->string('tel',70);
            $table->string('email',100);
            $table->string('website',100);
            $table->json('social');
            $table->json('certificate');
            $table->json('services');
            $table->string('language');
            $table->enum('credit',['gold','silver','bronze']);
            $table->string('logo');
            $table->string('featured_image');
            $table->json('gallery');
            $table->boolean('featured')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('clinics');
    }
}
