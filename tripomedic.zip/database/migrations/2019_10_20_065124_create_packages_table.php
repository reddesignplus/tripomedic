<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePackagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('packages', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->string('alias',100)->unique();
            $table->string('excerpt');
            $table->longText('description');
            $table->Integer('procedure_id');
            $table->Integer('facilitator_id');
            $table->timestamp('published_date')->nullable()->useCurrent();
            $table->timestamp('expire_date')->nullable();
            $table->unsignedDecimal('price',19,2);
            $table->boolean('featured')->default(0);
            $table->string('featured_image');
            $table->json('gallery');
            $table->json('services');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('packages');
    }
}
