<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProceduresTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('procedures', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->string('alias',100);
            $table->string('excerpt');
            $table->longText('description');
            $table->Integer('treatment_id');
            $table->string('icon');
            $table->enum('age',['adult','child']);
            $table->enum('gender',['men','women']);
            $table->boolean('featured')->default(0);
            $table->string('featured_image');
            $table->json('gallery');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('procedures');
    }
}
