<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Auth::routes(['register' => false,'login'=>false]);
Auth::routes();


Route::get('/', 'HomeController@index')->name('home');

Route::get('/hospitals', 'HospitalController@index');
Route::get('/hospitals/{id}', 'HospitalController@show');


Route::match(['GET', 'POST'], '/clinics', 'ClinicController@index');
Route::get('/clinics/{clinic}', 'ClinicController@show');
Route::post('/clinic-compare/', 'ClinicController@compare');


Route::match(['GET', 'POST'], '/treatments',  'ProcedureController@index');
Route::get('/treatments/{type?}/{id}', 'ProcedureController@show');



Route::get('/doctors', 'DoctorController@index');
Route::get('/doctors/{doctor}', 'DoctorController@show');


Route::get('/cities/{c?}', 'CityController@index');
Route::get('/cities/{city}', 'CityController@show');


Route::match(['GET', 'POST'], '/facilitators', 'FacilitatorController@index');
Route::get('/facilitators/{facilitator}', 'FacilitatorController@show');

Route::get( '/packages', 'PackageController@index');
Route::get('/packages/{package}', 'PackageController@show');


Route::get('/blog', 'BlogController@index');
Route::get('/blog/{id}', 'BlogController@show');


Route::get('/about', 'PageController@index');

Route::post('/comment/add/', 'CommentController@store' );

Route::get('/inquiry', 'InquiryController@index' );
Route::post('/inquiry/submit', 'InquiryController@index' );


Route::get('/visa', 'PageController@index' );
Route::post('/visa/submit', 'PageController@index' );

Route::put('subscribe/add','SubscribeController@store');

//Route::get('/home', 'HomeController@index')->name('home')->middleware('auth');


Route::prefix('admin')->name('admin.')->middleware(['auth'])->group(function () {

    Route::get('/', 'HomeController@admin')->name('dashboard');
	Route::get('hospitals', function () {
		return view('hospital.list');
	})->name('hospitals');
    Route::get('hospitals/create', 'HospitalController@create')->name('hospitals.create');
    Route::put('hospitals/store', 'HospitalController@store')->name('hospitals.store');
    Route::get('hospitals/{hospital}/edit', 'HospitalController@edit')->name('hospitals.edit');
    Route::put('hospitals/{hospital}', 'HospitalController@update')->name('hospitals.update');

    /************    clinics Route     ************/

    Route::get('clinics', function () {
        return view('clinic.list');
    })->name('clinics');
    Route::get('clinics/create', 'ClinicController@create')->name('clinics.create');
    Route::put('clinics/store', 'ClinicController@store')->name('clinics.store');
    Route::get('clinics/{clinic}/edit', 'ClinicController@edit')->name('clinics.edit');
    Route::put('clinics/{clinic}', 'ClinicController@update')->name('clinics.update');



    /************    doctors Route     ************/

    Route::get('doctors', function () {
        return view('doctor.list');
    })->name('doctors');
    Route::get('doctors/create', 'DoctorController@create')->name('doctors.create');
    Route::put('doctors/store', 'DoctorController@store')->name('doctors.store');
    Route::get('doctors/{doctor}/edit', 'DoctorController@edit')->name('doctors.edit');
    Route::put('doctors/{doctor}', 'DoctorController@update')->name('doctors.update');

    /************    Procedure Route     ************/

    Route::get('treatments', function (){
        return view('treatments.list',['treatments'=>\App\Procedure::where('type','treatment')->get(),'title'=>__('treatment.treatment'),'type'=>'treatment']);
    })->name('treatments');

    Route::get('procedures',  function (){
        return view('treatments.list',['treatments'=>\App\Procedure::where('type','procedure')->get(),'title'=>__('home.procedures'),'type'=>'procedure']);
    })->name('procedures');

    Route::get('treatments/create/{type}', 'ProcedureController@create')->name('treatments.create');
    Route::put('treatments/store', 'ProcedureController@store')->name('treatments.store');
    Route::get('treatments/{procedure}/edit', 'ProcedureController@edit')->name('treatments.edit');
    Route::put('treatments/{procedure}', 'ProcedureController@update')->name('treatments.update');


    /************    cities Route     ************/

    Route::get('cities', function () {
        return view('cities.list');
    })->name('cities');
    Route::get('cities/create', 'CityController@create')->name('cities.create');
    Route::put('cities/store', 'CityController@store')->name('cities.store');
    Route::get('cities/{city}/edit', 'CityController@edit')->name('cities.edit');
    Route::put('cities/{city}', 'CityController@update')->name('cities.update');



    /************    facilitators Route     ************/

    Route::get('facilitators', function () {
        return view('facilitators.list');
    })->name('facilitators');
    Route::get('facilitators/create', 'FacilitatorController@create')->name('facilitators.create');
    Route::put('facilitators/store', 'FacilitatorController@store')->name('facilitators.store');
    Route::get('facilitators/{facilitator}/edit', 'FacilitatorController@edit')->name('facilitators.edit');
    Route::put('facilitators/{facilitator}', 'FacilitatorController@update')->name('facilitators.update');



    /************    blog Route     ************/

    Route::get('blog', function () {
        return view('blog.list');
    })->name('blog');
    Route::get('blog/create', 'BlogController@create')->name('blog.create');
    Route::put('blog/store', 'BlogController@store')->name('blog.store');
    Route::get('blog/{blog}/edit', 'BlogController@edit')->name('blog.edit');
    Route::put('blog/{blog}', 'BlogController@update')->name('blog.update');


    /************    credit Route     ************/

    Route::get('credit', function () {
        return view('credit.list');
    })->name('credit');
    Route::get('credit/create', 'CreditController@create')->name('credit.create');
    Route::put('credit/store', 'CreditController@store')->name('credit.store');
    Route::get('credit/{blog}/edit', 'CreditController@edit')->name('credit.edit');
    Route::put('credit/{blog}', 'CreditController@update')->name('credit.update');


	Route::get('typography', function () {
		return view('admin.pages.typography');
	})->name('typography');

	Route::get('icons', function () {
		return view('admin.pages.icons');
	})->name('icons');

	Route::get('map', function () {
		return view('admin.pages.map');
	})->name('map');

	Route::get('notifications', function () {
		return view('admin.pages.notifications');
	})->name('notifications');

	Route::get('rtl-support', function () {
		return view('admin.pages.language');
	})->name('language');
//});


    /************    User Route     ************/
//Route::group(['middleware' => 'auth'], function () {
	Route::resource('user', 'UserController', ['except' => ['show']]);
	Route::get('profile', ['as' => 'profile.edit', 'uses' => 'ProfileController@edit']);
	Route::put('profile', ['as' => 'profile.update', 'uses' => 'ProfileController@update']);
	Route::put('profile/password', ['as' => 'profile.password', 'uses' => 'ProfileController@password']);
});

